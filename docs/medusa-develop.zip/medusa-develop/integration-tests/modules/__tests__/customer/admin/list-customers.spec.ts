import { Modules } from "@medusajs/utils"
import {
  adminHeaders,
  createAdminUser,
} from "../../../../helpers/create-admin-user"

import { ICustomerModuleService } from "@medusajs/types"

const { medusaIntegrationTestRunner } = require("@medusajs/test-utils")

jest.setTimeout(50000)

medusaIntegrationTestRunner({
  env: {},
  testSuite: ({ dbConnection, getContainer, api, dbUtils }) => {
    describe("GET /admin/customers", () => {
      let appContainer
      let shutdownServer
      let customerModuleService: ICustomerModuleService

      beforeAll(async () => {
        appContainer = getContainer()
        customerModuleService = appContainer.resolve(Modules.CUSTOMER)
      })

      beforeAll(async () => {
        await createAdminUser(dbConnection, adminHeaders, appContainer)

        await dbUtils.snapshot()
      })

      it("should get all customers and its count", async () => {
        await customerModuleService.createCustomers([
          {
            first_name: "Test",
            last_name: "Test",
            email: "test@me.com",
          },
        ])

        const response = await api.get(`/admin/customers`, adminHeaders)

        expect(response.status).toEqual(200)
        expect(response.data.count).toEqual(1)
        expect(response.data.customers).toEqual([
          expect.objectContaining({
            id: expect.any(String),
            first_name: "Test",
            last_name: "Test",
            email: "test@me.com",
          }),
        ])
      })

      it("should get all customers in specific customer group and its count", async () => {
        const vipGroup = await customerModuleService.createCustomerGroups({
          name: "VIP",
        })

        const [john] = await customerModuleService.createCustomers([
          {
            first_name: "John",
            last_name: "Doe",
            email: "john.doe@example.com",
          },
          {
            first_name: "Jane",
            last_name: "Smith",
            email: "jane.smith@example.com",
          },
        ])

        await customerModuleService.addCustomerToGroup({
          customer_id: john.id,
          customer_group_id: vipGroup.id,
        })

        const response = await api.get(
          `/admin/customers?limit=20&offset=0&groups%5B0%5D=${vipGroup.id}`,
          adminHeaders
        )

        expect(response.status).toEqual(200)
        expect(response.data.count).toEqual(1)
        expect(response.data.customers).toEqual([
          expect.objectContaining({
            first_name: "John",
            last_name: "Doe",
            email: "john.doe@example.com",
          }),
        ])
      })

      it("should filter customers by last name", async () => {
        await customerModuleService.createCustomers([
          {
            first_name: "Jane",
            last_name: "Doe",
            email: "jane@me.com",
          },
          {
            first_name: "John",
            last_name: "Doe",
            email: "john@me.com",
          },
          {
            first_name: "LeBron",
            last_name: "James",
            email: "lebron@me.com",
          },
          {
            first_name: "John",
            last_name: "Silver",
            email: "johns@me.com",
          },
        ])

        const response = await api.get(
          `/admin/customers?last_name=Doe`,
          adminHeaders
        )

        expect(response.status).toEqual(200)
        expect(response.data.count).toEqual(2)
        expect(response.data.customers).toContainEqual(
          expect.objectContaining({
            id: expect.any(String),
            first_name: "Jane",
            last_name: "Doe",
            email: "jane@me.com",
          })
        )
        expect(response.data.customers).toContainEqual(
          expect.objectContaining({
            id: expect.any(String),
            first_name: "John",
            last_name: "Doe",
            email: "john@me.com",
          })
        )
      })

      it("should support searching of customers", async () => {
        await customerModuleService.createCustomers([
          {
            first_name: "Jane",
            last_name: "Doe",
            email: "jane@me.com",
          },
          {
            first_name: "John",
            last_name: "Doe",
            email: "john@me.com",
          },
          {
            first_name: "LeBron",
            last_name: "James",
            email: "lebron@me.com",
          },
        ])

        const response = await api.get(`/admin/customers?q=do`, adminHeaders)

        expect(response.status).toEqual(200)
        expect(response.data.customers).toHaveLength(2)
        expect(response.data.customers).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              first_name: "Jane",
              last_name: "Doe",
            }),
            expect.objectContaining({
              first_name: "John",
              last_name: "Doe",
            }),
          ])
        )
      })
    })
  },
})
