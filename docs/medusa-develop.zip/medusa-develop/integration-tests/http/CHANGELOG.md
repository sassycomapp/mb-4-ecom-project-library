# integration-tests-http

## 1.1.26

### Patch Changes

- Updated dependencies [[`3718c46fa637e6556461fd50703425ee2cd33bfd`](https://github.com/medusajs/medusa/commit/3718c46fa637e6556461fd50703425ee2cd33bfd), [`1ba69082ceb941d47cfe390212f400e39a7166dd`](https://github.com/medusajs/medusa/commit/1ba69082ceb941d47cfe390212f400e39a7166dd), [`2aaf53962055fce8e302a76dd416e4eb6ead5929`](https://github.com/medusajs/medusa/commit/2aaf53962055fce8e302a76dd416e4eb6ead5929), [`41d8204e67dc02f600b74b2002f74860ee764fb5`](https://github.com/medusajs/medusa/commit/41d8204e67dc02f600b74b2002f74860ee764fb5), [`989880a6c51f3659453473b2a5b068e83ce4fc78`](https://github.com/medusajs/medusa/commit/989880a6c51f3659453473b2a5b068e83ce4fc78)]:
  - @medusajs/promotion@2.21.2
  - @medusajs/utils@2.21.2
  - @medusajs/medusa@2.21.2
  - @medusajs/framework@2.21.2
  - @medusajs/modules-sdk@2.21.2
  - @medusajs/event-bus-redis@2.21.2
  - @medusajs/loyalty-plugin@2.21.2
  - @medusajs/test-utils@2.21.2
  - @medusajs/core-flows@2.21.2
  - @medusajs/api-key@2.21.2
  - @medusajs/auth@2.21.2
  - @medusajs/cache-inmemory@2.21.2
  - @medusajs/customer@2.21.2
  - @medusajs/event-bus-local@2.21.2
  - @medusajs/fulfillment@2.21.2
  - @medusajs/inventory@2.21.2
  - @medusajs/pricing@2.21.2
  - @medusajs/product@2.21.2
  - @medusajs/fulfillment-manual@2.21.2
  - @medusajs/region@2.21.2
  - @medusajs/stock-location@2.21.2
  - @medusajs/store@2.21.2
  - @medusajs/tax@2.21.2
  - @medusajs/translation@2.21.2
  - @medusajs/user@2.21.2
  - @medusajs/workflow-engine-inmemory@2.21.2

## 1.1.25

### Patch Changes

- Updated dependencies [[`1c1607cced6c1e552e9e800cf571a2235098d0fd`](https://github.com/medusajs/medusa/commit/1c1607cced6c1e552e9e800cf571a2235098d0fd), [`17ecd1d329ea36f392cc0ec1e8846bb21da7a4ba`](https://github.com/medusajs/medusa/commit/17ecd1d329ea36f392cc0ec1e8846bb21da7a4ba), [`c7225d7191cafcd7e66bba714f203bcf5ce6923b`](https://github.com/medusajs/medusa/commit/c7225d7191cafcd7e66bba714f203bcf5ce6923b), [`3538aab7bc5fcff61591a83bb98e6643823cb947`](https://github.com/medusajs/medusa/commit/3538aab7bc5fcff61591a83bb98e6643823cb947), [`f8dce55556a1e68d6ea9b2fb88852b2a76fbd73c`](https://github.com/medusajs/medusa/commit/f8dce55556a1e68d6ea9b2fb88852b2a76fbd73c), [`bb4c7cbafe45212f3df408a2a09d73253c3d0b40`](https://github.com/medusajs/medusa/commit/bb4c7cbafe45212f3df408a2a09d73253c3d0b40), [`1caeb1ab62de9b51c1f385e0e051bb8a10c66aee`](https://github.com/medusajs/medusa/commit/1caeb1ab62de9b51c1f385e0e051bb8a10c66aee), [`893d96850320f8f00c623c66f46e9fcde5ab1cdf`](https://github.com/medusajs/medusa/commit/893d96850320f8f00c623c66f46e9fcde5ab1cdf), [`c000d377f1a90d14bcda41500b1ed5bc2734902e`](https://github.com/medusajs/medusa/commit/c000d377f1a90d14bcda41500b1ed5bc2734902e), [`7ff721850c22a886af25f251685f6bca59434664`](https://github.com/medusajs/medusa/commit/7ff721850c22a886af25f251685f6bca59434664), [`75f3d03b84b1404cc05b9f5f15c6be4a2c2f1d18`](https://github.com/medusajs/medusa/commit/75f3d03b84b1404cc05b9f5f15c6be4a2c2f1d18), [`83592f11c72fde11c2d23d9b160bc5a9f010ea26`](https://github.com/medusajs/medusa/commit/83592f11c72fde11c2d23d9b160bc5a9f010ea26), [`7a0cb956645aef3ed13a20c18fc3faf8961ca535`](https://github.com/medusajs/medusa/commit/7a0cb956645aef3ed13a20c18fc3faf8961ca535), [`854a42c10f14735785fccf74b2f0b53b3b46204f`](https://github.com/medusajs/medusa/commit/854a42c10f14735785fccf74b2f0b53b3b46204f)]:
  - @medusajs/utils@2.21.1
  - @medusajs/medusa@2.21.1
  - @medusajs/loyalty-plugin@2.21.1
  - @medusajs/core-flows@2.21.1
  - @medusajs/framework@2.21.1
  - @medusajs/test-utils@2.21.1
  - @medusajs/modules-sdk@2.21.1
  - @medusajs/event-bus-redis@2.21.1
  - @medusajs/api-key@2.21.1
  - @medusajs/auth@2.21.1
  - @medusajs/cache-inmemory@2.21.1
  - @medusajs/customer@2.21.1
  - @medusajs/event-bus-local@2.21.1
  - @medusajs/fulfillment@2.21.1
  - @medusajs/inventory@2.21.1
  - @medusajs/pricing@2.21.1
  - @medusajs/product@2.21.1
  - @medusajs/promotion@2.21.1
  - @medusajs/fulfillment-manual@2.21.1
  - @medusajs/region@2.21.1
  - @medusajs/stock-location@2.21.1
  - @medusajs/store@2.21.1
  - @medusajs/tax@2.21.1
  - @medusajs/translation@2.21.1
  - @medusajs/user@2.21.1
  - @medusajs/workflow-engine-inmemory@2.21.1

## 1.1.24

### Patch Changes

- [#16762](https://github.com/medusajs/medusa/pull/16762) [`cbd48e2e0169ef9c016fb25703ae08d70827ff34`](https://github.com/medusajs/medusa/commit/cbd48e2e0169ef9c016fb25703ae08d70827ff34) Thanks [@sradevski](https://github.com/sradevski)! - Add search helpers for better DX

- Updated dependencies [[`c511dbb072270b01cddc52a0b77040701ffe34ff`](https://github.com/medusajs/medusa/commit/c511dbb072270b01cddc52a0b77040701ffe34ff), [`cbd48e2e0169ef9c016fb25703ae08d70827ff34`](https://github.com/medusajs/medusa/commit/cbd48e2e0169ef9c016fb25703ae08d70827ff34), [`ce19ae663c3edaa6b58bd596a406bcde24d5956f`](https://github.com/medusajs/medusa/commit/ce19ae663c3edaa6b58bd596a406bcde24d5956f), [`2097e7b43f3d4525b1a909dbe4cb6fb634765893`](https://github.com/medusajs/medusa/commit/2097e7b43f3d4525b1a909dbe4cb6fb634765893), [`0ef6fa815681dfd1771ece1edc921ffbfbc2ef4b`](https://github.com/medusajs/medusa/commit/0ef6fa815681dfd1771ece1edc921ffbfbc2ef4b), [`c07aa54827922badb6348ed942f73d8d7ebc1d62`](https://github.com/medusajs/medusa/commit/c07aa54827922badb6348ed942f73d8d7ebc1d62), [`0f08725d4c0dc0b65d48e3240e72237027cbd34a`](https://github.com/medusajs/medusa/commit/0f08725d4c0dc0b65d48e3240e72237027cbd34a), [`a85c552b236772253d075279ab4dacbf9cc9041d`](https://github.com/medusajs/medusa/commit/a85c552b236772253d075279ab4dacbf9cc9041d), [`14e630faa1c31d37626068004e3f00acad1fd51d`](https://github.com/medusajs/medusa/commit/14e630faa1c31d37626068004e3f00acad1fd51d), [`ebc8aeea3880dd2531c2536b7e2c762ff7ca2c17`](https://github.com/medusajs/medusa/commit/ebc8aeea3880dd2531c2536b7e2c762ff7ca2c17), [`b957121a5adb45a53ca66202c0845c2dcda77e8a`](https://github.com/medusajs/medusa/commit/b957121a5adb45a53ca66202c0845c2dcda77e8a), [`acaa818b1dfa35ac852a67b7736878a7b7442022`](https://github.com/medusajs/medusa/commit/acaa818b1dfa35ac852a67b7736878a7b7442022), [`94567d12270c11e88a22aa4898075f3a3b746440`](https://github.com/medusajs/medusa/commit/94567d12270c11e88a22aa4898075f3a3b746440), [`a963fd6bf746a1aa73f161f89d441287edb035fe`](https://github.com/medusajs/medusa/commit/a963fd6bf746a1aa73f161f89d441287edb035fe), [`e9d1f84dbfacd35d7787d1af03215a6ae5a176d8`](https://github.com/medusajs/medusa/commit/e9d1f84dbfacd35d7787d1af03215a6ae5a176d8), [`b650b6c9a486f50ac437614ba36c7f42a203a458`](https://github.com/medusajs/medusa/commit/b650b6c9a486f50ac437614ba36c7f42a203a458), [`bda24b9725ac697ec5e8f706b503013e20babf12`](https://github.com/medusajs/medusa/commit/bda24b9725ac697ec5e8f706b503013e20babf12), [`a4c0a845e8b3a7a5acfaacbb0c093cd539ac713b`](https://github.com/medusajs/medusa/commit/a4c0a845e8b3a7a5acfaacbb0c093cd539ac713b), [`c8701e77534f7b615c8b86814f8d5789c0104382`](https://github.com/medusajs/medusa/commit/c8701e77534f7b615c8b86814f8d5789c0104382), [`df8c278d615229436be5b299ebdc76a576695fc3`](https://github.com/medusajs/medusa/commit/df8c278d615229436be5b299ebdc76a576695fc3)]:
  - @medusajs/medusa@2.21.0
  - @medusajs/utils@2.21.0
  - @medusajs/promotion@2.21.0
  - @medusajs/core-flows@2.21.0
  - @medusajs/event-bus-redis@2.21.0
  - @medusajs/fulfillment@2.21.0
  - @medusajs/product@2.21.0
  - @medusajs/loyalty-plugin@2.21.0
  - @medusajs/framework@2.21.0
  - @medusajs/test-utils@2.21.0
  - @medusajs/modules-sdk@2.21.0
  - @medusajs/api-key@2.21.0
  - @medusajs/auth@2.21.0
  - @medusajs/cache-inmemory@2.21.0
  - @medusajs/customer@2.21.0
  - @medusajs/event-bus-local@2.21.0
  - @medusajs/inventory@2.21.0
  - @medusajs/pricing@2.21.0
  - @medusajs/fulfillment-manual@2.21.0
  - @medusajs/region@2.21.0
  - @medusajs/stock-location@2.21.0
  - @medusajs/store@2.21.0
  - @medusajs/tax@2.21.0
  - @medusajs/translation@2.21.0
  - @medusajs/user@2.21.0
  - @medusajs/workflow-engine-inmemory@2.21.0

## 1.1.23

### Patch Changes

- Updated dependencies [[`75c26e85f3bebc0c921064e9aa37987a76cc24ae`](https://github.com/medusajs/medusa/commit/75c26e85f3bebc0c921064e9aa37987a76cc24ae), [`f373c17dd60cb1e7df1d0c70db31d516d2a0cb4f`](https://github.com/medusajs/medusa/commit/f373c17dd60cb1e7df1d0c70db31d516d2a0cb4f), [`f373c17dd60cb1e7df1d0c70db31d516d2a0cb4f`](https://github.com/medusajs/medusa/commit/f373c17dd60cb1e7df1d0c70db31d516d2a0cb4f)]:
  - @medusajs/utils@2.20.1
  - @medusajs/core-flows@2.20.1
  - @medusajs/framework@2.20.1
  - @medusajs/medusa@2.20.1
  - @medusajs/modules-sdk@2.20.1
  - @medusajs/event-bus-redis@2.20.1
  - @medusajs/loyalty-plugin@2.20.1
  - @medusajs/test-utils@2.20.1
  - @medusajs/api-key@2.20.1
  - @medusajs/auth@2.20.1
  - @medusajs/cache-inmemory@2.20.1
  - @medusajs/customer@2.20.1
  - @medusajs/event-bus-local@2.20.1
  - @medusajs/fulfillment@2.20.1
  - @medusajs/inventory@2.20.1
  - @medusajs/pricing@2.20.1
  - @medusajs/product@2.20.1
  - @medusajs/promotion@2.20.1
  - @medusajs/fulfillment-manual@2.20.1
  - @medusajs/region@2.20.1
  - @medusajs/stock-location@2.20.1
  - @medusajs/store@2.20.1
  - @medusajs/tax@2.20.1
  - @medusajs/translation@2.20.1
  - @medusajs/user@2.20.1
  - @medusajs/workflow-engine-inmemory@2.20.1

## 1.1.22

### Patch Changes

- Updated dependencies [[`4857d15bdcaf5a0648e7adc5b0b40312e23b5c02`](https://github.com/medusajs/medusa/commit/4857d15bdcaf5a0648e7adc5b0b40312e23b5c02), [`094b2ed4e1442f67a345269ba32bbc1a26dacf97`](undefined), [`884e8a810d75be52a255d58bfcf01581e738d7d8`](https://github.com/medusajs/medusa/commit/884e8a810d75be52a255d58bfcf01581e738d7d8), [`faa9c0c160cf69d90ca495aac6ad2c1341c62b1c`](https://github.com/medusajs/medusa/commit/faa9c0c160cf69d90ca495aac6ad2c1341c62b1c), [`4857d15bdcaf5a0648e7adc5b0b40312e23b5c02`](https://github.com/medusajs/medusa/commit/4857d15bdcaf5a0648e7adc5b0b40312e23b5c02), [`51c48dcb472c3b232b88337030945b2b651e90f8`](https://github.com/medusajs/medusa/commit/51c48dcb472c3b232b88337030945b2b651e90f8), [`4528357cfe3c3bcf76a20b2ac2fe3637fb649a9d`](https://github.com/medusajs/medusa/commit/4528357cfe3c3bcf76a20b2ac2fe3637fb649a9d), [`c26c1551ac8700061267ac6b8e0ac380e5404d3c`](https://github.com/medusajs/medusa/commit/c26c1551ac8700061267ac6b8e0ac380e5404d3c), [`847612908fdd1c11a4df09ccc2e8ab44d338bb04`](https://github.com/medusajs/medusa/commit/847612908fdd1c11a4df09ccc2e8ab44d338bb04), [`90841150c76acbd31d8e94bd2edd585ccdff1db7`](https://github.com/medusajs/medusa/commit/90841150c76acbd31d8e94bd2edd585ccdff1db7), [`785fd2b8a978201638a4d8d5ae9eea483958c0fb`](https://github.com/medusajs/medusa/commit/785fd2b8a978201638a4d8d5ae9eea483958c0fb), [`0451e065e7ae393e3b6a963894b04c43316eb366`](undefined), [`693310310610cf439fabb73230187028f2755696`](https://github.com/medusajs/medusa/commit/693310310610cf439fabb73230187028f2755696), [`706ce874672c9cd1d8fc0c5429fc0dd24e6910a9`](https://github.com/medusajs/medusa/commit/706ce874672c9cd1d8fc0c5429fc0dd24e6910a9), [`b9f3d12440a7f02ec3b68443934195193e4ecba8`](undefined), [`578a5416ad7d789966d68f1525bc9d55d3a53020`](https://github.com/medusajs/medusa/commit/578a5416ad7d789966d68f1525bc9d55d3a53020), [`3dbc8c91e9618277d178f4339d2f602d3563beb5`](https://github.com/medusajs/medusa/commit/3dbc8c91e9618277d178f4339d2f602d3563beb5), [`4dd4d90f814fb499239b8718a69f7f0dc04ae86a`](https://github.com/medusajs/medusa/commit/4dd4d90f814fb499239b8718a69f7f0dc04ae86a), [`7f5bc532f92cd2cacea4c4750f64bc5b337f6f36`](undefined), [`c1e5a8f63988698df7f92b8f1e75f63ab8fdee64`](https://github.com/medusajs/medusa/commit/c1e5a8f63988698df7f92b8f1e75f63ab8fdee64), [`f7317903600e5b64f06c21c29a73e0e569d2fe3a`](https://github.com/medusajs/medusa/commit/f7317903600e5b64f06c21c29a73e0e569d2fe3a), [`f3b3bd838ed53b6b2e1adead27d6b1006ea6e6e4`](https://github.com/medusajs/medusa/commit/f3b3bd838ed53b6b2e1adead27d6b1006ea6e6e4), [`2a5dd813a7e1d5094cb81f688e2e9e7cc8fd3543`](https://github.com/medusajs/medusa/commit/2a5dd813a7e1d5094cb81f688e2e9e7cc8fd3543), [`184f222fb32b913778ce75fdd61164ca038ec03d`](https://github.com/medusajs/medusa/commit/184f222fb32b913778ce75fdd61164ca038ec03d), [`ac38ab4d7f430498d09e77a8a267a41b1dcf3d19`](undefined), [`7479b07071e51f4fc6a7ddafe2c778e85c6eb61d`](https://github.com/medusajs/medusa/commit/7479b07071e51f4fc6a7ddafe2c778e85c6eb61d), [`6a2fce501f3bcd459c21a67f586c7a15b905ff0f`](https://github.com/medusajs/medusa/commit/6a2fce501f3bcd459c21a67f586c7a15b905ff0f), [`c5d55adb2375d19b8ae3be750e9aca52cf22e964`](https://github.com/medusajs/medusa/commit/c5d55adb2375d19b8ae3be750e9aca52cf22e964), [`2ba41aac170a47c4a6b858531ec9439f2a6cf66e`](undefined), [`5e06e544a296b9033f20f71f11c559f81a0e5739`](https://github.com/medusajs/medusa/commit/5e06e544a296b9033f20f71f11c559f81a0e5739), [`6b2d37e9f132973789b241cd065497e4f7d95fe4`](https://github.com/medusajs/medusa/commit/6b2d37e9f132973789b241cd065497e4f7d95fe4), [`e01b039f256cb8224dd70a99662a49d0e8cf65d1`](https://github.com/medusajs/medusa/commit/e01b039f256cb8224dd70a99662a49d0e8cf65d1)]:
  - @medusajs/medusa@2.20.0
  - @medusajs/loyalty-plugin@2.20.0
  - @medusajs/core-flows@2.20.0
  - @medusajs/utils@2.20.0
  - @medusajs/test-utils@2.20.0
  - @medusajs/framework@2.20.0
  - @medusajs/auth@2.20.0
  - @medusajs/product@2.20.0
  - @medusajs/inventory@2.20.0
  - @medusajs/modules-sdk@2.20.0
  - @medusajs/event-bus-redis@2.20.0
  - @medusajs/api-key@2.20.0
  - @medusajs/customer@2.20.0
  - @medusajs/fulfillment@2.20.0
  - @medusajs/pricing@2.20.0
  - @medusajs/promotion@2.20.0
  - @medusajs/region@2.20.0
  - @medusajs/stock-location@2.20.0
  - @medusajs/store@2.20.0
  - @medusajs/tax@2.20.0
  - @medusajs/translation@2.20.0
  - @medusajs/user@2.20.0
  - @medusajs/workflow-engine-inmemory@2.20.0
  - @medusajs/cache-inmemory@2.20.0
  - @medusajs/event-bus-local@2.20.0
  - @medusajs/fulfillment-manual@2.20.0

## 1.1.21

### Patch Changes

- Updated dependencies [[`0e1ccf49654caefa8305fe91a4c9abd573ca1143`](https://github.com/medusajs/medusa/commit/0e1ccf49654caefa8305fe91a4c9abd573ca1143), [`b31b64270e19a785ee1d396766a0e0c0a37f8354`](https://github.com/medusajs/medusa/commit/b31b64270e19a785ee1d396766a0e0c0a37f8354), [`a42ee0825b07409cab68cd351516c35b74238150`](https://github.com/medusajs/medusa/commit/a42ee0825b07409cab68cd351516c35b74238150), [`a4791af3b2e566684b18e7ea07b086c579ec874f`](https://github.com/medusajs/medusa/commit/a4791af3b2e566684b18e7ea07b086c579ec874f), [`5cc7fdef1893d8c4afac8de8e3cfa32d451e69a5`](https://github.com/medusajs/medusa/commit/5cc7fdef1893d8c4afac8de8e3cfa32d451e69a5), [`be4ccf3f6a5ae40eff1ed55743d3518bdefeb07d`](https://github.com/medusajs/medusa/commit/be4ccf3f6a5ae40eff1ed55743d3518bdefeb07d), [`f2c9d7d3c11507f92142b440a1d90ad74c2a03de`](https://github.com/medusajs/medusa/commit/f2c9d7d3c11507f92142b440a1d90ad74c2a03de), [`e037c71ff11add91583124a600840ce793421fe7`](https://github.com/medusajs/medusa/commit/e037c71ff11add91583124a600840ce793421fe7), [`7a5ef2d1f79b2e278625b686dba0b9cfe53a9cc9`](https://github.com/medusajs/medusa/commit/7a5ef2d1f79b2e278625b686dba0b9cfe53a9cc9), [`aeea1f46bf4947ca36577e950b4c79a1faba8ba1`](https://github.com/medusajs/medusa/commit/aeea1f46bf4947ca36577e950b4c79a1faba8ba1), [`c13aaa96b3968b7f021131529f630b1de7bd6970`](https://github.com/medusajs/medusa/commit/c13aaa96b3968b7f021131529f630b1de7bd6970), [`01f31bc58b1ff729a7326bdf54c65f92e35b0725`](https://github.com/medusajs/medusa/commit/01f31bc58b1ff729a7326bdf54c65f92e35b0725), [`e2b2a5c5c2c51dfc0973b024d4cbb5c6c2f49158`](https://github.com/medusajs/medusa/commit/e2b2a5c5c2c51dfc0973b024d4cbb5c6c2f49158), [`5641bab6ea2d6f0eb7cb9188486656d555ce4d60`](https://github.com/medusajs/medusa/commit/5641bab6ea2d6f0eb7cb9188486656d555ce4d60), [`372a1ab8fa4c8415f1eda294e3c4c5d9dbee4a30`](https://github.com/medusajs/medusa/commit/372a1ab8fa4c8415f1eda294e3c4c5d9dbee4a30), [`18e02fb06f5c925c0b3ebc1943407bf58f83e7b7`](https://github.com/medusajs/medusa/commit/18e02fb06f5c925c0b3ebc1943407bf58f83e7b7), [`941fd67d59b6f506efc18e255b051c4d3ab14f64`](https://github.com/medusajs/medusa/commit/941fd67d59b6f506efc18e255b051c4d3ab14f64), [`5f4d93c374b0ad0b0a31e75de98c7557e0415677`](https://github.com/medusajs/medusa/commit/5f4d93c374b0ad0b0a31e75de98c7557e0415677), [`4f2b8a2b435870a379b029d5e6348a3c06cc4093`](https://github.com/medusajs/medusa/commit/4f2b8a2b435870a379b029d5e6348a3c06cc4093), [`3ff26b6f7f036392ad1a97e67daea6b83c3fee23`](https://github.com/medusajs/medusa/commit/3ff26b6f7f036392ad1a97e67daea6b83c3fee23), [`1fb31df2728659578b2aab697322b80b7501b66b`](https://github.com/medusajs/medusa/commit/1fb31df2728659578b2aab697322b80b7501b66b), [`39fac16bfa77374e3158842f64aeff4031e4f37b`](https://github.com/medusajs/medusa/commit/39fac16bfa77374e3158842f64aeff4031e4f37b), [`5c54d68fd0f4020291deb3746eb21dccf498ca45`](https://github.com/medusajs/medusa/commit/5c54d68fd0f4020291deb3746eb21dccf498ca45), [`5105fec20908cf7bcd7f5f859674acdd8a38b982`](https://github.com/medusajs/medusa/commit/5105fec20908cf7bcd7f5f859674acdd8a38b982), [`5105fec20908cf7bcd7f5f859674acdd8a38b982`](https://github.com/medusajs/medusa/commit/5105fec20908cf7bcd7f5f859674acdd8a38b982), [`5105fec20908cf7bcd7f5f859674acdd8a38b982`](https://github.com/medusajs/medusa/commit/5105fec20908cf7bcd7f5f859674acdd8a38b982), [`9fa4bd9eb941a266c560b35683e8230af33a3352`](https://github.com/medusajs/medusa/commit/9fa4bd9eb941a266c560b35683e8230af33a3352)]:
  - @medusajs/medusa@2.19.0
  - @medusajs/utils@2.19.0
  - @medusajs/core-flows@2.19.0
  - @medusajs/test-utils@2.19.0
  - @medusajs/modules-sdk@2.19.0
  - @medusajs/product@2.19.0
  - @medusajs/framework@2.19.0
  - @medusajs/pricing@2.19.0
  - @medusajs/auth@2.19.0
  - @medusajs/loyalty-plugin@2.19.0
  - @medusajs/fulfillment@2.19.0
  - @medusajs/event-bus-redis@2.19.0
  - @medusajs/api-key@2.19.0
  - @medusajs/customer@2.19.0
  - @medusajs/inventory@2.19.0
  - @medusajs/promotion@2.19.0
  - @medusajs/region@2.19.0
  - @medusajs/stock-location@2.19.0
  - @medusajs/store@2.19.0
  - @medusajs/tax@2.19.0
  - @medusajs/translation@2.19.0
  - @medusajs/user@2.19.0
  - @medusajs/workflow-engine-inmemory@2.19.0
  - @medusajs/cache-inmemory@2.19.0
  - @medusajs/event-bus-local@2.19.0
  - @medusajs/fulfillment-manual@2.19.0

## 1.1.20

### Patch Changes

- Updated dependencies [[`b83aeae9b03e52dedbf3cd37be5f838e23875014`](https://github.com/medusajs/medusa/commit/b83aeae9b03e52dedbf3cd37be5f838e23875014), [`1621e14330fe64a968510991408ace8fdac84ce9`](https://github.com/medusajs/medusa/commit/1621e14330fe64a968510991408ace8fdac84ce9), [`6d1622265c96e2417b64aa69fd867a89522e6b76`](https://github.com/medusajs/medusa/commit/6d1622265c96e2417b64aa69fd867a89522e6b76), [`1359d1bf6237aa058910b805395932cd070d2043`](https://github.com/medusajs/medusa/commit/1359d1bf6237aa058910b805395932cd070d2043), [`04daac9a7639435a89446578b9012ad0a673ac6b`](https://github.com/medusajs/medusa/commit/04daac9a7639435a89446578b9012ad0a673ac6b), [`45646168b9769a306c3783fa605a7109f9df4ee9`](https://github.com/medusajs/medusa/commit/45646168b9769a306c3783fa605a7109f9df4ee9), [`b18d4de91c2c229ba7a03a9d541e1b8de71f52a9`](https://github.com/medusajs/medusa/commit/b18d4de91c2c229ba7a03a9d541e1b8de71f52a9), [`dfdcdd7467ede40e1bb80ce866bfe2c256b8ff86`](https://github.com/medusajs/medusa/commit/dfdcdd7467ede40e1bb80ce866bfe2c256b8ff86), [`3bf2b51b7e140c3a7f45ad9c9a8a6bd4f470ff09`](https://github.com/medusajs/medusa/commit/3bf2b51b7e140c3a7f45ad9c9a8a6bd4f470ff09), [`a48e78b953943efd11204f48890608020f7949e0`](https://github.com/medusajs/medusa/commit/a48e78b953943efd11204f48890608020f7949e0), [`af4ab2f5f7721f8b99c80158c78fba3b5c4db64d`](https://github.com/medusajs/medusa/commit/af4ab2f5f7721f8b99c80158c78fba3b5c4db64d), [`f85473ca88249bed7bfed81b01326a7abc46ac12`](https://github.com/medusajs/medusa/commit/f85473ca88249bed7bfed81b01326a7abc46ac12), [`f0e86a06ada4e43cf61383a65603dab7ef5e8039`](undefined), [`3af18a52c12a2db2933bdb376ed4308ccb0b6519`](https://github.com/medusajs/medusa/commit/3af18a52c12a2db2933bdb376ed4308ccb0b6519), [`83ec164e5e475880603188bdd29991964a8136d1`](undefined), [`d76952b5b0e4b287747a7e08f2cb745510143aae`](https://github.com/medusajs/medusa/commit/d76952b5b0e4b287747a7e08f2cb745510143aae), [`0e7973e2fc3c45da39136cf3f66c90358571ffc5`](https://github.com/medusajs/medusa/commit/0e7973e2fc3c45da39136cf3f66c90358571ffc5), [`d6b2a87da1dbfd065336c80e41cb7c086dc2a340`](https://github.com/medusajs/medusa/commit/d6b2a87da1dbfd065336c80e41cb7c086dc2a340), [`c2fc62507a54f0ab73367d4369c783bbbdccf022`](https://github.com/medusajs/medusa/commit/c2fc62507a54f0ab73367d4369c783bbbdccf022), [`142ad068e7d892a24a6e2cf8c20e143409d27bde`](https://github.com/medusajs/medusa/commit/142ad068e7d892a24a6e2cf8c20e143409d27bde), [`7d7edad6fdf47ae36c06cd5f5b71232c9d51c70b`](https://github.com/medusajs/medusa/commit/7d7edad6fdf47ae36c06cd5f5b71232c9d51c70b), [`8078ac6c62994ebc6d279c2612472086c20ce346`](undefined), [`0731abc3827d729b4999d056034a7c7c84df1ee2`](https://github.com/medusajs/medusa/commit/0731abc3827d729b4999d056034a7c7c84df1ee2), [`7c0f94c207796bc443fd36d3999f1533bba255be`](https://github.com/medusajs/medusa/commit/7c0f94c207796bc443fd36d3999f1533bba255be), [`3382c8189bfc9f44e86123496ef3665e92ac91c9`](https://github.com/medusajs/medusa/commit/3382c8189bfc9f44e86123496ef3665e92ac91c9), [`d6b2a87da1dbfd065336c80e41cb7c086dc2a340`](https://github.com/medusajs/medusa/commit/d6b2a87da1dbfd065336c80e41cb7c086dc2a340), [`09abcfab45f44932450c18de4717a6ab3acc6b0b`](undefined), [`935a14c0098580a2b6ef8af11321e931c8ac80da`](https://github.com/medusajs/medusa/commit/935a14c0098580a2b6ef8af11321e931c8ac80da), [`dea11e3d011a0dd1c95b1fc4ab2292fd07ec4857`](undefined), [`04b19ba7b861447c5f2a944a47f5533ee64e0acf`](https://github.com/medusajs/medusa/commit/04b19ba7b861447c5f2a944a47f5533ee64e0acf), [`e78ef6ce51a00e6b303b654c5046cd1e60c8dc68`](https://github.com/medusajs/medusa/commit/e78ef6ce51a00e6b303b654c5046cd1e60c8dc68), [`99f2ea9c85a64a08c56196ba963db2c8dd0b7923`](https://github.com/medusajs/medusa/commit/99f2ea9c85a64a08c56196ba963db2c8dd0b7923), [`dd5b3ee61ed5e4a8965c39eb34e2141908c664ce`](https://github.com/medusajs/medusa/commit/dd5b3ee61ed5e4a8965c39eb34e2141908c664ce), [`9cd0501b26c401431a11e0d7f4ae6719100b9296`](https://github.com/medusajs/medusa/commit/9cd0501b26c401431a11e0d7f4ae6719100b9296), [`631c2f2311f1931fe4a688d8796a7a81c2191243`](undefined), [`0b678b4c8b3f22d5fa1a63d1cfefd2bb78cdef47`](undefined), [`e329681099bb3d602a8c1f8ec3c0472e1716f45f`](https://github.com/medusajs/medusa/commit/e329681099bb3d602a8c1f8ec3c0472e1716f45f), [`917ddbe0e56b4e739fa828140cd7973d823d1bbd`](undefined), [`6ef16b6fdc6f04b900583a5f2714a863011ed19a`](https://github.com/medusajs/medusa/commit/6ef16b6fdc6f04b900583a5f2714a863011ed19a), [`70c122753875f3cca03ff49b8a0ea9fe2c5e1165`](https://github.com/medusajs/medusa/commit/70c122753875f3cca03ff49b8a0ea9fe2c5e1165), [`cd0aeef37c3d553d6121f7b933e9a06c3a5ae697`](undefined), [`d5c6d183e187a24d5cf6d39bca8d79d72a4f1f71`](https://github.com/medusajs/medusa/commit/d5c6d183e187a24d5cf6d39bca8d79d72a4f1f71), [`d61d8b3e0422344cb7bee091a49ecbe51d7ef50c`](https://github.com/medusajs/medusa/commit/d61d8b3e0422344cb7bee091a49ecbe51d7ef50c), [`ffe9f4c4a98f6ee6a0b26d695f0ffc612cc70e89`](https://github.com/medusajs/medusa/commit/ffe9f4c4a98f6ee6a0b26d695f0ffc612cc70e89), [`812687d1195645a2ae223553c400c9142c91f74c`](undefined), [`a48e78b953943efd11204f48890608020f7949e0`](https://github.com/medusajs/medusa/commit/a48e78b953943efd11204f48890608020f7949e0), [`3a51849b0d9aa754975c6d9654508961ce14f998`](undefined), [`144c47aba88f6e08fb7c99634c9fec8474721b0a`](https://github.com/medusajs/medusa/commit/144c47aba88f6e08fb7c99634c9fec8474721b0a), [`513c01a5a7f587cb52c92677e2379e54bd990361`](https://github.com/medusajs/medusa/commit/513c01a5a7f587cb52c92677e2379e54bd990361)]:
  - @medusajs/utils@2.18.0
  - @medusajs/loyalty-plugin@2.18.0
  - @medusajs/modules-sdk@2.18.0
  - @medusajs/framework@2.18.0
  - @medusajs/medusa@2.18.0
  - @medusajs/core-flows@2.18.0
  - @medusajs/product@2.18.0
  - @medusajs/promotion@2.18.0
  - @medusajs/test-utils@2.18.0
  - @medusajs/pricing@2.18.0
  - @medusajs/event-bus-redis@2.18.0
  - @medusajs/api-key@2.18.0
  - @medusajs/auth@2.18.0
  - @medusajs/cache-inmemory@2.18.0
  - @medusajs/customer@2.18.0
  - @medusajs/event-bus-local@2.18.0
  - @medusajs/fulfillment@2.18.0
  - @medusajs/inventory@2.18.0
  - @medusajs/fulfillment-manual@2.18.0
  - @medusajs/region@2.18.0
  - @medusajs/stock-location@2.18.0
  - @medusajs/store@2.18.0
  - @medusajs/tax@2.18.0
  - @medusajs/translation@2.18.0
  - @medusajs/user@2.18.0
  - @medusajs/workflow-engine-inmemory@2.18.0

## 1.1.19

### Patch Changes

- Updated dependencies [[`cb454a097b6792a06564a7b601489e2cd651e00e`](https://github.com/medusajs/medusa/commit/cb454a097b6792a06564a7b601489e2cd651e00e), [`385819ba1469b4310832a7737060eb23226f135d`](https://github.com/medusajs/medusa/commit/385819ba1469b4310832a7737060eb23226f135d), [`8f2c71222afb2bcd1268438fc5fe9da6a63d7af2`](https://github.com/medusajs/medusa/commit/8f2c71222afb2bcd1268438fc5fe9da6a63d7af2), [`de58ec503bcd82aae3fe576f9a404c36e2525f4c`](https://github.com/medusajs/medusa/commit/de58ec503bcd82aae3fe576f9a404c36e2525f4c), [`b50a9dbaf3eeb29753fa28afbc1b529c44ec5a51`](https://github.com/medusajs/medusa/commit/b50a9dbaf3eeb29753fa28afbc1b529c44ec5a51), [`5296f51121d4796b1757b65852c48e97e0e1e197`](https://github.com/medusajs/medusa/commit/5296f51121d4796b1757b65852c48e97e0e1e197), [`7686adc8637b41879c4551ca422829ad2d63d6a9`](https://github.com/medusajs/medusa/commit/7686adc8637b41879c4551ca422829ad2d63d6a9), [`385819ba1469b4310832a7737060eb23226f135d`](https://github.com/medusajs/medusa/commit/385819ba1469b4310832a7737060eb23226f135d)]:
  - @medusajs/event-bus-redis@2.17.2
  - @medusajs/core-flows@2.17.2
  - @medusajs/utils@2.17.2
  - @medusajs/api-key@2.17.2
  - @medusajs/auth@2.17.2
  - @medusajs/cache-inmemory@2.17.2
  - @medusajs/customer@2.17.2
  - @medusajs/event-bus-local@2.17.2
  - @medusajs/framework@2.17.2
  - @medusajs/fulfillment@2.17.2
  - @medusajs/fulfillment-manual@2.17.2
  - @medusajs/inventory@2.17.2
  - @medusajs/loyalty-plugin@2.17.2
  - @medusajs/medusa@2.17.2
  - @medusajs/modules-sdk@2.17.2
  - @medusajs/pricing@2.17.2
  - @medusajs/product@2.17.2
  - @medusajs/promotion@2.17.2
  - @medusajs/region@2.17.2
  - @medusajs/stock-location@2.17.2
  - @medusajs/store@2.17.2
  - @medusajs/tax@2.17.2
  - @medusajs/test-utils@2.17.2
  - @medusajs/translation@2.17.2
  - @medusajs/user@2.17.2
  - @medusajs/workflow-engine-inmemory@2.17.2

## 1.1.18

### Patch Changes

- Updated dependencies [[`975313f62b22055ddaacf7852f33cf7b0f4af5df`](https://github.com/medusajs/medusa/commit/975313f62b22055ddaacf7852f33cf7b0f4af5df), [`4f5e1cc97f4511f43cf4790af412781dafb2ba86`](https://github.com/medusajs/medusa/commit/4f5e1cc97f4511f43cf4790af412781dafb2ba86)]:
  - @medusajs/workflow-engine-inmemory@2.17.1
  - @medusajs/framework@2.17.1
  - @medusajs/event-bus-local@2.17.1
  - @medusajs/event-bus-redis@2.17.1
  - @medusajs/utils@2.17.1
  - @medusajs/medusa@2.17.1
  - @medusajs/core-flows@2.17.1
  - @medusajs/test-utils@2.17.1
  - @medusajs/api-key@2.17.1
  - @medusajs/auth@2.17.1
  - @medusajs/cache-inmemory@2.17.1
  - @medusajs/customer@2.17.1
  - @medusajs/fulfillment@2.17.1
  - @medusajs/inventory@2.17.1
  - @medusajs/pricing@2.17.1
  - @medusajs/product@2.17.1
  - @medusajs/promotion@2.17.1
  - @medusajs/fulfillment-manual@2.17.1
  - @medusajs/region@2.17.1
  - @medusajs/stock-location@2.17.1
  - @medusajs/store@2.17.1
  - @medusajs/tax@2.17.1
  - @medusajs/translation@2.17.1
  - @medusajs/user@2.17.1
  - @medusajs/loyalty-plugin@2.17.1
  - @medusajs/modules-sdk@2.17.1

## 1.1.17

### Patch Changes

- Updated dependencies [[`f2d563a56b5f70834e113998ad36bcab30824cf8`](https://github.com/medusajs/medusa/commit/f2d563a56b5f70834e113998ad36bcab30824cf8), [`5770fe15c8b63407705cb96d0e77c6f7c76b5219`](https://github.com/medusajs/medusa/commit/5770fe15c8b63407705cb96d0e77c6f7c76b5219), [`57b8e74d0fea8fb0e9dccd76eb6df06f0380071a`](https://github.com/medusajs/medusa/commit/57b8e74d0fea8fb0e9dccd76eb6df06f0380071a), [`6eff86709de4dddc359f35fa84a2462fed85b753`](https://github.com/medusajs/medusa/commit/6eff86709de4dddc359f35fa84a2462fed85b753), [`6eff86709de4dddc359f35fa84a2462fed85b753`](https://github.com/medusajs/medusa/commit/6eff86709de4dddc359f35fa84a2462fed85b753), [`6eff86709de4dddc359f35fa84a2462fed85b753`](https://github.com/medusajs/medusa/commit/6eff86709de4dddc359f35fa84a2462fed85b753), [`06358e3a3b4bebf8b2cf5e6f9227a63b84937fb9`](https://github.com/medusajs/medusa/commit/06358e3a3b4bebf8b2cf5e6f9227a63b84937fb9)]:
  - @medusajs/medusa@2.17.0
  - @medusajs/core-flows@2.17.0
  - @medusajs/framework@2.17.0
  - @medusajs/product@2.17.0
  - @medusajs/utils@2.17.0
  - @medusajs/workflow-engine-inmemory@2.17.0
  - @medusajs/test-utils@2.17.0
  - @medusajs/loyalty-plugin@2.17.0
  - @medusajs/modules-sdk@2.17.0
  - @medusajs/event-bus-redis@2.17.0
  - @medusajs/api-key@2.17.0
  - @medusajs/auth@2.17.0
  - @medusajs/cache-inmemory@2.17.0
  - @medusajs/customer@2.17.0
  - @medusajs/event-bus-local@2.17.0
  - @medusajs/fulfillment@2.17.0
  - @medusajs/inventory@2.17.0
  - @medusajs/pricing@2.17.0
  - @medusajs/promotion@2.17.0
  - @medusajs/fulfillment-manual@2.17.0
  - @medusajs/region@2.17.0
  - @medusajs/stock-location@2.17.0
  - @medusajs/store@2.17.0
  - @medusajs/tax@2.17.0
  - @medusajs/translation@2.17.0
  - @medusajs/user@2.17.0

## 1.1.16

### Patch Changes

- Updated dependencies [[`f2e576f895ae6579dfa4e29b75d8a0a9c9cf9326`](https://github.com/medusajs/medusa/commit/f2e576f895ae6579dfa4e29b75d8a0a9c9cf9326), [`2b7e6782c61af8b38ec9789736f3c708576b2620`](https://github.com/medusajs/medusa/commit/2b7e6782c61af8b38ec9789736f3c708576b2620), [`8a6664d6d445f875f56078fad21fe12a185b9627`](https://github.com/medusajs/medusa/commit/8a6664d6d445f875f56078fad21fe12a185b9627), [`27874782c29890d8eb4c07f3eaafa3c71ebf3949`](undefined), [`7cea59f0c674a49380acb3638cbf86c590461b23`](https://github.com/medusajs/medusa/commit/7cea59f0c674a49380acb3638cbf86c590461b23), [`34450089041ee90ebbeca40ad7977e945a53a7b7`](undefined), [`55be5103e41ffe367400cc9317a3bd6dbaa1e0cf`](undefined), [`46271f2c4f9b4d107a43b588b1082a3e572fbe76`](https://github.com/medusajs/medusa/commit/46271f2c4f9b4d107a43b588b1082a3e572fbe76), [`735e0aa51ef64274257057a59046776af54203f4`](https://github.com/medusajs/medusa/commit/735e0aa51ef64274257057a59046776af54203f4), [`68f7a0e792a90c2edc04f27454178b75fd3b05f4`](https://github.com/medusajs/medusa/commit/68f7a0e792a90c2edc04f27454178b75fd3b05f4), [`dc3e213a3be9d5ae8637863461eab0404bbc0e16`](undefined), [`9f5194267fc5abdece31531af3822b0d05ed1fcc`](undefined), [`8b3b9f7dc97731688e4a5f1c0bb2714e00483bc6`](undefined), [`5cd86b7b0899bb3bace07da3299cc70826afbd64`](https://github.com/medusajs/medusa/commit/5cd86b7b0899bb3bace07da3299cc70826afbd64), [`801dbdb2ae70152aaa5917590885bd36bd44efc4`](undefined), [`beb1b5e6bcbfeda02659cbaa0e04d5dbc1ba64cd`](https://github.com/medusajs/medusa/commit/beb1b5e6bcbfeda02659cbaa0e04d5dbc1ba64cd), [`06b05343b4158e7bb96f8f0fbd7e6836a1818e44`](https://github.com/medusajs/medusa/commit/06b05343b4158e7bb96f8f0fbd7e6836a1818e44), [`e1697b65ff73257939c714dd2c8afdb5efa5e947`](undefined), [`1c5ce279aaf792789be371fae70ca304f710cb73`](undefined), [`46c806036c1f469e949c2da76ae55909c8920bd9`](undefined), [`18474de124868370298addf195e5229ca6792f81`](undefined), [`ab832fcf1e4f51e1469a20aeb8e1ded125bd19c6`](undefined), [`5c20d034de9a0b32189963f20dd3d8e426f0e67b`](https://github.com/medusajs/medusa/commit/5c20d034de9a0b32189963f20dd3d8e426f0e67b), [`30f6d407cfaca510939ad161fbbe74feebb97883`](undefined), [`24ccb4a7dad55e383c2c620b29eb5eceac6fd76b`](https://github.com/medusajs/medusa/commit/24ccb4a7dad55e383c2c620b29eb5eceac6fd76b), [`1344c10503f34e392bd03f733820bcd5a12a2766`](https://github.com/medusajs/medusa/commit/1344c10503f34e392bd03f733820bcd5a12a2766), [`a46961ed421dc69fe991891d02b0f1c66f6180ab`](undefined), [`6dd06189fdcb610e85fe2cd59e96862e6ad474df`](undefined), [`20352f4fa2f31e5b491c8b1b244c407392939fbf`](https://github.com/medusajs/medusa/commit/20352f4fa2f31e5b491c8b1b244c407392939fbf), [`42e54eb549209f0609b0668d822f962676e81bb1`](undefined), [`ffae1bee3fe51c6c5dc68f27ace7b257da2327b4`](undefined), [`90af038c95c835dee5168ffd19cda5182d81b904`](https://github.com/medusajs/medusa/commit/90af038c95c835dee5168ffd19cda5182d81b904), [`13c5dd22802593f5fb5c0a97076a966704aa56c9`](https://github.com/medusajs/medusa/commit/13c5dd22802593f5fb5c0a97076a966704aa56c9), [`14af163eae35be9a204f37c5a87d0b2b59b14054`](undefined), [`740132b7576d937b82e913c1ccf4cfabe56777d6`](https://github.com/medusajs/medusa/commit/740132b7576d937b82e913c1ccf4cfabe56777d6), [`333b08a120dcd40ef1066d05be0c124a8c3b1ff7`](undefined), [`42aa9bf7ec8cf8dede96ce4da13e12e3ef319e90`](undefined), [`66610b87efb112e37b78c7c9536d95070b8d6b11`](https://github.com/medusajs/medusa/commit/66610b87efb112e37b78c7c9536d95070b8d6b11), [`8a27881086307b14bfd1f74f13e2b9db51cc0c03`](undefined), [`3f3b339ea732670de449ee6ace4635523ff44ab0`](https://github.com/medusajs/medusa/commit/3f3b339ea732670de449ee6ace4635523ff44ab0), [`a1fd4d648b923cbd68240dba49f1c46ad0e98f39`](https://github.com/medusajs/medusa/commit/a1fd4d648b923cbd68240dba49f1c46ad0e98f39), [`60d63bd2c0e400f06b985d5275b86c72681e4f62`](https://github.com/medusajs/medusa/commit/60d63bd2c0e400f06b985d5275b86c72681e4f62), [`f58de022857e00d12fa60f55fb80fcc7eff357d8`](undefined), [`af4dc161cf3ca90f68214138212416bc7b54209b`](https://github.com/medusajs/medusa/commit/af4dc161cf3ca90f68214138212416bc7b54209b), [`762195f2329745e9ead1653ea8cdf54120530c96`](undefined)]:
  - @medusajs/loyalty-plugin@2.16.0
  - @medusajs/medusa@2.16.0
  - @medusajs/framework@2.16.0
  - @medusajs/utils@2.16.0
  - @medusajs/core-flows@2.16.0
  - @medusajs/product@2.16.0
  - @medusajs/promotion@2.16.0
  - @medusajs/auth@2.16.0
  - @medusajs/user@2.16.0
  - @medusajs/pricing@2.16.0
  - @medusajs/test-utils@2.16.0
  - @medusajs/api-key@2.16.0
  - @medusajs/cache-inmemory@2.16.0
  - @medusajs/customer@2.16.0
  - @medusajs/event-bus-local@2.16.0
  - @medusajs/event-bus-redis@2.16.0
  - @medusajs/fulfillment@2.16.0
  - @medusajs/inventory@2.16.0
  - @medusajs/fulfillment-manual@2.16.0
  - @medusajs/region@2.16.0
  - @medusajs/stock-location@2.16.0
  - @medusajs/store@2.16.0
  - @medusajs/tax@2.16.0
  - @medusajs/translation@2.16.0
  - @medusajs/workflow-engine-inmemory@2.16.0
  - @medusajs/modules-sdk@2.16.0

## 1.1.15

### Patch Changes

- Updated dependencies [[`ace1822bccbb21afa533665937460140e36aa995`](https://github.com/medusajs/medusa/commit/ace1822bccbb21afa533665937460140e36aa995), [`c8e37903177c2551ec27ba5f881804e351e819c4`](https://github.com/medusajs/medusa/commit/c8e37903177c2551ec27ba5f881804e351e819c4), [`2535bd63f3bf2745034abb11ac38469df6f4a588`](https://github.com/medusajs/medusa/commit/2535bd63f3bf2745034abb11ac38469df6f4a588), [`e6c632ada9ced677e44198f145097422890abc63`](https://github.com/medusajs/medusa/commit/e6c632ada9ced677e44198f145097422890abc63), [`8122633a8b33164a6094f5a39896e356efde1747`](https://github.com/medusajs/medusa/commit/8122633a8b33164a6094f5a39896e356efde1747), [`c7258f2ca2da8c09df430d81121ea8eae7f75cd9`](https://github.com/medusajs/medusa/commit/c7258f2ca2da8c09df430d81121ea8eae7f75cd9), [`538f98da78ae2d741f1182e6ef315ba8efac6911`](https://github.com/medusajs/medusa/commit/538f98da78ae2d741f1182e6ef315ba8efac6911)]:
  - @medusajs/auth@2.15.5
  - @medusajs/core-flows@2.15.5
  - @medusajs/medusa@2.15.5
  - @medusajs/utils@2.15.5
  - @medusajs/framework@2.15.5
  - @medusajs/test-utils@2.15.5
  - @medusajs/modules-sdk@2.15.5
  - @medusajs/event-bus-redis@2.15.5
  - @medusajs/loyalty-plugin@2.15.5
  - @medusajs/api-key@2.15.5
  - @medusajs/cache-inmemory@2.15.5
  - @medusajs/customer@2.15.5
  - @medusajs/event-bus-local@2.15.5
  - @medusajs/fulfillment@2.15.5
  - @medusajs/inventory@2.15.5
  - @medusajs/pricing@2.15.5
  - @medusajs/product@2.15.5
  - @medusajs/promotion@2.15.5
  - @medusajs/fulfillment-manual@2.15.5
  - @medusajs/region@2.15.5
  - @medusajs/stock-location@2.15.5
  - @medusajs/store@2.15.5
  - @medusajs/tax@2.15.5
  - @medusajs/translation@2.15.5
  - @medusajs/user@2.15.5
  - @medusajs/workflow-engine-inmemory@2.15.5

## 1.1.14

### Patch Changes

- Updated dependencies [[`fe9636daba55fd65213fe338ba818ec1429783fa`](https://github.com/medusajs/medusa/commit/fe9636daba55fd65213fe338ba818ec1429783fa), [`08912969605975ca8dafae3bc87776f1ae184e08`](https://github.com/medusajs/medusa/commit/08912969605975ca8dafae3bc87776f1ae184e08), [`94a3ee29d2a2ec441791d671e42deb24108df7f3`](https://github.com/medusajs/medusa/commit/94a3ee29d2a2ec441791d671e42deb24108df7f3)]:
  - @medusajs/core-flows@2.15.4
  - @medusajs/auth@2.15.4
  - @medusajs/medusa@2.15.4
  - @medusajs/test-utils@2.15.4
  - @medusajs/api-key@2.15.4
  - @medusajs/customer@2.15.4
  - @medusajs/fulfillment@2.15.4
  - @medusajs/inventory@2.15.4
  - @medusajs/pricing@2.15.4
  - @medusajs/product@2.15.4
  - @medusajs/promotion@2.15.4
  - @medusajs/region@2.15.4
  - @medusajs/stock-location@2.15.4
  - @medusajs/store@2.15.4
  - @medusajs/tax@2.15.4
  - @medusajs/translation@2.15.4
  - @medusajs/user@2.15.4
  - @medusajs/workflow-engine-inmemory@2.15.4
  - @medusajs/loyalty-plugin@2.15.4
  - @medusajs/framework@2.15.4
  - @medusajs/modules-sdk@2.15.4
  - @medusajs/utils@2.15.4
  - @medusajs/cache-inmemory@2.15.4
  - @medusajs/event-bus-local@2.15.4
  - @medusajs/event-bus-redis@2.15.4
  - @medusajs/fulfillment-manual@2.15.4

## 1.1.13

### Patch Changes

- Updated dependencies [[`3063ea20314843c23ad8077ce5e2f5c01ce2c54c`](https://github.com/medusajs/medusa/commit/3063ea20314843c23ad8077ce5e2f5c01ce2c54c), [`22fa3e373aa5377b79e7f80b006b69b33eac7434`](https://github.com/medusajs/medusa/commit/22fa3e373aa5377b79e7f80b006b69b33eac7434), [`e0b8251bbd04a400dffa635e990e3e587f9f2986`](https://github.com/medusajs/medusa/commit/e0b8251bbd04a400dffa635e990e3e587f9f2986), [`d0f4df0c6307555737a46f54ab7b99dd81c6c75b`](https://github.com/medusajs/medusa/commit/d0f4df0c6307555737a46f54ab7b99dd81c6c75b), [`5d14db303b5192c3459a5aa5302c292286a54ff6`](https://github.com/medusajs/medusa/commit/5d14db303b5192c3459a5aa5302c292286a54ff6), [`0697de72f2e59e9674e8b6489febf72587e3feef`](https://github.com/medusajs/medusa/commit/0697de72f2e59e9674e8b6489febf72587e3feef), [`ad14455d087d045eba3b3197ac37bf66e42d4e64`](https://github.com/medusajs/medusa/commit/ad14455d087d045eba3b3197ac37bf66e42d4e64), [`d36790f6ccc1a8d7fa729027f9e9d75ad8c9d418`](https://github.com/medusajs/medusa/commit/d36790f6ccc1a8d7fa729027f9e9d75ad8c9d418), [`de43962211feb705d27b2f388384e3f3f4b6d466`](https://github.com/medusajs/medusa/commit/de43962211feb705d27b2f388384e3f3f4b6d466)]:
  - @medusajs/utils@2.15.3
  - @medusajs/core-flows@2.15.3
  - @medusajs/test-utils@2.15.3
  - @medusajs/medusa@2.15.3
  - @medusajs/inventory@2.15.3
  - @medusajs/framework@2.15.3
  - @medusajs/modules-sdk@2.15.3
  - @medusajs/event-bus-redis@2.15.3
  - @medusajs/loyalty-plugin@2.15.3
  - @medusajs/api-key@2.15.3
  - @medusajs/auth@2.15.3
  - @medusajs/customer@2.15.3
  - @medusajs/fulfillment@2.15.3
  - @medusajs/pricing@2.15.3
  - @medusajs/product@2.15.3
  - @medusajs/promotion@2.15.3
  - @medusajs/region@2.15.3
  - @medusajs/stock-location@2.15.3
  - @medusajs/store@2.15.3
  - @medusajs/tax@2.15.3
  - @medusajs/translation@2.15.3
  - @medusajs/user@2.15.3
  - @medusajs/workflow-engine-inmemory@2.15.3
  - @medusajs/cache-inmemory@2.15.3
  - @medusajs/event-bus-local@2.15.3
  - @medusajs/fulfillment-manual@2.15.3

## 1.1.12

### Patch Changes

- Updated dependencies [[`9990b69ab76f1a575c6a68875627d16764cc1564`](https://github.com/medusajs/medusa/commit/9990b69ab76f1a575c6a68875627d16764cc1564), [`2b21d15640ae459386b0acea4c83804c6f502b9d`](https://github.com/medusajs/medusa/commit/2b21d15640ae459386b0acea4c83804c6f502b9d), [`5e8fc904fe00d8c89b6615cfbbdbde66531d2337`](https://github.com/medusajs/medusa/commit/5e8fc904fe00d8c89b6615cfbbdbde66531d2337)]:
  - @medusajs/utils@2.15.2
  - @medusajs/framework@2.15.2
  - @medusajs/medusa@2.15.2
  - @medusajs/modules-sdk@2.15.2
  - @medusajs/event-bus-redis@2.15.2
  - @medusajs/core-flows@2.15.2
  - @medusajs/test-utils@2.15.2
  - @medusajs/api-key@2.15.2
  - @medusajs/auth@2.15.2
  - @medusajs/cache-inmemory@2.15.2
  - @medusajs/customer@2.15.2
  - @medusajs/event-bus-local@2.15.2
  - @medusajs/fulfillment@2.15.2
  - @medusajs/inventory@2.15.2
  - @medusajs/pricing@2.15.2
  - @medusajs/product@2.15.2
  - @medusajs/promotion@2.15.2
  - @medusajs/fulfillment-manual@2.15.2
  - @medusajs/region@2.15.2
  - @medusajs/stock-location@2.15.2
  - @medusajs/store@2.15.2
  - @medusajs/tax@2.15.2
  - @medusajs/translation@2.15.2
  - @medusajs/user@2.15.2
  - @medusajs/workflow-engine-inmemory@2.15.2
  - @medusajs/loyalty-plugin@2.15.2

## 1.1.11

### Patch Changes

- Updated dependencies []:
  - @medusajs/medusa@2.15.1
  - @medusajs/test-utils@2.15.1
  - @medusajs/api-key@2.15.1
  - @medusajs/auth@2.15.1
  - @medusajs/customer@2.15.1
  - @medusajs/fulfillment@2.15.1
  - @medusajs/inventory@2.15.1
  - @medusajs/pricing@2.15.1
  - @medusajs/product@2.15.1
  - @medusajs/promotion@2.15.1
  - @medusajs/region@2.15.1
  - @medusajs/stock-location@2.15.1
  - @medusajs/store@2.15.1
  - @medusajs/tax@2.15.1
  - @medusajs/translation@2.15.1
  - @medusajs/user@2.15.1
  - @medusajs/workflow-engine-inmemory@2.15.1
  - @medusajs/loyalty-plugin@2.15.1
  - @medusajs/core-flows@2.15.1
  - @medusajs/framework@2.15.1
  - @medusajs/modules-sdk@2.15.1
  - @medusajs/utils@2.15.1
  - @medusajs/cache-inmemory@2.15.1
  - @medusajs/event-bus-local@2.15.1
  - @medusajs/event-bus-redis@2.15.1
  - @medusajs/fulfillment-manual@2.15.1

## 1.1.10

### Patch Changes

- Updated dependencies [[`b1c4aeea58293e2c2ad0c72d15e9bf45e6168131`](https://github.com/medusajs/medusa/commit/b1c4aeea58293e2c2ad0c72d15e9bf45e6168131), [`7747d0510b24bcce5e68bf32236559d809dabdee`](https://github.com/medusajs/medusa/commit/7747d0510b24bcce5e68bf32236559d809dabdee), [`4a3f9ed2e076713f47d4fb2458dee528b36b864e`](https://github.com/medusajs/medusa/commit/4a3f9ed2e076713f47d4fb2458dee528b36b864e), [`75b23ffcdf5afeedb5321689cbd844342f218846`](https://github.com/medusajs/medusa/commit/75b23ffcdf5afeedb5321689cbd844342f218846), [`5a7b0142367491236167477e613de763f10b7e32`](https://github.com/medusajs/medusa/commit/5a7b0142367491236167477e613de763f10b7e32), [`436f549e326563cc3da4b7b142c12072fb89eed4`](https://github.com/medusajs/medusa/commit/436f549e326563cc3da4b7b142c12072fb89eed4), [`34f326d729aa9e1bafd6ef644ccb47621bf2a14e`](https://github.com/medusajs/medusa/commit/34f326d729aa9e1bafd6ef644ccb47621bf2a14e), [`4715ef174e9945600ef1082ddeb69ca0fdc5eaba`](https://github.com/medusajs/medusa/commit/4715ef174e9945600ef1082ddeb69ca0fdc5eaba), [`8539bc71a554ba0dd6bc48511aa980d93d3f2664`](https://github.com/medusajs/medusa/commit/8539bc71a554ba0dd6bc48511aa980d93d3f2664), [`6d0fd2fb38d56e76580b52d4e6ea74d34db2000e`](https://github.com/medusajs/medusa/commit/6d0fd2fb38d56e76580b52d4e6ea74d34db2000e), [`f57b942b8bbd385f32203965e2f54a3964e812eb`](https://github.com/medusajs/medusa/commit/f57b942b8bbd385f32203965e2f54a3964e812eb), [`667f3e213d847e2a44ba486522f9fb7b36c69e9a`](https://github.com/medusajs/medusa/commit/667f3e213d847e2a44ba486522f9fb7b36c69e9a), [`cd22b7df5120993f2311cf6fecc8f213c383f16b`](https://github.com/medusajs/medusa/commit/cd22b7df5120993f2311cf6fecc8f213c383f16b)]:
  - @medusajs/medusa@2.15.0
  - @medusajs/core-flows@2.15.0
  - @medusajs/utils@2.15.0
  - @medusajs/product@2.15.0
  - @medusajs/pricing@2.15.0
  - @medusajs/test-utils@2.15.0
  - @medusajs/framework@2.15.0
  - @medusajs/modules-sdk@2.15.0
  - @medusajs/event-bus-redis@2.15.0
  - @medusajs/loyalty-plugin@2.15.0
  - @medusajs/api-key@2.15.0
  - @medusajs/auth@2.15.0
  - @medusajs/customer@2.15.0
  - @medusajs/fulfillment@2.15.0
  - @medusajs/inventory@2.15.0
  - @medusajs/promotion@2.15.0
  - @medusajs/region@2.15.0
  - @medusajs/stock-location@2.15.0
  - @medusajs/store@2.15.0
  - @medusajs/tax@2.15.0
  - @medusajs/translation@2.15.0
  - @medusajs/user@2.15.0
  - @medusajs/workflow-engine-inmemory@2.15.0
  - @medusajs/cache-inmemory@2.15.0
  - @medusajs/event-bus-local@2.15.0
  - @medusajs/fulfillment-manual@2.15.0

## 1.1.9

### Patch Changes

- Updated dependencies [[`aa407641ce6ddcd2e27352315b0f7b911a2c0acf`](https://github.com/medusajs/medusa/commit/aa407641ce6ddcd2e27352315b0f7b911a2c0acf), [`d29b9a1d80580d4b5dce926387c465260936e5ec`](https://github.com/medusajs/medusa/commit/d29b9a1d80580d4b5dce926387c465260936e5ec), [`650938944e2b5b6fbe3f044b8ced8d260b6742a0`](https://github.com/medusajs/medusa/commit/650938944e2b5b6fbe3f044b8ced8d260b6742a0), [`cce180c48ed1378847ab191f39adbcbbc325bfda`](https://github.com/medusajs/medusa/commit/cce180c48ed1378847ab191f39adbcbbc325bfda), [`0303d7f30b7c636037c1df496f39aa04c0556248`](https://github.com/medusajs/medusa/commit/0303d7f30b7c636037c1df496f39aa04c0556248), [`be0b8817a1e2e48e1c6c579de6598c6f5e9bf4b0`](https://github.com/medusajs/medusa/commit/be0b8817a1e2e48e1c6c579de6598c6f5e9bf4b0), [`7c659ff3d69c43bd7477bcc8a1c0afd092ea1c23`](https://github.com/medusajs/medusa/commit/7c659ff3d69c43bd7477bcc8a1c0afd092ea1c23), [`243e88510cd7bb4187169ee383519a9be7594854`](https://github.com/medusajs/medusa/commit/243e88510cd7bb4187169ee383519a9be7594854), [`bd162f7a93e326c73b9929918b5bb9e3a458cc77`](https://github.com/medusajs/medusa/commit/bd162f7a93e326c73b9929918b5bb9e3a458cc77), [`a0e57e419cd3e597526460fdbfed7e3e4842aa9b`](https://github.com/medusajs/medusa/commit/a0e57e419cd3e597526460fdbfed7e3e4842aa9b), [`e434f5f117d8a19752ff50b2f1a49a6af7164df1`](https://github.com/medusajs/medusa/commit/e434f5f117d8a19752ff50b2f1a49a6af7164df1)]:
  - @medusajs/medusa@2.14.2
  - @medusajs/pricing@2.14.2
  - @medusajs/framework@2.14.2
  - @medusajs/core-flows@2.14.2
  - @medusajs/loyalty-plugin@2.14.2
  - @medusajs/region@2.14.2
  - @medusajs/test-utils@2.14.2
  - @medusajs/modules-sdk@2.14.2
  - @medusajs/utils@2.14.2
  - @medusajs/event-bus-redis@2.14.2
  - @medusajs/api-key@2.14.2
  - @medusajs/auth@2.14.2
  - @medusajs/cache-inmemory@2.14.2
  - @medusajs/customer@2.14.2
  - @medusajs/event-bus-local@2.14.2
  - @medusajs/fulfillment@2.14.2
  - @medusajs/inventory@2.14.2
  - @medusajs/product@2.14.2
  - @medusajs/promotion@2.14.2
  - @medusajs/fulfillment-manual@2.14.2
  - @medusajs/stock-location@2.14.2
  - @medusajs/store@2.14.2
  - @medusajs/tax@2.14.2
  - @medusajs/translation@2.14.2
  - @medusajs/user@2.14.2
  - @medusajs/workflow-engine-inmemory@2.14.2

## 1.1.8

### Patch Changes

- Updated dependencies [[`9b369cb735c46724b2ca08e2edfdd86ea7bfa314`](https://github.com/medusajs/medusa/commit/9b369cb735c46724b2ca08e2edfdd86ea7bfa314)]:
  - @medusajs/medusa@2.14.1
  - @medusajs/test-utils@2.14.1
  - @medusajs/api-key@2.14.1
  - @medusajs/auth@2.14.1
  - @medusajs/customer@2.14.1
  - @medusajs/fulfillment@2.14.1
  - @medusajs/inventory@2.14.1
  - @medusajs/pricing@2.14.1
  - @medusajs/product@2.14.1
  - @medusajs/promotion@2.14.1
  - @medusajs/region@2.14.1
  - @medusajs/stock-location@2.14.1
  - @medusajs/store@2.14.1
  - @medusajs/tax@2.14.1
  - @medusajs/translation@2.14.1
  - @medusajs/user@2.14.1
  - @medusajs/workflow-engine-inmemory@2.14.1
  - @medusajs/loyalty-plugin@2.14.1
  - @medusajs/core-flows@2.14.1
  - @medusajs/framework@2.14.1
  - @medusajs/modules-sdk@2.14.1
  - @medusajs/utils@2.14.1
  - @medusajs/cache-inmemory@2.14.1
  - @medusajs/event-bus-local@2.14.1
  - @medusajs/event-bus-redis@2.14.1
  - @medusajs/fulfillment-manual@2.14.1

## 1.1.7

### Patch Changes

- [#14826](https://github.com/medusajs/medusa/pull/14826) [`923a869a7d462c2e0399619ac2b35c16132e079c`](https://github.com/medusajs/medusa/commit/923a869a7d462c2e0399619ac2b35c16132e079c) Thanks [@asgerjensen](https://github.com/asgerjensen)! - chore(medusa,types): allow filtering on variant sku/barcode/ean/upc on both /store and /admin apis

- [#14855](https://github.com/medusajs/medusa/pull/14855) [`b94f7ae1f5f66dfca7f73c7ee8d53afdcbf26ee5`](https://github.com/medusajs/medusa/commit/b94f7ae1f5f66dfca7f73c7ee8d53afdcbf26ee5) Thanks [@asgerjensen](https://github.com/asgerjensen)! - feat(product,medusa,types): add external id to product tags, collections and types

- [#14799](https://github.com/medusajs/medusa/pull/14799) [`a92ca32b93eaf7f5a8e1fc8b2bbb01763867f6c1`](https://github.com/medusajs/medusa/commit/a92ca32b93eaf7f5a8e1fc8b2bbb01763867f6c1) Thanks [@asgerjensen](https://github.com/asgerjensen)! - add external_id to product-category

- Updated dependencies [[`1a28af3d7412466022dc941c425a06c762a43d75`](https://github.com/medusajs/medusa/commit/1a28af3d7412466022dc941c425a06c762a43d75), [`b4558c61a4a157fff105eb6f3e9b3ebf8dea7799`](https://github.com/medusajs/medusa/commit/b4558c61a4a157fff105eb6f3e9b3ebf8dea7799), [`3ae4162e0f027c4b7035028e183c07c9936fd0c1`](https://github.com/medusajs/medusa/commit/3ae4162e0f027c4b7035028e183c07c9936fd0c1), [`d708f879e27ced4acc1793e2e13d60ff30ccf0f9`](https://github.com/medusajs/medusa/commit/d708f879e27ced4acc1793e2e13d60ff30ccf0f9), [`d3a4ec0123d0bfb6910ff38d6d74ece00083e819`](https://github.com/medusajs/medusa/commit/d3a4ec0123d0bfb6910ff38d6d74ece00083e819), [`0929b8d192833e10b6b91795f1ffc478938c3fb7`](https://github.com/medusajs/medusa/commit/0929b8d192833e10b6b91795f1ffc478938c3fb7), [`15085e1adb9c50743ca07d2da94f23cc09b6852a`](https://github.com/medusajs/medusa/commit/15085e1adb9c50743ca07d2da94f23cc09b6852a), [`843dbfe7c8f27b732486c7a8da7b6d63f2fdf967`](https://github.com/medusajs/medusa/commit/843dbfe7c8f27b732486c7a8da7b6d63f2fdf967), [`834553b311aa66b2f2f85131398badb0d6b55b13`](https://github.com/medusajs/medusa/commit/834553b311aa66b2f2f85131398badb0d6b55b13), [`67499a8aa6b3b53cbdecb5be9fcc358b4e466696`](https://github.com/medusajs/medusa/commit/67499a8aa6b3b53cbdecb5be9fcc358b4e466696), [`e489aebaf301ea2eb2834449af65bc3da7f7465a`](https://github.com/medusajs/medusa/commit/e489aebaf301ea2eb2834449af65bc3da7f7465a), [`965adfe2fc15a024270ac384f819479e8b274e10`](https://github.com/medusajs/medusa/commit/965adfe2fc15a024270ac384f819479e8b274e10), [`9e145bfb27cb5792f7b8d1331f2b076fb00355d9`](https://github.com/medusajs/medusa/commit/9e145bfb27cb5792f7b8d1331f2b076fb00355d9), [`2ee9b39b6793d1352cc27a974e964049a053c9c0`](https://github.com/medusajs/medusa/commit/2ee9b39b6793d1352cc27a974e964049a053c9c0), [`5cabac3faea253d881f5f4910bc0aaec713bed4e`](https://github.com/medusajs/medusa/commit/5cabac3faea253d881f5f4910bc0aaec713bed4e), [`dd29f6f3201f275586746902953004011159b1e8`](https://github.com/medusajs/medusa/commit/dd29f6f3201f275586746902953004011159b1e8), [`41dc2a8a6fea39a158d93a3b0e1c9793e746ca3c`](https://github.com/medusajs/medusa/commit/41dc2a8a6fea39a158d93a3b0e1c9793e746ca3c), [`5ef7953ec3bbcdafe452db813e5c5b07a1c1f0ba`](https://github.com/medusajs/medusa/commit/5ef7953ec3bbcdafe452db813e5c5b07a1c1f0ba), [`7b438f244d94c35f0042f39e20e6e43d3f824d2b`](https://github.com/medusajs/medusa/commit/7b438f244d94c35f0042f39e20e6e43d3f824d2b), [`3717530011fc3adf1e7d2c57db41c833ba83c7fb`](https://github.com/medusajs/medusa/commit/3717530011fc3adf1e7d2c57db41c833ba83c7fb), [`923a869a7d462c2e0399619ac2b35c16132e079c`](https://github.com/medusajs/medusa/commit/923a869a7d462c2e0399619ac2b35c16132e079c), [`9e1e7082c3437ee2ae01d6752b624d4b4d905604`](https://github.com/medusajs/medusa/commit/9e1e7082c3437ee2ae01d6752b624d4b4d905604), [`d9af2f5efba391f612ea9f6183702756c3fa4732`](https://github.com/medusajs/medusa/commit/d9af2f5efba391f612ea9f6183702756c3fa4732), [`c18e1f49a88c3b6a426171afeaf6f7691e8c5bde`](https://github.com/medusajs/medusa/commit/c18e1f49a88c3b6a426171afeaf6f7691e8c5bde), [`b94f7ae1f5f66dfca7f73c7ee8d53afdcbf26ee5`](https://github.com/medusajs/medusa/commit/b94f7ae1f5f66dfca7f73c7ee8d53afdcbf26ee5), [`d9af2f5efba391f612ea9f6183702756c3fa4732`](https://github.com/medusajs/medusa/commit/d9af2f5efba391f612ea9f6183702756c3fa4732), [`2045c776de29534b86e9c4e0438f7d29f9b79e91`](https://github.com/medusajs/medusa/commit/2045c776de29534b86e9c4e0438f7d29f9b79e91), [`32533eb829d904d4c1a89c841f06d9c209460ac7`](https://github.com/medusajs/medusa/commit/32533eb829d904d4c1a89c841f06d9c209460ac7), [`a92ca32b93eaf7f5a8e1fc8b2bbb01763867f6c1`](https://github.com/medusajs/medusa/commit/a92ca32b93eaf7f5a8e1fc8b2bbb01763867f6c1)]:
  - @medusajs/core-flows@2.14.0
  - @medusajs/medusa@2.14.0
  - @medusajs/loyalty-plugin@2.14.0
  - @medusajs/framework@2.14.0
  - @medusajs/utils@2.14.0
  - @medusajs/promotion@2.14.0
  - @medusajs/pricing@2.14.0
  - @medusajs/region@2.14.0
  - @medusajs/store@2.14.0
  - @medusajs/workflow-engine-inmemory@2.14.0
  - @medusajs/stock-location@2.14.0
  - @medusajs/fulfillment@2.14.0
  - @medusajs/inventory@2.14.0
  - @medusajs/product@2.14.0
  - @medusajs/test-utils@2.14.0
  - @medusajs/modules-sdk@2.14.0
  - @medusajs/event-bus-redis@2.14.0
  - @medusajs/api-key@2.14.0
  - @medusajs/auth@2.14.0
  - @medusajs/cache-inmemory@2.14.0
  - @medusajs/customer@2.14.0
  - @medusajs/event-bus-local@2.14.0
  - @medusajs/fulfillment-manual@2.14.0
  - @medusajs/tax@2.14.0
  - @medusajs/translation@2.14.0
  - @medusajs/user@2.14.0

## 1.1.6

### Patch Changes

- Updated dependencies [[`5b655f6d7c24323bd84dc1b684938725873a33ac`](https://github.com/medusajs/medusa/commit/5b655f6d7c24323bd84dc1b684938725873a33ac), [`19839a44d6551038890c41e02cdff7cf0b45e268`](https://github.com/medusajs/medusa/commit/19839a44d6551038890c41e02cdff7cf0b45e268), [`2b0cd5ff0ce00bf1de1d99632f1bda4073ac035d`](https://github.com/medusajs/medusa/commit/2b0cd5ff0ce00bf1de1d99632f1bda4073ac035d), [`62e0760a2ad032c9f7ef219968d667193bf3c4a1`](https://github.com/medusajs/medusa/commit/62e0760a2ad032c9f7ef219968d667193bf3c4a1)]:
  - @medusajs/medusa@2.13.6
  - @medusajs/core-flows@2.13.6
  - @medusajs/framework@2.13.6
  - @medusajs/utils@2.13.6
  - @medusajs/modules-sdk@2.13.6
  - @medusajs/event-bus-redis@2.13.6
  - @medusajs/test-utils@2.13.6
  - @medusajs/api-key@2.13.6
  - @medusajs/auth@2.13.6
  - @medusajs/cache-inmemory@2.13.6
  - @medusajs/customer@2.13.6
  - @medusajs/event-bus-local@2.13.6
  - @medusajs/fulfillment@2.13.6
  - @medusajs/inventory@2.13.6
  - @medusajs/pricing@2.13.6
  - @medusajs/product@2.13.6
  - @medusajs/promotion@2.13.6
  - @medusajs/fulfillment-manual@2.13.6
  - @medusajs/region@2.13.6
  - @medusajs/stock-location@2.13.6
  - @medusajs/store@2.13.6
  - @medusajs/tax@2.13.6
  - @medusajs/translation@2.13.6
  - @medusajs/user@2.13.6
  - @medusajs/workflow-engine-inmemory@2.13.6

## 1.1.5

### Patch Changes

- Updated dependencies [[`4eee16b932f4b532f81db2739194ed5d2b47f3ea`](https://github.com/medusajs/medusa/commit/4eee16b932f4b532f81db2739194ed5d2b47f3ea), [`f01da61c0d973d399bb6c3693bd06b01ee557df6`](https://github.com/medusajs/medusa/commit/f01da61c0d973d399bb6c3693bd06b01ee557df6), [`991e61fbda7d6096e2ce1b4f713cf55aee2e9404`](https://github.com/medusajs/medusa/commit/991e61fbda7d6096e2ce1b4f713cf55aee2e9404)]:
  - @medusajs/utils@2.13.5
  - @medusajs/core-flows@2.13.5
  - @medusajs/medusa@2.13.5
  - @medusajs/framework@2.13.5
  - @medusajs/modules-sdk@2.13.5
  - @medusajs/event-bus-redis@2.13.5
  - @medusajs/test-utils@2.13.5
  - @medusajs/api-key@2.13.5
  - @medusajs/auth@2.13.5
  - @medusajs/cache-inmemory@2.13.5
  - @medusajs/customer@2.13.5
  - @medusajs/event-bus-local@2.13.5
  - @medusajs/fulfillment@2.13.5
  - @medusajs/inventory@2.13.5
  - @medusajs/pricing@2.13.5
  - @medusajs/product@2.13.5
  - @medusajs/promotion@2.13.5
  - @medusajs/fulfillment-manual@2.13.5
  - @medusajs/region@2.13.5
  - @medusajs/stock-location@2.13.5
  - @medusajs/store@2.13.5
  - @medusajs/tax@2.13.5
  - @medusajs/translation@2.13.5
  - @medusajs/user@2.13.5
  - @medusajs/workflow-engine-inmemory@2.13.5

## 1.1.4

### Patch Changes

- Updated dependencies [[`4b21cc6b8564740818e7f51a42cae86cf86e7331`](https://github.com/medusajs/medusa/commit/4b21cc6b8564740818e7f51a42cae86cf86e7331), [`fea64dd5d70a5e5fe4e1ea201bbe8a4329ce8703`](https://github.com/medusajs/medusa/commit/fea64dd5d70a5e5fe4e1ea201bbe8a4329ce8703), [`d07f70750362e6c78298aba673de4c9db96d3ad6`](https://github.com/medusajs/medusa/commit/d07f70750362e6c78298aba673de4c9db96d3ad6)]:
  - @medusajs/medusa@2.13.4
  - @medusajs/core-flows@2.13.4
  - @medusajs/test-utils@2.13.4
  - @medusajs/api-key@2.13.4
  - @medusajs/auth@2.13.4
  - @medusajs/customer@2.13.4
  - @medusajs/fulfillment@2.13.4
  - @medusajs/inventory@2.13.4
  - @medusajs/pricing@2.13.4
  - @medusajs/product@2.13.4
  - @medusajs/promotion@2.13.4
  - @medusajs/region@2.13.4
  - @medusajs/stock-location@2.13.4
  - @medusajs/store@2.13.4
  - @medusajs/tax@2.13.4
  - @medusajs/translation@2.13.4
  - @medusajs/user@2.13.4
  - @medusajs/workflow-engine-inmemory@2.13.4
  - @medusajs/framework@2.13.4
  - @medusajs/modules-sdk@2.13.4
  - @medusajs/utils@2.13.4
  - @medusajs/cache-inmemory@2.13.4
  - @medusajs/event-bus-local@2.13.4
  - @medusajs/event-bus-redis@2.13.4
  - @medusajs/fulfillment-manual@2.13.4

## 1.1.3

### Patch Changes

- [#14802](https://github.com/medusajs/medusa/pull/14802) [`9fecbd2b0487b10736879507cf11ed426d9523d5`](https://github.com/medusajs/medusa/commit/9fecbd2b0487b10736879507cf11ed426d9523d5) Thanks [@asgerjensen](https://github.com/asgerjensen)! - chore(types): add external_id to product list params type

- Updated dependencies [[`dbaae9630d26a0806751d5614beadef3e0b4bf07`](https://github.com/medusajs/medusa/commit/dbaae9630d26a0806751d5614beadef3e0b4bf07), [`5ccd523b41efaae2f2aaa6d5833b5ce88558d37b`](https://github.com/medusajs/medusa/commit/5ccd523b41efaae2f2aaa6d5833b5ce88558d37b)]:
  - @medusajs/framework@2.13.3
  - @medusajs/core-flows@2.13.3
  - @medusajs/medusa@2.13.3
  - @medusajs/test-utils@2.13.3
  - @medusajs/api-key@2.13.3
  - @medusajs/auth@2.13.3
  - @medusajs/cache-inmemory@2.13.3
  - @medusajs/customer@2.13.3
  - @medusajs/event-bus-local@2.13.3
  - @medusajs/event-bus-redis@2.13.3
  - @medusajs/fulfillment@2.13.3
  - @medusajs/inventory@2.13.3
  - @medusajs/pricing@2.13.3
  - @medusajs/product@2.13.3
  - @medusajs/promotion@2.13.3
  - @medusajs/fulfillment-manual@2.13.3
  - @medusajs/region@2.13.3
  - @medusajs/stock-location@2.13.3
  - @medusajs/store@2.13.3
  - @medusajs/tax@2.13.3
  - @medusajs/translation@2.13.3
  - @medusajs/user@2.13.3
  - @medusajs/workflow-engine-inmemory@2.13.3
  - @medusajs/modules-sdk@2.13.3
  - @medusajs/utils@2.13.3

## 1.1.2

### Patch Changes

- Updated dependencies [[`05262c0197bcc3c9cec89a3d95863916dba47af3`](https://github.com/medusajs/medusa/commit/05262c0197bcc3c9cec89a3d95863916dba47af3), [`f37f029799cad7ee0337aeab625df5e272de2363`](https://github.com/medusajs/medusa/commit/f37f029799cad7ee0337aeab625df5e272de2363), [`d2ce360875bafc3fc0c367384b9b631e77130726`](https://github.com/medusajs/medusa/commit/d2ce360875bafc3fc0c367384b9b631e77130726), [`09a80ab97aad62b65320c745899eb8517d256b40`](https://github.com/medusajs/medusa/commit/09a80ab97aad62b65320c745899eb8517d256b40), [`29d3dee13700d36a70aa55b8f2a01a5cbc0b42d0`](https://github.com/medusajs/medusa/commit/29d3dee13700d36a70aa55b8f2a01a5cbc0b42d0), [`42322f44eaaf997e9ab7af2ca1e8621a08a8ca01`](https://github.com/medusajs/medusa/commit/42322f44eaaf997e9ab7af2ca1e8621a08a8ca01), [`d0e6f710c3f8305b58ac39131a125274987cae05`](https://github.com/medusajs/medusa/commit/d0e6f710c3f8305b58ac39131a125274987cae05), [`7aca778ae56069371f5d26a757d3b2276d524776`](https://github.com/medusajs/medusa/commit/7aca778ae56069371f5d26a757d3b2276d524776), [`074a3ea05f2b86ce72a5e668a7616768e81293dd`](https://github.com/medusajs/medusa/commit/074a3ea05f2b86ce72a5e668a7616768e81293dd), [`7a27e8ad8d7771eeecd1fb648a458f56abab71f9`](https://github.com/medusajs/medusa/commit/7a27e8ad8d7771eeecd1fb648a458f56abab71f9), [`77d899e135ed75668ca7d7b01a8ed4f0c1fe0ac8`](https://github.com/medusajs/medusa/commit/77d899e135ed75668ca7d7b01a8ed4f0c1fe0ac8), [`1b5e5739b1d553d230b5602092f4c809479cf572`](https://github.com/medusajs/medusa/commit/1b5e5739b1d553d230b5602092f4c809479cf572), [`dc2b87810254ccabd382ececca0ae771cb9e64be`](https://github.com/medusajs/medusa/commit/dc2b87810254ccabd382ececca0ae771cb9e64be), [`fe529f214a789b7e94fd0438c631d9f6b5cf5290`](https://github.com/medusajs/medusa/commit/fe529f214a789b7e94fd0438c631d9f6b5cf5290), [`63b7d5f1bee265959db73236c509dc7c9d0c1525`](https://github.com/medusajs/medusa/commit/63b7d5f1bee265959db73236c509dc7c9d0c1525), [`2b795b6cc1ca1b0787f014784c9cbf06d6ab6e96`](https://github.com/medusajs/medusa/commit/2b795b6cc1ca1b0787f014784c9cbf06d6ab6e96)]:
  - @medusajs/core-flows@2.13.2
  - @medusajs/medusa@2.13.2
  - @medusajs/utils@2.13.2
  - @medusajs/framework@2.13.2
  - @medusajs/modules-sdk@2.13.2
  - @medusajs/event-bus-redis@2.13.2
  - @medusajs/test-utils@2.13.2
  - @medusajs/api-key@2.13.2
  - @medusajs/auth@2.13.2
  - @medusajs/cache-inmemory@2.13.2
  - @medusajs/customer@2.13.2
  - @medusajs/event-bus-local@2.13.2
  - @medusajs/fulfillment@2.13.2
  - @medusajs/inventory@2.13.2
  - @medusajs/pricing@2.13.2
  - @medusajs/product@2.13.2
  - @medusajs/promotion@2.13.2
  - @medusajs/fulfillment-manual@2.13.2
  - @medusajs/region@2.13.2
  - @medusajs/stock-location@2.13.2
  - @medusajs/store@2.13.2
  - @medusajs/tax@2.13.2
  - @medusajs/translation@2.13.2
  - @medusajs/user@2.13.2
  - @medusajs/workflow-engine-inmemory@2.13.2

## 1.1.1

### Patch Changes

- Updated dependencies [[`de08ea732b599374a071c016fa8af2e4f3e31075`](https://github.com/medusajs/medusa/commit/de08ea732b599374a071c016fa8af2e4f3e31075), [`2e2fad6c62a51373f97adcd06941f9182657d9d0`](https://github.com/medusajs/medusa/commit/2e2fad6c62a51373f97adcd06941f9182657d9d0)]:
  - @medusajs/medusa@2.13.1
  - @medusajs/core-flows@2.13.1
  - @medusajs/test-utils@2.13.1
  - @medusajs/api-key@2.13.1
  - @medusajs/auth@2.13.1
  - @medusajs/customer@2.13.1
  - @medusajs/fulfillment@2.13.1
  - @medusajs/inventory@2.13.1
  - @medusajs/pricing@2.13.1
  - @medusajs/product@2.13.1
  - @medusajs/promotion@2.13.1
  - @medusajs/region@2.13.1
  - @medusajs/stock-location@2.13.1
  - @medusajs/store@2.13.1
  - @medusajs/tax@2.13.1
  - @medusajs/translation@2.13.1
  - @medusajs/user@2.13.1
  - @medusajs/workflow-engine-inmemory@2.13.1
  - @medusajs/framework@2.13.1
  - @medusajs/modules-sdk@2.13.1
  - @medusajs/utils@2.13.1
  - @medusajs/cache-inmemory@2.13.1
  - @medusajs/event-bus-local@2.13.1
  - @medusajs/event-bus-redis@2.13.1
  - @medusajs/fulfillment-manual@2.13.1

## 1.1.0

### Minor Changes

- [`a31e72c31c5235240cead2d04e39e5927688eec7`](https://github.com/medusajs/medusa/commit/a31e72c31c5235240cead2d04e39e5927688eec7) Thanks [@olivermrbl](https://github.com/olivermrbl)! - chore: Minor bump

### Patch Changes

- Updated dependencies [[`a31e72c31c5235240cead2d04e39e5927688eec7`](https://github.com/medusajs/medusa/commit/a31e72c31c5235240cead2d04e39e5927688eec7), [`4a33c44f79808a3b5b907e2b053427d2ba6d7015`](https://github.com/medusajs/medusa/commit/4a33c44f79808a3b5b907e2b053427d2ba6d7015)]:
  - @medusajs/core-flows@2.13.0
  - @medusajs/framework@2.13.0
  - @medusajs/modules-sdk@2.13.0
  - @medusajs/utils@2.13.0
  - @medusajs/medusa@2.13.0
  - @medusajs/test-utils@2.13.0
  - @medusajs/api-key@2.13.0
  - @medusajs/auth@2.13.0
  - @medusajs/cache-inmemory@2.13.0
  - @medusajs/customer@2.13.0
  - @medusajs/event-bus-local@2.13.0
  - @medusajs/event-bus-redis@2.13.0
  - @medusajs/fulfillment@2.13.0
  - @medusajs/inventory@2.13.0
  - @medusajs/pricing@2.13.0
  - @medusajs/product@2.13.0
  - @medusajs/promotion@2.13.0
  - @medusajs/fulfillment-manual@2.13.0
  - @medusajs/region@2.13.0
  - @medusajs/stock-location@2.13.0
  - @medusajs/store@2.13.0
  - @medusajs/tax@2.13.0
  - @medusajs/translation@2.13.0
  - @medusajs/user@2.13.0
  - @medusajs/workflow-engine-inmemory@2.13.0

## 1.0.36

### Patch Changes

- Updated dependencies [[`13476988763368b3b333fa5bc3f613e8eb174fdf`](https://github.com/medusajs/medusa/commit/13476988763368b3b333fa5bc3f613e8eb174fdf), [`514cc329f8fccd05a9497bf03fb27ba2de0265f4`](https://github.com/medusajs/medusa/commit/514cc329f8fccd05a9497bf03fb27ba2de0265f4), [`55d2a704700433c34edd0f7f10dfd042d2f9333a`](https://github.com/medusajs/medusa/commit/55d2a704700433c34edd0f7f10dfd042d2f9333a), [`e91ce2ee4b0d15948d4021b2d74c1c9744ef0ae2`](https://github.com/medusajs/medusa/commit/e91ce2ee4b0d15948d4021b2d74c1c9744ef0ae2), [`dfb27a638d913916ee534ecb0a06ae30f6f8a9de`](https://github.com/medusajs/medusa/commit/dfb27a638d913916ee534ecb0a06ae30f6f8a9de), [`a9b5797e2de093e26286808876262b724e26671a`](https://github.com/medusajs/medusa/commit/a9b5797e2de093e26286808876262b724e26671a), [`d60ea7268a00f386f803f0f9e6ffeec4bced50bf`](https://github.com/medusajs/medusa/commit/d60ea7268a00f386f803f0f9e6ffeec4bced50bf), [`39b9f84affcdda267bca0ee486825daca2e4a896`](https://github.com/medusajs/medusa/commit/39b9f84affcdda267bca0ee486825daca2e4a896), [`8890f284705a4843a57a3800820208f593689a2a`](https://github.com/medusajs/medusa/commit/8890f284705a4843a57a3800820208f593689a2a), [`41e1d5e5066719569d4f639415d3d1fdae1ddc0b`](https://github.com/medusajs/medusa/commit/41e1d5e5066719569d4f639415d3d1fdae1ddc0b), [`733026f96c23f01d1ceb2fb09f88aa2b9bb65841`](https://github.com/medusajs/medusa/commit/733026f96c23f01d1ceb2fb09f88aa2b9bb65841), [`cec8b8e428131d4743d6da98cd5fa0974b8ab9e1`](https://github.com/medusajs/medusa/commit/cec8b8e428131d4743d6da98cd5fa0974b8ab9e1), [`28fae96ceed68e2c15c3f27316c5b8601f06c478`](https://github.com/medusajs/medusa/commit/28fae96ceed68e2c15c3f27316c5b8601f06c478), [`cbc9f3d059a65cc5ee26595e5cbccf7f05781e41`](https://github.com/medusajs/medusa/commit/cbc9f3d059a65cc5ee26595e5cbccf7f05781e41), [`7307a5e63fdf8ed6f0ff201a0383f0a0bbfc7002`](https://github.com/medusajs/medusa/commit/7307a5e63fdf8ed6f0ff201a0383f0a0bbfc7002), [`b615b71a8e4e273018a09528a8b61116fca6de8b`](https://github.com/medusajs/medusa/commit/b615b71a8e4e273018a09528a8b61116fca6de8b), [`95e9dfdcaf008b86e2ed3d1ad273b369776bc90e`](https://github.com/medusajs/medusa/commit/95e9dfdcaf008b86e2ed3d1ad273b369776bc90e), [`3df466dadde91b24f52504097c07e1ced4b2b8ff`](https://github.com/medusajs/medusa/commit/3df466dadde91b24f52504097c07e1ced4b2b8ff), [`89e6e3e5cbe96f1f64e2cdb33cc2e0d6a221f7a2`](https://github.com/medusajs/medusa/commit/89e6e3e5cbe96f1f64e2cdb33cc2e0d6a221f7a2), [`1ca3516a5cbb059ad79fe483cd8e1d6a7ebca23b`](https://github.com/medusajs/medusa/commit/1ca3516a5cbb059ad79fe483cd8e1d6a7ebca23b)]:
  - @medusajs/event-bus-redis@2.12.6
  - @medusajs/framework@2.12.6
  - @medusajs/utils@2.12.6
  - @medusajs/translation@2.12.6
  - @medusajs/core-flows@2.12.6
  - @medusajs/medusa@2.12.6
  - @medusajs/fulfillment@2.12.6
  - @medusajs/customer@2.12.6
  - @medusajs/product@2.12.6
  - @medusajs/region@2.12.6
  - @medusajs/tax@2.12.6
  - @medusajs/test-utils@2.12.6
  - @medusajs/api-key@2.12.6
  - @medusajs/auth@2.12.6
  - @medusajs/cache-inmemory@2.12.6
  - @medusajs/event-bus-local@2.12.6
  - @medusajs/inventory@2.12.6
  - @medusajs/pricing@2.12.6
  - @medusajs/promotion@2.12.6
  - @medusajs/fulfillment-manual@2.12.6
  - @medusajs/stock-location@2.12.6
  - @medusajs/store@2.12.6
  - @medusajs/user@2.12.6
  - @medusajs/workflow-engine-inmemory@2.12.6
  - @medusajs/modules-sdk@2.12.6

## 1.0.35

### Patch Changes

- Updated dependencies [[`bb599a26deed6d5b98e6ce6308c447dca5b90f10`](https://github.com/medusajs/medusa/commit/bb599a26deed6d5b98e6ce6308c447dca5b90f10), [`08c55e703573f3c11532228d2c626f7b7f16228f`](https://github.com/medusajs/medusa/commit/08c55e703573f3c11532228d2c626f7b7f16228f), [`568742826fae7240b33e6cc7356a12c3715d05b1`](https://github.com/medusajs/medusa/commit/568742826fae7240b33e6cc7356a12c3715d05b1), [`233ec261be200fac83002415aa7c0df082339a3f`](https://github.com/medusajs/medusa/commit/233ec261be200fac83002415aa7c0df082339a3f)]:
  - @medusajs/modules-sdk@2.12.5
  - @medusajs/utils@2.12.5
  - @medusajs/auth@2.12.5
  - @medusajs/event-bus-redis@2.12.5
  - @medusajs/medusa@2.12.5
  - @medusajs/framework@2.12.5
  - @medusajs/test-utils@2.12.5
  - @medusajs/core-flows@2.12.5
  - @medusajs/api-key@2.12.5
  - @medusajs/cache-inmemory@2.12.5
  - @medusajs/customer@2.12.5
  - @medusajs/event-bus-local@2.12.5
  - @medusajs/fulfillment@2.12.5
  - @medusajs/inventory@2.12.5
  - @medusajs/pricing@2.12.5
  - @medusajs/product@2.12.5
  - @medusajs/promotion@2.12.5
  - @medusajs/fulfillment-manual@2.12.5
  - @medusajs/region@2.12.5
  - @medusajs/stock-location@2.12.5
  - @medusajs/store@2.12.5
  - @medusajs/tax@2.12.5
  - @medusajs/translation@2.12.5
  - @medusajs/user@2.12.5
  - @medusajs/workflow-engine-inmemory@2.12.5

## 1.0.34

### Patch Changes

- Updated dependencies [[`a464e9d907e30bca86a1e8677f8ebf22c38638a2`](https://github.com/medusajs/medusa/commit/a464e9d907e30bca86a1e8677f8ebf22c38638a2), [`60f68ff492bc98013fc2f6e0b0b252182a1ee59c`](https://github.com/medusajs/medusa/commit/60f68ff492bc98013fc2f6e0b0b252182a1ee59c), [`9d2c78db4eac010d60b8943e769e68d506cfd529`](https://github.com/medusajs/medusa/commit/9d2c78db4eac010d60b8943e769e68d506cfd529), [`0ffd79010953315494c1b2ba1def477b7b1d9e4b`](https://github.com/medusajs/medusa/commit/0ffd79010953315494c1b2ba1def477b7b1d9e4b), [`6380c1fdf42d023f7a103260ba204efbe37d5c0f`](https://github.com/medusajs/medusa/commit/6380c1fdf42d023f7a103260ba204efbe37d5c0f), [`9cad05c8df1c3f2591da46b5efa415b4850e0602`](https://github.com/medusajs/medusa/commit/9cad05c8df1c3f2591da46b5efa415b4850e0602), [`bf4cc12545edc5bf249edc6ecec115c5f7a2b31f`](https://github.com/medusajs/medusa/commit/bf4cc12545edc5bf249edc6ecec115c5f7a2b31f), [`c0ec54fc15fece373ac77f547706ab85eb5bc844`](https://github.com/medusajs/medusa/commit/c0ec54fc15fece373ac77f547706ab85eb5bc844), [`0277062fecc278e630bf2110761a545339f6b9fe`](https://github.com/medusajs/medusa/commit/0277062fecc278e630bf2110761a545339f6b9fe), [`b21a599d118f126e64d2993d46ba60f4a4e94545`](https://github.com/medusajs/medusa/commit/b21a599d118f126e64d2993d46ba60f4a4e94545), [`181d5fa67122e4e5f38b91f6b716d35f2d08a204`](https://github.com/medusajs/medusa/commit/181d5fa67122e4e5f38b91f6b716d35f2d08a204), [`001923da2bbebb3d42373f0f66e517830d9c0187`](https://github.com/medusajs/medusa/commit/001923da2bbebb3d42373f0f66e517830d9c0187), [`d347e369ce555064e24f2dc3cd93b9e4e73a006d`](https://github.com/medusajs/medusa/commit/d347e369ce555064e24f2dc3cd93b9e4e73a006d), [`8055a79c5268528261c88d5f6f245d1003d87a6d`](https://github.com/medusajs/medusa/commit/8055a79c5268528261c88d5f6f245d1003d87a6d), [`1c89acc536b9b15a7a2984a34783cf3b08db6317`](https://github.com/medusajs/medusa/commit/1c89acc536b9b15a7a2984a34783cf3b08db6317), [`43305a562cfba914654da056b0a7e03c40849678`](https://github.com/medusajs/medusa/commit/43305a562cfba914654da056b0a7e03c40849678), [`92d240d7493ed350aed8b8af80c1dfc62b07a88c`](https://github.com/medusajs/medusa/commit/92d240d7493ed350aed8b8af80c1dfc62b07a88c), [`11de7e3e3449f3a93724aaeed770a66840ffcaf9`](https://github.com/medusajs/medusa/commit/11de7e3e3449f3a93724aaeed770a66840ffcaf9), [`7e3ed913a6008a25974634d489f9339c40066125`](https://github.com/medusajs/medusa/commit/7e3ed913a6008a25974634d489f9339c40066125)]:
  - @medusajs/core-flows@2.12.4
  - @medusajs/translation@2.12.4
  - @medusajs/medusa@2.12.4
  - @medusajs/modules-sdk@2.12.4
  - @medusajs/utils@2.12.4
  - @medusajs/framework@2.12.4
  - @medusajs/auth@2.12.4
  - @medusajs/test-utils@2.12.4
  - @medusajs/api-key@2.12.4
  - @medusajs/cache-inmemory@2.12.4
  - @medusajs/customer@2.12.4
  - @medusajs/event-bus-local@2.12.4
  - @medusajs/event-bus-redis@2.12.4
  - @medusajs/fulfillment@2.12.4
  - @medusajs/inventory@2.12.4
  - @medusajs/pricing@2.12.4
  - @medusajs/product@2.12.4
  - @medusajs/promotion@2.12.4
  - @medusajs/fulfillment-manual@2.12.4
  - @medusajs/region@2.12.4
  - @medusajs/stock-location@2.12.4
  - @medusajs/store@2.12.4
  - @medusajs/tax@2.12.4
  - @medusajs/user@2.12.4
  - @medusajs/workflow-engine-inmemory@2.12.4

## 1.0.33

### Patch Changes

- Updated dependencies [[`b3cb904e9bce3bfad649e500a9e1be0c9bff0e1a`](https://github.com/medusajs/medusa/commit/b3cb904e9bce3bfad649e500a9e1be0c9bff0e1a), [`31a057558c0ec6ff7233489a28edc1fda0ec5375`](https://github.com/medusajs/medusa/commit/31a057558c0ec6ff7233489a28edc1fda0ec5375), [`accb778039a52fae8eefbada77044c527b136114`](https://github.com/medusajs/medusa/commit/accb778039a52fae8eefbada77044c527b136114), [`7b4dda5a179c78de5e099231ec407836db4c8dbd`](https://github.com/medusajs/medusa/commit/7b4dda5a179c78de5e099231ec407836db4c8dbd), [`8964a03fa1b9e6a4c443bf5b21d65d41a8441d29`](https://github.com/medusajs/medusa/commit/8964a03fa1b9e6a4c443bf5b21d65d41a8441d29), [`6815b3d7dbad2931895ba81c6de19208427d9c50`](https://github.com/medusajs/medusa/commit/6815b3d7dbad2931895ba81c6de19208427d9c50), [`e94e1a4676d68950df76a496a30a9acc61e4b799`](https://github.com/medusajs/medusa/commit/e94e1a4676d68950df76a496a30a9acc61e4b799), [`ba6ed8d9dd22be8646d311d9531c65aea1b7986a`](https://github.com/medusajs/medusa/commit/ba6ed8d9dd22be8646d311d9531c65aea1b7986a), [`70929ecac3e5610d90d47a40a517eac3cf3173a4`](https://github.com/medusajs/medusa/commit/70929ecac3e5610d90d47a40a517eac3cf3173a4), [`1743ed7f04585c597c9398a99899817b11310463`](https://github.com/medusajs/medusa/commit/1743ed7f04585c597c9398a99899817b11310463), [`b5edbb994084b6095ee523e018b835f19e73df3a`](https://github.com/medusajs/medusa/commit/b5edbb994084b6095ee523e018b835f19e73df3a), [`f13c23a4b709e31f9b2d42e98acc6e342c494403`](https://github.com/medusajs/medusa/commit/f13c23a4b709e31f9b2d42e98acc6e342c494403), [`8c29d85f0f7fdd27b67974d26e3b774e3270e5a9`](https://github.com/medusajs/medusa/commit/8c29d85f0f7fdd27b67974d26e3b774e3270e5a9), [`c8a7122ba918751b215dc0b19cf9b09b2c011ab8`](https://github.com/medusajs/medusa/commit/c8a7122ba918751b215dc0b19cf9b09b2c011ab8), [`d813fc4ff91e98b475a4eae11780ddc00caf66a8`](https://github.com/medusajs/medusa/commit/d813fc4ff91e98b475a4eae11780ddc00caf66a8), [`0f1566c64456a6f29a7bfb1dda5a7c470a84ace7`](https://github.com/medusajs/medusa/commit/0f1566c64456a6f29a7bfb1dda5a7c470a84ace7)]:
  - @medusajs/core-flows@2.12.3
  - @medusajs/utils@2.12.3
  - @medusajs/medusa@2.12.3
  - @medusajs/framework@2.12.3
  - @medusajs/store@2.12.3
  - @medusajs/translation@2.12.3
  - @medusajs/pricing@2.12.3
  - @medusajs/fulfillment@2.12.3
  - @medusajs/product@2.12.3
  - @medusajs/promotion@2.12.3
  - @medusajs/test-utils@2.12.3
  - @medusajs/modules-sdk@2.12.3
  - @medusajs/api-key@2.12.3
  - @medusajs/auth@2.12.3
  - @medusajs/cache-inmemory@2.12.3
  - @medusajs/customer@2.12.3
  - @medusajs/event-bus-local@2.12.3
  - @medusajs/event-bus-redis@2.12.3
  - @medusajs/inventory@2.12.3
  - @medusajs/fulfillment-manual@2.12.3
  - @medusajs/region@2.12.3
  - @medusajs/stock-location@2.12.3
  - @medusajs/tax@2.12.3
  - @medusajs/user@2.12.3
  - @medusajs/workflow-engine-inmemory@2.12.3

## 1.0.32

### Patch Changes

- Updated dependencies [[`4dbf46f2cb64240092843ebfdef766ec5b2a7116`](https://github.com/medusajs/medusa/commit/4dbf46f2cb64240092843ebfdef766ec5b2a7116), [`9f7846ae0babbad39947a1f33d236bff8b5098d0`](https://github.com/medusajs/medusa/commit/9f7846ae0babbad39947a1f33d236bff8b5098d0), [`e4877616c38777f583fe0b58bb10d1c7cf41c0b3`](https://github.com/medusajs/medusa/commit/e4877616c38777f583fe0b58bb10d1c7cf41c0b3), [`a78f68fa46dceb8e201fe60e770bd9ea654390d8`](https://github.com/medusajs/medusa/commit/a78f68fa46dceb8e201fe60e770bd9ea654390d8), [`fe49b567d6d55ae224095c06c710d31d40887653`](https://github.com/medusajs/medusa/commit/fe49b567d6d55ae224095c06c710d31d40887653), [`b517137466726c15d5e31ab0c9f42aa57af90c4e`](https://github.com/medusajs/medusa/commit/b517137466726c15d5e31ab0c9f42aa57af90c4e), [`842c0f500721e08d448b6c5c80a725072106ccff`](https://github.com/medusajs/medusa/commit/842c0f500721e08d448b6c5c80a725072106ccff), [`bca145bdbe674a73731f1672047ca44d426a37c1`](https://github.com/medusajs/medusa/commit/bca145bdbe674a73731f1672047ca44d426a37c1), [`6dc0b8bed84a330c1c24f4f1331f1ed078430a47`](https://github.com/medusajs/medusa/commit/6dc0b8bed84a330c1c24f4f1331f1ed078430a47), [`24c469d2173e814a567e18454f5cc5c81f5dcc6a`](https://github.com/medusajs/medusa/commit/24c469d2173e814a567e18454f5cc5c81f5dcc6a), [`fd3965974dc0b750d377ff621387d34611760957`](https://github.com/medusajs/medusa/commit/fd3965974dc0b750d377ff621387d34611760957), [`bff0142e7a0d65c9204864b04a28cada2caaa894`](https://github.com/medusajs/medusa/commit/bff0142e7a0d65c9204864b04a28cada2caaa894), [`fdc2b722d91f446499123d71386e64d9da9265eb`](https://github.com/medusajs/medusa/commit/fdc2b722d91f446499123d71386e64d9da9265eb), [`356283c359e5c30e0d31e6c6fd0fb8e16c025b78`](https://github.com/medusajs/medusa/commit/356283c359e5c30e0d31e6c6fd0fb8e16c025b78), [`dd74ce34ba4e273719d1205a2ec6d76f06c7c94e`](https://github.com/medusajs/medusa/commit/dd74ce34ba4e273719d1205a2ec6d76f06c7c94e), [`144f0f4e2ef4bf27e0e3fc48dd7d79bb6fbedef9`](https://github.com/medusajs/medusa/commit/144f0f4e2ef4bf27e0e3fc48dd7d79bb6fbedef9), [`5b7e3c0e7649a3a61b0a4fe796f37e5f7fbe9a3a`](https://github.com/medusajs/medusa/commit/5b7e3c0e7649a3a61b0a4fe796f37e5f7fbe9a3a), [`fea3d4ec49c3a7f7eb7d66bd58499e55ae9ec648`](https://github.com/medusajs/medusa/commit/fea3d4ec49c3a7f7eb7d66bd58499e55ae9ec648), [`4de555b546c33c67653a211987aca5f80341e637`](https://github.com/medusajs/medusa/commit/4de555b546c33c67653a211987aca5f80341e637)]:
  - @medusajs/utils@2.12.2
  - @medusajs/framework@2.12.2
  - @medusajs/medusa@2.12.2
  - @medusajs/test-utils@2.12.2
  - @medusajs/core-flows@2.12.2
  - @medusajs/event-bus-local@2.12.2
  - @medusajs/modules-sdk@2.12.2
  - @medusajs/product@2.12.2
  - @medusajs/customer@2.12.2
  - @medusajs/promotion@2.12.2
  - @medusajs/event-bus-redis@2.12.2
  - @medusajs/api-key@2.12.2
  - @medusajs/auth@2.12.2
  - @medusajs/cache-inmemory@2.12.2
  - @medusajs/fulfillment@2.12.2
  - @medusajs/inventory@2.12.2
  - @medusajs/pricing@2.12.2
  - @medusajs/fulfillment-manual@2.12.2
  - @medusajs/region@2.12.2
  - @medusajs/stock-location@2.12.2
  - @medusajs/store@2.12.2
  - @medusajs/tax@2.12.2
  - @medusajs/translation@2.12.2
  - @medusajs/user@2.12.2
  - @medusajs/workflow-engine-inmemory@2.12.2

## 1.0.31

### Patch Changes

- Updated dependencies [[`391d8dc6cd50c79b678059fdeb7774a72e243143`](https://github.com/medusajs/medusa/commit/391d8dc6cd50c79b678059fdeb7774a72e243143)]:
  - @medusajs/medusa@2.12.1
  - @medusajs/utils@2.12.1
  - @medusajs/test-utils@2.12.1
  - @medusajs/framework@2.12.1
  - @medusajs/modules-sdk@2.12.1
  - @medusajs/api-key@2.12.1
  - @medusajs/auth@2.12.1
  - @medusajs/customer@2.12.1
  - @medusajs/fulfillment@2.12.1
  - @medusajs/inventory@2.12.1
  - @medusajs/pricing@2.12.1
  - @medusajs/product@2.12.1
  - @medusajs/promotion@2.12.1
  - @medusajs/region@2.12.1
  - @medusajs/stock-location@2.12.1
  - @medusajs/store@2.12.1
  - @medusajs/tax@2.12.1
  - @medusajs/user@2.12.1
  - @medusajs/workflow-engine-inmemory@2.12.1
  - @medusajs/core-flows@2.12.1
  - @medusajs/cache-inmemory@2.12.1
  - @medusajs/event-bus-local@2.12.1
  - @medusajs/event-bus-redis@2.12.1
  - @medusajs/fulfillment-manual@2.12.1

## 1.0.30

### Patch Changes

- [#13306](https://github.com/medusajs/medusa/pull/13306) [`78842af1c30de9c7561f10b4129aba4e1f30db27`](https://github.com/medusajs/medusa/commit/78842af1c30de9c7561f10b4129aba4e1f30db27) Thanks [@olivermrbl](https://github.com/olivermrbl)! - fix: Compute "virtual" adjustments for order previews

- Updated dependencies [[`83dd1b616a9e78810001645bb815347cacc5b4d1`](https://github.com/medusajs/medusa/commit/83dd1b616a9e78810001645bb815347cacc5b4d1), [`9fdc00350a4aa006e4bfc3eddcc499737f18bdf3`](https://github.com/medusajs/medusa/commit/9fdc00350a4aa006e4bfc3eddcc499737f18bdf3), [`0ddd9e36b51267f774ec53e8dd110b601196fa51`](https://github.com/medusajs/medusa/commit/0ddd9e36b51267f774ec53e8dd110b601196fa51), [`bbf294fc31ac12d3dcdd1687340e58574fb4cfea`](https://github.com/medusajs/medusa/commit/bbf294fc31ac12d3dcdd1687340e58574fb4cfea), [`113f200a99ccb2f0fbef0017340da5107c700a74`](https://github.com/medusajs/medusa/commit/113f200a99ccb2f0fbef0017340da5107c700a74), [`5499cd27494a68836a242cd34eb70fe9c141a713`](https://github.com/medusajs/medusa/commit/5499cd27494a68836a242cd34eb70fe9c141a713), [`929607f6925581da67a9e955eedded2aab2bdc16`](https://github.com/medusajs/medusa/commit/929607f6925581da67a9e955eedded2aab2bdc16), [`6b4f2c1d3282501fce5b9a4f35bbcecf8a18fe93`](https://github.com/medusajs/medusa/commit/6b4f2c1d3282501fce5b9a4f35bbcecf8a18fe93), [`c2c3ad5ba53f1959422fb2d37297a8de8d714782`](https://github.com/medusajs/medusa/commit/c2c3ad5ba53f1959422fb2d37297a8de8d714782), [`ef15868ca8b309dc902470b2da0096255da82c5d`](https://github.com/medusajs/medusa/commit/ef15868ca8b309dc902470b2da0096255da82c5d), [`3e2991e44719c2a829696215862ae5fbd368fe37`](https://github.com/medusajs/medusa/commit/3e2991e44719c2a829696215862ae5fbd368fe37), [`7e3eb6e41316d7b04d32bc7186ed0c78de1aa539`](https://github.com/medusajs/medusa/commit/7e3eb6e41316d7b04d32bc7186ed0c78de1aa539), [`beb91d88a2f224075e4fcf35a0ee9483b3124504`](https://github.com/medusajs/medusa/commit/beb91d88a2f224075e4fcf35a0ee9483b3124504), [`a5c6f6b1fb944a730b605a120f84b4f38f608f9f`](https://github.com/medusajs/medusa/commit/a5c6f6b1fb944a730b605a120f84b4f38f608f9f), [`78842af1c30de9c7561f10b4129aba4e1f30db27`](https://github.com/medusajs/medusa/commit/78842af1c30de9c7561f10b4129aba4e1f30db27), [`32eaa9dd81a58e9208cce700b0087d14eec8cd5c`](https://github.com/medusajs/medusa/commit/32eaa9dd81a58e9208cce700b0087d14eec8cd5c), [`aae92d5447c067fce9889403da30f3abcdf5be23`](https://github.com/medusajs/medusa/commit/aae92d5447c067fce9889403da30f3abcdf5be23), [`91499081f4584d53690db07f6a9c9f104cd5674e`](https://github.com/medusajs/medusa/commit/91499081f4584d53690db07f6a9c9f104cd5674e), [`1cfc88ee5530d1d45dc583412234d86d6fe7a777`](https://github.com/medusajs/medusa/commit/1cfc88ee5530d1d45dc583412234d86d6fe7a777), [`0e73d8d5e3d04d62d444d17138f9cf61b7a236a2`](https://github.com/medusajs/medusa/commit/0e73d8d5e3d04d62d444d17138f9cf61b7a236a2), [`8ddf8b4d764ae359d279498f08d85146d55077f0`](https://github.com/medusajs/medusa/commit/8ddf8b4d764ae359d279498f08d85146d55077f0), [`00aa2c13bc37223029e40b38f3e2bedd8ed1e816`](https://github.com/medusajs/medusa/commit/00aa2c13bc37223029e40b38f3e2bedd8ed1e816), [`79582bc94eb420f02ad49a81bcbcc02521e5c414`](https://github.com/medusajs/medusa/commit/79582bc94eb420f02ad49a81bcbcc02521e5c414), [`536a3f802c92960b1eab48c37db25a8c542fd231`](https://github.com/medusajs/medusa/commit/536a3f802c92960b1eab48c37db25a8c542fd231), [`5da51064d7936c6d7a459cfa8b34eada65163e03`](https://github.com/medusajs/medusa/commit/5da51064d7936c6d7a459cfa8b34eada65163e03), [`0cb12021efd2b8ad1cd6dc6801c5f29a87b28ad1`](https://github.com/medusajs/medusa/commit/0cb12021efd2b8ad1cd6dc6801c5f29a87b28ad1), [`a9d33bc8d11637230052f1729e85af5e174b2423`](https://github.com/medusajs/medusa/commit/a9d33bc8d11637230052f1729e85af5e174b2423), [`0a0c2f41d8ef2c70f6e3b73251eb34499e83ea32`](https://github.com/medusajs/medusa/commit/0a0c2f41d8ef2c70f6e3b73251eb34499e83ea32), [`1ea932a56f1d85fd1ebbe4a77f3619fe58d2947a`](https://github.com/medusajs/medusa/commit/1ea932a56f1d85fd1ebbe4a77f3619fe58d2947a), [`b81f958d4126ab99f09b9fef3b1f790b4bca1515`](https://github.com/medusajs/medusa/commit/b81f958d4126ab99f09b9fef3b1f790b4bca1515), [`5c6c28545c6fe4789afdb8fedcab144eda2a452f`](undefined), [`e59cdae3365981339d55ec01224f09995250e67d`](https://github.com/medusajs/medusa/commit/e59cdae3365981339d55ec01224f09995250e67d), [`6bc5bf4fc976a827ea1d1a5b095e370e717a9b24`](https://github.com/medusajs/medusa/commit/6bc5bf4fc976a827ea1d1a5b095e370e717a9b24), [`4bbf0d23674856f2d9fd0a9d137a478bc90b4cdb`](https://github.com/medusajs/medusa/commit/4bbf0d23674856f2d9fd0a9d137a478bc90b4cdb), [`b74ef4a784d3728ff2c657a8186095e87fc3f0d4`](https://github.com/medusajs/medusa/commit/b74ef4a784d3728ff2c657a8186095e87fc3f0d4), [`6746fecd727823b233a90edb1819d08555124464`](https://github.com/medusajs/medusa/commit/6746fecd727823b233a90edb1819d08555124464), [`9d9d0397a88c398683f75ac3d6f539c1a686d278`](undefined), [`a85778679e99c40421b3be0122d153f991efbc80`](https://github.com/medusajs/medusa/commit/a85778679e99c40421b3be0122d153f991efbc80), [`f67bfb9f92b9ea4c06910ea203c685e18fafe1d7`](https://github.com/medusajs/medusa/commit/f67bfb9f92b9ea4c06910ea203c685e18fafe1d7)]:
  - @medusajs/core-flows@2.12.0
  - @medusajs/medusa@2.12.0
  - @medusajs/product@2.12.0
  - @medusajs/event-bus-local@2.12.0
  - @medusajs/framework@2.12.0
  - @medusajs/promotion@2.12.0
  - @medusajs/modules-sdk@2.12.0
  - @medusajs/utils@2.12.0
  - @medusajs/workflow-engine-inmemory@2.12.0
  - @medusajs/fulfillment@2.12.0
  - @medusajs/test-utils@2.12.0
  - @medusajs/api-key@2.12.0
  - @medusajs/auth@2.12.0
  - @medusajs/cache-inmemory@2.12.0
  - @medusajs/customer@2.12.0
  - @medusajs/inventory@2.12.0
  - @medusajs/pricing@2.12.0
  - @medusajs/fulfillment-manual@2.12.0
  - @medusajs/region@2.12.0
  - @medusajs/stock-location@2.12.0
  - @medusajs/store@2.12.0
  - @medusajs/tax@2.12.0
  - @medusajs/user@2.12.0

## 1.0.29

### Patch Changes

- Updated dependencies [[`42b270ed2df09474f528d8d23816e0affcf4bd25`](https://github.com/medusajs/medusa/commit/42b270ed2df09474f528d8d23816e0affcf4bd25), [`018871f8cd6121ea6af40644f784256891b11849`](https://github.com/medusajs/medusa/commit/018871f8cd6121ea6af40644f784256891b11849), [`28c3ea68f5634792848f146ac6af5b27c848bf21`](https://github.com/medusajs/medusa/commit/28c3ea68f5634792848f146ac6af5b27c848bf21), [`224ab39a81e8d3cf3d6fa3ff5eee82541f64728d`](https://github.com/medusajs/medusa/commit/224ab39a81e8d3cf3d6fa3ff5eee82541f64728d), [`afb40d437b3cc4ceb015df70985b2f005f40eaff`](https://github.com/medusajs/medusa/commit/afb40d437b3cc4ceb015df70985b2f005f40eaff), [`e66f7cf59e516f12e5446e191e9fdd1aede9c8ab`](https://github.com/medusajs/medusa/commit/e66f7cf59e516f12e5446e191e9fdd1aede9c8ab), [`990691e78a77a46bc581353de47945dd8f5d6928`](https://github.com/medusajs/medusa/commit/990691e78a77a46bc581353de47945dd8f5d6928), [`e4f8e3d6cc90ba1570e4b0f3f09ac225ce6bc871`](undefined), [`37563987b8fe75c9acfe62957a33e8398977647a`](https://github.com/medusajs/medusa/commit/37563987b8fe75c9acfe62957a33e8398977647a), [`13d7d15be594ca413785eebe8f86b47c36cb9830`](https://github.com/medusajs/medusa/commit/13d7d15be594ca413785eebe8f86b47c36cb9830)]:
  - @medusajs/medusa@2.11.3
  - @medusajs/framework@2.11.3
  - @medusajs/api-key@2.11.3
  - @medusajs/auth@2.11.3
  - @medusajs/cache-inmemory@2.11.3
  - @medusajs/core-flows@2.11.3
  - @medusajs/customer@2.11.3
  - @medusajs/event-bus-local@2.11.3
  - @medusajs/fulfillment@2.11.3
  - @medusajs/fulfillment-manual@2.11.3
  - @medusajs/inventory@2.11.3
  - @medusajs/modules-sdk@2.11.3
  - @medusajs/pricing@2.11.3
  - @medusajs/product@2.11.3
  - @medusajs/promotion@2.11.3
  - @medusajs/region@2.11.3
  - @medusajs/stock-location@2.11.3
  - @medusajs/store@2.11.3
  - @medusajs/tax@2.11.3
  - @medusajs/test-utils@2.11.3
  - @medusajs/user@2.11.3
  - @medusajs/utils@2.11.3
  - @medusajs/workflow-engine-inmemory@2.11.3

## 1.0.28

### Patch Changes

- Updated dependencies [[`f055bfd723e47b381a780b23dc230203b989088c`](https://github.com/medusajs/medusa/commit/f055bfd723e47b381a780b23dc230203b989088c), [`cc2614ded7f83cdbe7e7f7f809d05f5ab6059fe4`](https://github.com/medusajs/medusa/commit/cc2614ded7f83cdbe7e7f7f809d05f5ab6059fe4), [`25a20ca95f702dfb8a34fe9e4f3c565a47c2655e`](https://github.com/medusajs/medusa/commit/25a20ca95f702dfb8a34fe9e4f3c565a47c2655e), [`ec4443287601f5fe1544b305873f3aa151ed1bd7`](https://github.com/medusajs/medusa/commit/ec4443287601f5fe1544b305873f3aa151ed1bd7), [`0f79f22ebc35b3e4d8151789b92c932f014de85e`](https://github.com/medusajs/medusa/commit/0f79f22ebc35b3e4d8151789b92c932f014de85e), [`47572816778e21432d0201f4b2642a765c86fdbc`](https://github.com/medusajs/medusa/commit/47572816778e21432d0201f4b2642a765c86fdbc), [`66bbe39a8ee812ae88b7f06f7d911b8254b1c87e`](https://github.com/medusajs/medusa/commit/66bbe39a8ee812ae88b7f06f7d911b8254b1c87e), [`c9701c70da33bb81aca1560ac5b96ea53fb61060`](https://github.com/medusajs/medusa/commit/c9701c70da33bb81aca1560ac5b96ea53fb61060), [`6d7ba778f5ace76350ac6f249b855b21fb43a03e`](https://github.com/medusajs/medusa/commit/6d7ba778f5ace76350ac6f249b855b21fb43a03e), [`0b202cc50946fdd0d0ccf4c76ae2d4f801895378`](https://github.com/medusajs/medusa/commit/0b202cc50946fdd0d0ccf4c76ae2d4f801895378), [`85b1f3d43aa8d8e0269a545ef7867733fd0eb8e2`](https://github.com/medusajs/medusa/commit/85b1f3d43aa8d8e0269a545ef7867733fd0eb8e2), [`1defb3c29bfe018fd5f89b5a9e27fc8a31d72cdd`](https://github.com/medusajs/medusa/commit/1defb3c29bfe018fd5f89b5a9e27fc8a31d72cdd)]:
  - @medusajs/pricing@2.11.2
  - @medusajs/utils@2.11.2
  - @medusajs/medusa@2.11.2
  - @medusajs/core-flows@2.11.2
  - @medusajs/product@2.11.2
  - @medusajs/framework@2.11.2
  - @medusajs/modules-sdk@2.11.2
  - @medusajs/test-utils@2.11.2
  - @medusajs/api-key@2.11.2
  - @medusajs/auth@2.11.2
  - @medusajs/cache-inmemory@2.11.2
  - @medusajs/customer@2.11.2
  - @medusajs/event-bus-local@2.11.2
  - @medusajs/fulfillment@2.11.2
  - @medusajs/inventory@2.11.2
  - @medusajs/promotion@2.11.2
  - @medusajs/fulfillment-manual@2.11.2
  - @medusajs/region@2.11.2
  - @medusajs/stock-location@2.11.2
  - @medusajs/store@2.11.2
  - @medusajs/tax@2.11.2
  - @medusajs/user@2.11.2
  - @medusajs/workflow-engine-inmemory@2.11.2

## 1.0.27

### Patch Changes

- Updated dependencies [[`d51ae2768be0dad5ece49324aa4866bb591e7ad0`](https://github.com/medusajs/medusa/commit/d51ae2768be0dad5ece49324aa4866bb591e7ad0), [`90162ebeacf6e093a06b70ac2e87de9f12674a17`](https://github.com/medusajs/medusa/commit/90162ebeacf6e093a06b70ac2e87de9f12674a17), [`5df903f5fb52d1e37d13bfe72ed9c226c1eb46b4`](https://github.com/medusajs/medusa/commit/5df903f5fb52d1e37d13bfe72ed9c226c1eb46b4), [`2d1d51a2af71092127c0af79786ece735b47f13f`](https://github.com/medusajs/medusa/commit/2d1d51a2af71092127c0af79786ece735b47f13f), [`a34fcfab351a79badfb24255602ca3c6ff60bffd`](https://github.com/medusajs/medusa/commit/a34fcfab351a79badfb24255602ca3c6ff60bffd)]:
  - @medusajs/workflow-engine-inmemory@2.11.1
  - @medusajs/medusa@2.11.1
  - @medusajs/core-flows@2.11.1
  - @medusajs/test-utils@2.11.1
  - @medusajs/customer@2.11.1
  - @medusajs/inventory@2.11.1
  - @medusajs/product@2.11.1
  - @medusajs/framework@2.11.1
  - @medusajs/modules-sdk@2.11.1
  - @medusajs/utils@2.11.1
  - @medusajs/api-key@2.11.1
  - @medusajs/auth@2.11.1
  - @medusajs/fulfillment@2.11.1
  - @medusajs/pricing@2.11.1
  - @medusajs/promotion@2.11.1
  - @medusajs/region@2.11.1
  - @medusajs/stock-location@2.11.1
  - @medusajs/store@2.11.1
  - @medusajs/tax@2.11.1
  - @medusajs/user@2.11.1
  - @medusajs/cache-inmemory@2.11.1
  - @medusajs/event-bus-local@2.11.1
  - @medusajs/fulfillment-manual@2.11.1

## 1.0.26

### Patch Changes

- [`9d3c71fefd12d09ecd3be1aeff7744e809872481`](undefined) - fix(medusa): cart now returns 404 when not found

- Updated dependencies [[`0cbd9f0bc315b3eda1770ac301061f1576856387`](https://github.com/medusajs/medusa/commit/0cbd9f0bc315b3eda1770ac301061f1576856387), [`12a96a7c7015f011f5e29a1d387f835e514ba536`](https://github.com/medusajs/medusa/commit/12a96a7c7015f011f5e29a1d387f835e514ba536), [`c61f3150c138de016c6886e79d79984bc267273c`](https://github.com/medusajs/medusa/commit/c61f3150c138de016c6886e79d79984bc267273c), [`9c957e1da04c1f86d1caa7de279993453b76bb63`](https://github.com/medusajs/medusa/commit/9c957e1da04c1f86d1caa7de279993453b76bb63), [`295f6be146dff6650216259bdf3e64165e5e3691`](undefined), [`45f180a2b558edcf69603f3d8da983e92c4e212d`](https://github.com/medusajs/medusa/commit/45f180a2b558edcf69603f3d8da983e92c4e212d), [`1b57e5c58ab5c656da398b69444c2b9baba2e35e`](https://github.com/medusajs/medusa/commit/1b57e5c58ab5c656da398b69444c2b9baba2e35e), [`a501364b2d26a3ca0670eb345d9933b83964abc1`](undefined), [`7dc3b0c5ffdf8eb7070ee5cfd8155c6c4de5c0b1`](https://github.com/medusajs/medusa/commit/7dc3b0c5ffdf8eb7070ee5cfd8155c6c4de5c0b1), [`9c7c1d48c7779023172d5e7003674b2d7107b733`](https://github.com/medusajs/medusa/commit/9c7c1d48c7779023172d5e7003674b2d7107b733), [`76aa4a48b3cbec519ab16c96cc87ee3288de28de`](https://github.com/medusajs/medusa/commit/76aa4a48b3cbec519ab16c96cc87ee3288de28de), [`5c77b10fa64d28c315e5196da1c9608c1c0a2ab7`](undefined), [`9d8ed70130867466f81834adf13b7b60bdfc0b6a`](undefined), [`5346079d4717933d31d57f549d4158f3d433551c`](undefined), [`730d73306d699634121a793f2b4049fd3e09bc47`](undefined), [`5b135a41fe40ccda9ef0e867748a77c619214d0a`](undefined), [`57030fa43e084ed8300e6b74399c5402b1587e80`](undefined), [`150aa50397825ae800f3acf4bbc68fe28e397582`](https://github.com/medusajs/medusa/commit/150aa50397825ae800f3acf4bbc68fe28e397582), [`70d855bd1be0ab654ff319d3780469e0c8a0fe36`](undefined), [`4c1c1dd4c0790597d7d881bb979bb9c8d8fd35e3`](undefined), [`b9d6f73320c36c53235b12fb8397b30a448917f0`](https://github.com/medusajs/medusa/commit/b9d6f73320c36c53235b12fb8397b30a448917f0), [`924564bee505fc8787945c6d683243cef5799625`](https://github.com/medusajs/medusa/commit/924564bee505fc8787945c6d683243cef5799625), [`cb716856b653c31178a5977b17ec77eed4c9c241`](undefined), [`1fd439e321d8284ab7218333ab83125af66afb02`](undefined), [`51859c38a728c5f05cf30f09f4c6a55657895de7`](https://github.com/medusajs/medusa/commit/51859c38a728c5f05cf30f09f4c6a55657895de7), [`8acfb88c2b627ba6ba4a2827bcb78c3bb74c22f8`](https://github.com/medusajs/medusa/commit/8acfb88c2b627ba6ba4a2827bcb78c3bb74c22f8), [`b43b285125a66455ed6567543414eddcbe54781e`](undefined), [`41651721450c99e5f38cfbb87a6a47ab067ece86`](https://github.com/medusajs/medusa/commit/41651721450c99e5f38cfbb87a6a47ab067ece86), [`a61d1825eaef4bece20704fe6ae21d9da841b2f2`](https://github.com/medusajs/medusa/commit/a61d1825eaef4bece20704fe6ae21d9da841b2f2), [`71014bafa6942709d4b763cbc82dc7f6d4860ba6`](undefined), [`087887fefb948e6676001ad2dc2cb265ae6f7430`](https://github.com/medusajs/medusa/commit/087887fefb948e6676001ad2dc2cb265ae6f7430), [`8ece06d8ed6a197ebb370918c49a3ec5c21dd186`](https://github.com/medusajs/medusa/commit/8ece06d8ed6a197ebb370918c49a3ec5c21dd186), [`8fb7e04be7d586453d32ee73e292834ca2de2378`](undefined), [`fc67fd0b36f53f0c0897df54ecea02061e65e816`](https://github.com/medusajs/medusa/commit/fc67fd0b36f53f0c0897df54ecea02061e65e816), [`bb08edd41fd954306b0feacf6a6a69b87d9287dd`](https://github.com/medusajs/medusa/commit/bb08edd41fd954306b0feacf6a6a69b87d9287dd), [`5ea32aaa44a47b143c46f895032478334b7379ca`](https://github.com/medusajs/medusa/commit/5ea32aaa44a47b143c46f895032478334b7379ca), [`459fbcdf998a506d80abb758bc7648126c6c96f8`](https://github.com/medusajs/medusa/commit/459fbcdf998a506d80abb758bc7648126c6c96f8), [`137b237c8498fe4c195a3b8344e16b61193b9329`](undefined), [`c54c5ed6de2c9686f89aeef86c5c607c4b5f1cf3`](https://github.com/medusajs/medusa/commit/c54c5ed6de2c9686f89aeef86c5c607c4b5f1cf3), [`907fbc89a2566f516c65a4eefdfeeb4f9dcb3579`](undefined), [`1d2b4566fda0bdd826c3d1fe090b1ee3efdbd9bd`](https://github.com/medusajs/medusa/commit/1d2b4566fda0bdd826c3d1fe090b1ee3efdbd9bd), [`458dd04bbf70159ec42254e91675c7a1f1d344d8`](https://github.com/medusajs/medusa/commit/458dd04bbf70159ec42254e91675c7a1f1d344d8), [`ee1c77a01f6463dd7a1d8bc2046e91b932900602`](undefined), [`3960c80e9f55bdf41f9f257e12ed72c713577598`](undefined), [`86c975258b7f3a2f1d49117f7a4139806812a8e7`](https://github.com/medusajs/medusa/commit/86c975258b7f3a2f1d49117f7a4139806812a8e7), [`92d30b28f45b4037cd73c180c8f257070cf49bd4`](https://github.com/medusajs/medusa/commit/92d30b28f45b4037cd73c180c8f257070cf49bd4), [`ca334b7cc1eef297cbde2356746adfd0121d348f`](undefined), [`fc2ded4b100432236a14d9f6409e8c6ea5a84269`](https://github.com/medusajs/medusa/commit/fc2ded4b100432236a14d9f6409e8c6ea5a84269), [`02b6d013822b9665f868c4ea6d1b5cfe58723459`](https://github.com/medusajs/medusa/commit/02b6d013822b9665f868c4ea6d1b5cfe58723459), [`4e3090ab263b8c0da97e91d6586275d0f8609db5`](https://github.com/medusajs/medusa/commit/4e3090ab263b8c0da97e91d6586275d0f8609db5), [`9d3c71fefd12d09ecd3be1aeff7744e809872481`](undefined), [`516f5a38960f1ea05a2c696e0079d2e4c34d5c86`](https://github.com/medusajs/medusa/commit/516f5a38960f1ea05a2c696e0079d2e4c34d5c86)]:
  - @medusajs/core-flows@2.11.0
  - @medusajs/modules-sdk@2.11.0
  - @medusajs/framework@2.11.0
  - @medusajs/utils@2.11.0
  - @medusajs/medusa@2.11.0
  - @medusajs/test-utils@2.11.0
  - @medusajs/api-key@2.11.0
  - @medusajs/auth@2.11.0
  - @medusajs/customer@2.11.0
  - @medusajs/fulfillment@2.11.0
  - @medusajs/inventory@2.11.0
  - @medusajs/pricing@2.11.0
  - @medusajs/product@2.11.0
  - @medusajs/promotion@2.11.0
  - @medusajs/region@2.11.0
  - @medusajs/stock-location@2.11.0
  - @medusajs/store@2.11.0
  - @medusajs/tax@2.11.0
  - @medusajs/user@2.11.0
  - @medusajs/workflow-engine-inmemory@2.11.0
  - @medusajs/event-bus-local@2.11.0
  - @medusajs/cache-inmemory@2.11.0
  - @medusajs/fulfillment-manual@2.11.0

## 1.0.25

### Patch Changes

- Updated dependencies [[`ebf33bea43bb6fe03a60a3099b2bc62608f0d13b`](https://github.com/medusajs/medusa/commit/ebf33bea43bb6fe03a60a3099b2bc62608f0d13b), [`25634b038248ab6501af719faec79b59b496bada`](https://github.com/medusajs/medusa/commit/25634b038248ab6501af719faec79b59b496bada), [`57897c232e23db042f523cbe83b6318b97de519d`](https://github.com/medusajs/medusa/commit/57897c232e23db042f523cbe83b6318b97de519d), [`9563ee446f2b3a2e0cd4a4a33959ed55be5f268a`](https://github.com/medusajs/medusa/commit/9563ee446f2b3a2e0cd4a4a33959ed55be5f268a), [`4736c58da5de67f6868b4552351a093e67715e4b`](https://github.com/medusajs/medusa/commit/4736c58da5de67f6868b4552351a093e67715e4b), [`1071296236d84b70b3b31034eb95984445feb020`](https://github.com/medusajs/medusa/commit/1071296236d84b70b3b31034eb95984445feb020), [`90cc3f42d98bce04d45a72165399193e7933a54f`](https://github.com/medusajs/medusa/commit/90cc3f42d98bce04d45a72165399193e7933a54f), [`040fbf3220420b43871e33acc6686a6cedcf88fc`](https://github.com/medusajs/medusa/commit/040fbf3220420b43871e33acc6686a6cedcf88fc), [`8565dcfc46c9ccc923a44582bb215c615ac2792f`](https://github.com/medusajs/medusa/commit/8565dcfc46c9ccc923a44582bb215c615ac2792f)]:
  - @medusajs/workflow-engine-inmemory@2.10.3
  - @medusajs/medusa@2.10.3
  - @medusajs/api-key@2.10.3
  - @medusajs/auth@2.10.3
  - @medusajs/customer@2.10.3
  - @medusajs/event-bus-local@2.10.3
  - @medusajs/fulfillment@2.10.3
  - @medusajs/inventory@2.10.3
  - @medusajs/core-flows@2.10.3
  - @medusajs/modules-sdk@2.10.3
  - @medusajs/utils@2.10.3
  - @medusajs/promotion@2.10.3
  - @medusajs/test-utils@2.10.3
  - @medusajs/cache-inmemory@2.10.3
  - @medusajs/pricing@2.10.3
  - @medusajs/product@2.10.3
  - @medusajs/fulfillment-manual@2.10.3
  - @medusajs/region@2.10.3
  - @medusajs/stock-location@2.10.3
  - @medusajs/store@2.10.3
  - @medusajs/tax@2.10.3
  - @medusajs/user@2.10.3

## 1.0.24

### Patch Changes

- Updated dependencies [[`e8822f3e693bde33fdfd8b0d6140b4e59b40af98`](https://github.com/medusajs/medusa/commit/e8822f3e693bde33fdfd8b0d6140b4e59b40af98), [`0000ed69982b95f4bff80fd6182347291d25f7b8`](https://github.com/medusajs/medusa/commit/0000ed69982b95f4bff80fd6182347291d25f7b8), [`2b89510df3b87c153beae5207b1f9184002129d7`](https://github.com/medusajs/medusa/commit/2b89510df3b87c153beae5207b1f9184002129d7), [`a0693727a04855f07c710207aaeac07699fc8ee9`](https://github.com/medusajs/medusa/commit/a0693727a04855f07c710207aaeac07699fc8ee9), [`d828005354587d248f699656d04c7cb4cbe1fc87`](https://github.com/medusajs/medusa/commit/d828005354587d248f699656d04c7cb4cbe1fc87), [`bd206cb2505a832d0e426040f7a8cf10a947d346`](https://github.com/medusajs/medusa/commit/bd206cb2505a832d0e426040f7a8cf10a947d346), [`b4c0f131b70ba950339c1ca4d81b5ce062a588a3`](https://github.com/medusajs/medusa/commit/b4c0f131b70ba950339c1ca4d81b5ce062a588a3), [`faae150a589bb29d08719ebb1d2617234e1f5e3a`](https://github.com/medusajs/medusa/commit/faae150a589bb29d08719ebb1d2617234e1f5e3a), [`fb71bc64052ff7ddf4e5a44c6e91e6a3a3636317`](https://github.com/medusajs/medusa/commit/fb71bc64052ff7ddf4e5a44c6e91e6a3a3636317), [`b776fd55dcd959fdd495dd11ff9b006a31a623ce`](https://github.com/medusajs/medusa/commit/b776fd55dcd959fdd495dd11ff9b006a31a623ce), [`d7692100e7a2b2f078756cac9ca2b33784d3d1ff`](https://github.com/medusajs/medusa/commit/d7692100e7a2b2f078756cac9ca2b33784d3d1ff), [`d622c61ce2008f3efdfbbaa4154c4329d7978d2b`](https://github.com/medusajs/medusa/commit/d622c61ce2008f3efdfbbaa4154c4329d7978d2b), [`637d4cf7ef792622830d49446283d3c578c4f09c`](https://github.com/medusajs/medusa/commit/637d4cf7ef792622830d49446283d3c578c4f09c), [`55a35e47218c65190e36a1a6088031890edc1b14`](https://github.com/medusajs/medusa/commit/55a35e47218c65190e36a1a6088031890edc1b14), [`4fded2602bfbb63c8d648d2af717c2eb3bbb6f49`](https://github.com/medusajs/medusa/commit/4fded2602bfbb63c8d648d2af717c2eb3bbb6f49), [`b85a46e85bb741b942e7fa23bef48f447d2b7c5a`](https://github.com/medusajs/medusa/commit/b85a46e85bb741b942e7fa23bef48f447d2b7c5a), [`2fe68a975b75a925e1e16c7e08c245abf63db0c5`](https://github.com/medusajs/medusa/commit/2fe68a975b75a925e1e16c7e08c245abf63db0c5), [`fc4d5f0ac94afaf48fdf39f1d6bd3ac97259a8c5`](https://github.com/medusajs/medusa/commit/fc4d5f0ac94afaf48fdf39f1d6bd3ac97259a8c5), [`8e5c22a8e8c54daa313b4685e453e49699d75e9a`](https://github.com/medusajs/medusa/commit/8e5c22a8e8c54daa313b4685e453e49699d75e9a), [`8e119988950479345c90e88b541198eba53496a3`](https://github.com/medusajs/medusa/commit/8e119988950479345c90e88b541198eba53496a3), [`ac09b3cbeffc11c76b8e5972ee25688b17e5fa58`](https://github.com/medusajs/medusa/commit/ac09b3cbeffc11c76b8e5972ee25688b17e5fa58), [`58e20fa3fc266cbecc69b45998ef1fadd7056f9a`](https://github.com/medusajs/medusa/commit/58e20fa3fc266cbecc69b45998ef1fadd7056f9a), [`2f6edf367abb9d3e71f398c3b98a749b73517ea6`](https://github.com/medusajs/medusa/commit/2f6edf367abb9d3e71f398c3b98a749b73517ea6), [`29dca1ca481e34cc17678b7b4f0e854d3a404acd`](https://github.com/medusajs/medusa/commit/29dca1ca481e34cc17678b7b4f0e854d3a404acd), [`368c1d1e1737fb9cd1e60632c8a2c46a2ce34f46`](https://github.com/medusajs/medusa/commit/368c1d1e1737fb9cd1e60632c8a2c46a2ce34f46), [`ca471eb8f45d01cebe3eb65644de1b10e796e7ba`](https://github.com/medusajs/medusa/commit/ca471eb8f45d01cebe3eb65644de1b10e796e7ba), [`0700a2448c54438482cd3b422e66c591bc5c1df8`](https://github.com/medusajs/medusa/commit/0700a2448c54438482cd3b422e66c591bc5c1df8), [`e0943f3c9012a4a7b63c455bc23ade6ada26b33e`](https://github.com/medusajs/medusa/commit/e0943f3c9012a4a7b63c455bc23ade6ada26b33e), [`823a5c75ff97cf0acbd4ddf00f43ab3b49f0f210`](https://github.com/medusajs/medusa/commit/823a5c75ff97cf0acbd4ddf00f43ab3b49f0f210), [`1b681a79da02aec3f872baa2213a4b2423d73e97`](https://github.com/medusajs/medusa/commit/1b681a79da02aec3f872baa2213a4b2423d73e97)]:
  - @medusajs/api-key@2.10.2
  - @medusajs/customer@2.10.2
  - @medusajs/fulfillment@2.10.2
  - @medusajs/inventory@2.10.2
  - @medusajs/pricing@2.10.2
  - @medusajs/product@2.10.2
  - @medusajs/utils@2.10.2
  - @medusajs/medusa@2.10.2
  - @medusajs/workflow-engine-inmemory@2.10.2
  - @medusajs/test-utils@2.10.2
  - @medusajs/modules-sdk@2.10.2
  - @medusajs/core-flows@2.10.2
  - @medusajs/event-bus-local@2.10.2
  - @medusajs/promotion@2.10.2
  - @medusajs/auth@2.10.2
  - @medusajs/region@2.10.2
  - @medusajs/stock-location@2.10.2
  - @medusajs/store@2.10.2
  - @medusajs/tax@2.10.2
  - @medusajs/user@2.10.2
  - @medusajs/cache-inmemory@2.10.2
  - @medusajs/fulfillment-manual@2.10.2

## 1.0.23

### Patch Changes

- Updated dependencies [[`8176d0f684be95331ce3bec31d67c5f857f9c85a`](https://github.com/medusajs/medusa/commit/8176d0f684be95331ce3bec31d67c5f857f9c85a)]:
  - @medusajs/core-flows@2.10.1
  - @medusajs/medusa@2.10.1
  - @medusajs/test-utils@2.10.1
  - @medusajs/api-key@2.10.1
  - @medusajs/auth@2.10.1
  - @medusajs/customer@2.10.1
  - @medusajs/fulfillment@2.10.1
  - @medusajs/inventory@2.10.1
  - @medusajs/pricing@2.10.1
  - @medusajs/product@2.10.1
  - @medusajs/promotion@2.10.1
  - @medusajs/region@2.10.1
  - @medusajs/stock-location@2.10.1
  - @medusajs/store@2.10.1
  - @medusajs/tax@2.10.1
  - @medusajs/user@2.10.1
  - @medusajs/workflow-engine-inmemory@2.10.1
  - @medusajs/modules-sdk@2.10.1
  - @medusajs/utils@2.10.1
  - @medusajs/cache-inmemory@2.10.1
  - @medusajs/event-bus-local@2.10.1
  - @medusajs/fulfillment-manual@2.10.1

## 1.0.22

### Patch Changes

- Updated dependencies [[`486621383a79e83c831933c1a0ffdae58a695cb0`](https://github.com/medusajs/medusa/commit/486621383a79e83c831933c1a0ffdae58a695cb0), [`2f594291ad8d227b499b80a5bfe66f5963d42d6a`](https://github.com/medusajs/medusa/commit/2f594291ad8d227b499b80a5bfe66f5963d42d6a), [`5382afccfa0740bba04372a8613c537ff6a69cbe`](https://github.com/medusajs/medusa/commit/5382afccfa0740bba04372a8613c537ff6a69cbe), [`e413cfefc2e0579ba7c5299dc4f4270310e39c2c`](https://github.com/medusajs/medusa/commit/e413cfefc2e0579ba7c5299dc4f4270310e39c2c), [`3cc512ef39b6d64b1fe04c1bcdb2e23fa03526f6`](https://github.com/medusajs/medusa/commit/3cc512ef39b6d64b1fe04c1bcdb2e23fa03526f6), [`cbaa40374480a6254d9e568c3003517308be0a44`](https://github.com/medusajs/medusa/commit/cbaa40374480a6254d9e568c3003517308be0a44), [`67d3660abf3ceeac3f04006fe5e92d2fa7c0ccad`](https://github.com/medusajs/medusa/commit/67d3660abf3ceeac3f04006fe5e92d2fa7c0ccad), [`338a42f72808052f8d4dcbda8e070b97048bac87`](https://github.com/medusajs/medusa/commit/338a42f72808052f8d4dcbda8e070b97048bac87), [`9412669e654c994e2dbee9cf61c18004d79f6475`](https://github.com/medusajs/medusa/commit/9412669e654c994e2dbee9cf61c18004d79f6475), [`57077406f9ce5d3bc1008b643a055f294de838eb`](https://github.com/medusajs/medusa/commit/57077406f9ce5d3bc1008b643a055f294de838eb), [`cbfe646ce14d8436adbaa72cda95d38e6cdcd908`](https://github.com/medusajs/medusa/commit/cbfe646ce14d8436adbaa72cda95d38e6cdcd908), [`059bfc147590b01458432539be4a7746bc433c51`](https://github.com/medusajs/medusa/commit/059bfc147590b01458432539be4a7746bc433c51), [`b111d01898a621c4280457021677d9b89e20e10d`](https://github.com/medusajs/medusa/commit/b111d01898a621c4280457021677d9b89e20e10d), [`71818e43cb6c90d26d5173d01c476d2480355110`](https://github.com/medusajs/medusa/commit/71818e43cb6c90d26d5173d01c476d2480355110), [`06ef9197f825c78b9d8d3e1f4f3a0ca995853331`](https://github.com/medusajs/medusa/commit/06ef9197f825c78b9d8d3e1f4f3a0ca995853331), [`fc4925327334c540c0125a91e81794c3c1f340e7`](https://github.com/medusajs/medusa/commit/fc4925327334c540c0125a91e81794c3c1f340e7), [`e2213448ac9eb93318570fde2807a3036108d44b`](https://github.com/medusajs/medusa/commit/e2213448ac9eb93318570fde2807a3036108d44b), [`6b04fbcc50cef6bbe2b65269d1b7d88949e4fa37`](https://github.com/medusajs/medusa/commit/6b04fbcc50cef6bbe2b65269d1b7d88949e4fa37), [`7f5b9fc5fa47e8e73c7afe54aa1bde4dd035086e`](https://github.com/medusajs/medusa/commit/7f5b9fc5fa47e8e73c7afe54aa1bde4dd035086e), [`34c3c14e0a1491ab80473605018b97981544167d`](https://github.com/medusajs/medusa/commit/34c3c14e0a1491ab80473605018b97981544167d), [`ff152e7ace60232c02932bbd06a759e555a823d4`](https://github.com/medusajs/medusa/commit/ff152e7ace60232c02932bbd06a759e555a823d4), [`eb376eb4cf9cc6fe0ce2a6724e0df81b27bc7b87`](https://github.com/medusajs/medusa/commit/eb376eb4cf9cc6fe0ce2a6724e0df81b27bc7b87), [`4b3c43fe92d99a98b3d7b9ee6705114de01cbc5d`](https://github.com/medusajs/medusa/commit/4b3c43fe92d99a98b3d7b9ee6705114de01cbc5d), [`492e0189573ffad4977a3559d71f39bf94d8b45d`](https://github.com/medusajs/medusa/commit/492e0189573ffad4977a3559d71f39bf94d8b45d), [`6264a6262b0220c70ad35c0d56a93a39218ccb80`](https://github.com/medusajs/medusa/commit/6264a6262b0220c70ad35c0d56a93a39218ccb80), [`be62cf87c7ed975bd0880133588cc806751715cb`](https://github.com/medusajs/medusa/commit/be62cf87c7ed975bd0880133588cc806751715cb), [`6602e893b88f1c8f0c8165101dd609baaf60d925`](https://github.com/medusajs/medusa/commit/6602e893b88f1c8f0c8165101dd609baaf60d925), [`fd4e79142880f1b2da63a38adef8c647da9c48e4`](https://github.com/medusajs/medusa/commit/fd4e79142880f1b2da63a38adef8c647da9c48e4)]:
  - @medusajs/promotion@2.10.0
  - @medusajs/core-flows@2.10.0
  - @medusajs/modules-sdk@2.10.0
  - @medusajs/utils@2.10.0
  - @medusajs/medusa@2.10.0
  - @medusajs/test-utils@2.10.0
  - @medusajs/fulfillment@2.10.0
  - @medusajs/workflow-engine-inmemory@2.10.0
  - @medusajs/pricing@2.10.0
  - @medusajs/event-bus-local@2.10.0
  - @medusajs/api-key@2.10.0
  - @medusajs/auth@2.10.0
  - @medusajs/cache-inmemory@2.10.0
  - @medusajs/customer@2.10.0
  - @medusajs/inventory@2.10.0
  - @medusajs/product@2.10.0
  - @medusajs/fulfillment-manual@2.10.0
  - @medusajs/region@2.10.0
  - @medusajs/stock-location@2.10.0
  - @medusajs/store@2.10.0
  - @medusajs/tax@2.10.0
  - @medusajs/user@2.10.0

## 1.0.21

### Patch Changes

- [#13131](https://github.com/medusajs/medusa/pull/13131) [`51d4751d9502c0996ee5640f29d0253da980082a`](https://github.com/medusajs/medusa/commit/51d4751d9502c0996ee5640f29d0253da980082a) Thanks [@scherddel](https://github.com/scherddel)! - Fix on precision for high quantities for items when promotion is applied

- [#12960](https://github.com/medusajs/medusa/pull/12960) [`1bdf602f1c1da181e2839858d2f7e8aea503573a`](https://github.com/medusajs/medusa/commit/1bdf602f1c1da181e2839858d2f7e8aea503573a) Thanks [@scherddel](https://github.com/scherddel)! - This fixes the discount\_ calculation logic and promotion tax inclusiveness calculation

- Updated dependencies [[`a52708769da675e2ade6cb6fe28e1cd9741c562d`](https://github.com/medusajs/medusa/commit/a52708769da675e2ade6cb6fe28e1cd9741c562d), [`9fb5baa912674b6d35492b147e0f22d8f8330a24`](https://github.com/medusajs/medusa/commit/9fb5baa912674b6d35492b147e0f22d8f8330a24), [`02dd83f59a0f02badd99f6e05c083aabbe6daa96`](https://github.com/medusajs/medusa/commit/02dd83f59a0f02badd99f6e05c083aabbe6daa96), [`93d7a93b2806d7e7660a6702c9e9b60d01dfe936`](https://github.com/medusajs/medusa/commit/93d7a93b2806d7e7660a6702c9e9b60d01dfe936), [`f6736d96616aaff51399b2733905f9e340efc8be`](https://github.com/medusajs/medusa/commit/f6736d96616aaff51399b2733905f9e340efc8be), [`51d4751d9502c0996ee5640f29d0253da980082a`](https://github.com/medusajs/medusa/commit/51d4751d9502c0996ee5640f29d0253da980082a), [`acf6bbc2ec1d90e3b0100c86f56e96b38fa7c67a`](https://github.com/medusajs/medusa/commit/acf6bbc2ec1d90e3b0100c86f56e96b38fa7c67a), [`1bdf602f1c1da181e2839858d2f7e8aea503573a`](https://github.com/medusajs/medusa/commit/1bdf602f1c1da181e2839858d2f7e8aea503573a), [`75320e744f680afba06d8ad852f169242736fb19`](https://github.com/medusajs/medusa/commit/75320e744f680afba06d8ad852f169242736fb19), [`6e66e36d0814a524440c05a99c849c3d62e48ed3`](https://github.com/medusajs/medusa/commit/6e66e36d0814a524440c05a99c849c3d62e48ed3), [`9766570827ebf50d49d8daf956deecce6666a8cc`](https://github.com/medusajs/medusa/commit/9766570827ebf50d49d8daf956deecce6666a8cc), [`b1cba9fdeba901c9d4c7bddd414ed2fd085fa7b0`](https://github.com/medusajs/medusa/commit/b1cba9fdeba901c9d4c7bddd414ed2fd085fa7b0)]:
  - @medusajs/utils@2.9.0
  - @medusajs/core-flows@2.9.0
  - @medusajs/pricing@2.9.0
  - @medusajs/promotion@2.9.0
  - @medusajs/medusa@2.9.0
  - @medusajs/workflow-engine-inmemory@2.9.0
  - @medusajs/modules-sdk@2.9.0
  - @medusajs/test-utils@2.9.0
  - @medusajs/api-key@2.9.0
  - @medusajs/auth@2.9.0
  - @medusajs/cache-inmemory@2.9.0
  - @medusajs/customer@2.9.0
  - @medusajs/event-bus-local@2.9.0
  - @medusajs/fulfillment@2.9.0
  - @medusajs/inventory@2.9.0
  - @medusajs/product@2.9.0
  - @medusajs/fulfillment-manual@2.9.0
  - @medusajs/region@2.9.0
  - @medusajs/stock-location@2.9.0
  - @medusajs/store@2.9.0
  - @medusajs/tax@2.9.0
  - @medusajs/user@2.9.0

## 1.0.20

### Patch Changes

- Updated dependencies [[`a28226af80a8880afbdb926a5001f0cb0d89fdc9`](https://github.com/medusajs/medusa/commit/a28226af80a8880afbdb926a5001f0cb0d89fdc9), [`40625c82d6deb28ecb4e4c0f911c28fdd7356bf7`](https://github.com/medusajs/medusa/commit/40625c82d6deb28ecb4e4c0f911c28fdd7356bf7), [`822217fa366d4399d3f6a0407451c9649197d5d9`](https://github.com/medusajs/medusa/commit/822217fa366d4399d3f6a0407451c9649197d5d9), [`7b1debfe12fc096f7b4e20f13bdeb925c96085c1`](https://github.com/medusajs/medusa/commit/7b1debfe12fc096f7b4e20f13bdeb925c96085c1), [`eb83954f23077c0714125b6f2f19fd0ef0f288f9`](https://github.com/medusajs/medusa/commit/eb83954f23077c0714125b6f2f19fd0ef0f288f9), [`8c4228fc42e717f9ab72230040e708f606a585b7`](https://github.com/medusajs/medusa/commit/8c4228fc42e717f9ab72230040e708f606a585b7), [`439c7118450c5f9ee0b541de9014093a42b7d0ea`](https://github.com/medusajs/medusa/commit/439c7118450c5f9ee0b541de9014093a42b7d0ea), [`238e7d53c13a1c033886d7c33254919f8b5b22dc`](https://github.com/medusajs/medusa/commit/238e7d53c13a1c033886d7c33254919f8b5b22dc), [`7669dbb03e2f65fa76cff1c5b90a0777e475cb47`](https://github.com/medusajs/medusa/commit/7669dbb03e2f65fa76cff1c5b90a0777e475cb47), [`c5d609d09cb29c6cf01d1c6c65305cc566f391c5`](https://github.com/medusajs/medusa/commit/c5d609d09cb29c6cf01d1c6c65305cc566f391c5), [`2c2528a08751945d6f0363473605f1a8ef1a8a2a`](https://github.com/medusajs/medusa/commit/2c2528a08751945d6f0363473605f1a8ef1a8a2a)]:
  - @medusajs/core-flows@2.8.8
  - @medusajs/pricing@2.8.8
  - @medusajs/workflow-engine-inmemory@2.8.8
  - @medusajs/product@2.8.8
  - @medusajs/utils@2.8.8
  - @medusajs/test-utils@2.8.8
  - @medusajs/modules-sdk@2.8.8
  - @medusajs/medusa@2.8.8
  - @medusajs/api-key@2.8.8
  - @medusajs/auth@2.8.8
  - @medusajs/cache-inmemory@2.8.8
  - @medusajs/customer@2.8.8
  - @medusajs/event-bus-local@2.8.8
  - @medusajs/fulfillment@2.8.8
  - @medusajs/inventory@2.8.8
  - @medusajs/promotion@2.8.8
  - @medusajs/fulfillment-manual@2.8.8
  - @medusajs/region@2.8.8
  - @medusajs/stock-location@2.8.8
  - @medusajs/store@2.8.8
  - @medusajs/tax@2.8.8
  - @medusajs/user@2.8.8

## 1.0.19

### Patch Changes

- Updated dependencies [[`e9a33d0700c47c3d2357bb325791bc272a4d4569`](https://github.com/medusajs/medusa/commit/e9a33d0700c47c3d2357bb325791bc272a4d4569), [`46bf7ae7aead3f33485ce8adebb602eda305088c`](https://github.com/medusajs/medusa/commit/46bf7ae7aead3f33485ce8adebb602eda305088c), [`2f70f133511857b499a992b65a0a4d6170e03ab9`](https://github.com/medusajs/medusa/commit/2f70f133511857b499a992b65a0a4d6170e03ab9), [`fa76f85bba253528964bacf86c061fef6d3d0742`](https://github.com/medusajs/medusa/commit/fa76f85bba253528964bacf86c061fef6d3d0742), [`42be9a88d61a11db7aebde2d6f4d96d43f54ea79`](https://github.com/medusajs/medusa/commit/42be9a88d61a11db7aebde2d6f4d96d43f54ea79)]:
  - @medusajs/test-utils@2.8.7
  - @medusajs/core-flows@2.8.7
  - @medusajs/api-key@2.8.7
  - @medusajs/auth@2.8.7
  - @medusajs/fulfillment@2.8.7
  - @medusajs/inventory@2.8.7
  - @medusajs/pricing@2.8.7
  - @medusajs/product@2.8.7
  - @medusajs/promotion@2.8.7
  - @medusajs/region@2.8.7
  - @medusajs/stock-location@2.8.7
  - @medusajs/store@2.8.7
  - @medusajs/medusa@2.8.7
  - @medusajs/customer@2.8.7
  - @medusajs/tax@2.8.7
  - @medusajs/user@2.8.7
  - @medusajs/workflow-engine-inmemory@2.8.7
  - @medusajs/modules-sdk@2.8.7
  - @medusajs/utils@2.8.7
  - @medusajs/cache-inmemory@2.8.7
  - @medusajs/event-bus-local@2.8.7
  - @medusajs/fulfillment-manual@2.8.7

## 1.0.18

### Patch Changes

- Updated dependencies [[`9a62f359f1c954bcc09c57e4660f90d4b010e51c`](https://github.com/medusajs/medusa/commit/9a62f359f1c954bcc09c57e4660f90d4b010e51c), [`95d282e8ef8f2185737d493dea8b6f1677684543`](https://github.com/medusajs/medusa/commit/95d282e8ef8f2185737d493dea8b6f1677684543)]:
  - @medusajs/core-flows@2.8.6
  - @medusajs/utils@2.8.6
  - @medusajs/test-utils@2.8.6
  - @medusajs/workflow-engine-inmemory@2.8.6
  - @medusajs/medusa@2.8.6
  - @medusajs/modules-sdk@2.8.6
  - @medusajs/api-key@2.8.6
  - @medusajs/auth@2.8.6
  - @medusajs/customer@2.8.6
  - @medusajs/fulfillment@2.8.6
  - @medusajs/inventory@2.8.6
  - @medusajs/pricing@2.8.6
  - @medusajs/product@2.8.6
  - @medusajs/promotion@2.8.6
  - @medusajs/region@2.8.6
  - @medusajs/stock-location@2.8.6
  - @medusajs/store@2.8.6
  - @medusajs/tax@2.8.6
  - @medusajs/user@2.8.6
  - @medusajs/cache-inmemory@2.8.6
  - @medusajs/event-bus-local@2.8.6
  - @medusajs/fulfillment-manual@2.8.6

## 1.0.17

### Patch Changes

- [#12815](https://github.com/medusajs/medusa/pull/12815) [`6ca755ede7bfe3211464447412ca0d97e1207742`](https://github.com/medusajs/medusa/commit/6ca755ede7bfe3211464447412ca0d97e1207742) Thanks [@anteprimorac](https://github.com/anteprimorac)! - Enable filtering admin products API by variant EAN, UPC, and barcode

- [#12643](https://github.com/medusajs/medusa/pull/12643) [`f2cb528a5650fe112ca8eeb4bdffc5f0b217338a`](https://github.com/medusajs/medusa/commit/f2cb528a5650fe112ca8eeb4bdffc5f0b217338a) Thanks [@thetutlage](https://github.com/thetutlage)! - feat: wire up direct uploads with local file provider

- Updated dependencies [[`ab634a14ba709f1b1d12eb4cd5c7f3db6bfe6470`](https://github.com/medusajs/medusa/commit/ab634a14ba709f1b1d12eb4cd5c7f3db6bfe6470), [`6ca755ede7bfe3211464447412ca0d97e1207742`](https://github.com/medusajs/medusa/commit/6ca755ede7bfe3211464447412ca0d97e1207742), [`ba1e6595b74ae69f4ee066d545f8def8aff77dd3`](https://github.com/medusajs/medusa/commit/ba1e6595b74ae69f4ee066d545f8def8aff77dd3), [`f2cb528a5650fe112ca8eeb4bdffc5f0b217338a`](https://github.com/medusajs/medusa/commit/f2cb528a5650fe112ca8eeb4bdffc5f0b217338a), [`cbf3644eb7c8a24eaed879647b58c9ece3373c0e`](https://github.com/medusajs/medusa/commit/cbf3644eb7c8a24eaed879647b58c9ece3373c0e), [`d517dbd66a47817d1270c278b03add9a5c4244cb`](https://github.com/medusajs/medusa/commit/d517dbd66a47817d1270c278b03add9a5c4244cb), [`b316924572fc2cf529e0d91b84955da20b34248a`](https://github.com/medusajs/medusa/commit/b316924572fc2cf529e0d91b84955da20b34248a), [`2621f00bb035a6b909f9498a2bc98fdba8570ba9`](https://github.com/medusajs/medusa/commit/2621f00bb035a6b909f9498a2bc98fdba8570ba9), [`672871b733c6e82bd9e68cf90300ff78cf44727a`](https://github.com/medusajs/medusa/commit/672871b733c6e82bd9e68cf90300ff78cf44727a), [`bd6d9777c50d69115a20334a103a8ab9997b259d`](https://github.com/medusajs/medusa/commit/bd6d9777c50d69115a20334a103a8ab9997b259d), [`316a325b63e92003df25452faf88e577e9133064`](https://github.com/medusajs/medusa/commit/316a325b63e92003df25452faf88e577e9133064), [`94b62c67249d13ec6342411cf7efdedfd0ac47e1`](https://github.com/medusajs/medusa/commit/94b62c67249d13ec6342411cf7efdedfd0ac47e1), [`1a7847660890ae84648123567ce8dc4c9a0eca03`](https://github.com/medusajs/medusa/commit/1a7847660890ae84648123567ce8dc4c9a0eca03)]:
  - @medusajs/utils@2.8.5
  - @medusajs/auth@2.8.5
  - @medusajs/customer@2.8.5
  - @medusajs/fulfillment@2.8.5
  - @medusajs/inventory@2.8.5
  - @medusajs/medusa@2.8.5
  - @medusajs/core-flows@2.8.5
  - @medusajs/test-utils@2.8.5
  - @medusajs/user@2.8.5
  - @medusajs/modules-sdk@2.8.5
  - @medusajs/promotion@2.8.5
  - @medusajs/workflow-engine-inmemory@2.8.5
  - @medusajs/api-key@2.8.5
  - @medusajs/pricing@2.8.5
  - @medusajs/product@2.8.5
  - @medusajs/region@2.8.5
  - @medusajs/stock-location@2.8.5
  - @medusajs/store@2.8.5
  - @medusajs/tax@2.8.5
  - @medusajs/cache-inmemory@2.8.5
  - @medusajs/event-bus-local@2.8.5
  - @medusajs/fulfillment-manual@2.8.5

## 1.0.16

### Patch Changes

- Updated dependencies [[`da5e278a783010e886fbae96c4b704bc9fcf78e5`](https://github.com/medusajs/medusa/commit/da5e278a783010e886fbae96c4b704bc9fcf78e5), [`791276e80f5745c8885352b7979c0faa979110f4`](https://github.com/medusajs/medusa/commit/791276e80f5745c8885352b7979c0faa979110f4), [`c4dd29046183bfe3c99b7ec00414449e53478d22`](https://github.com/medusajs/medusa/commit/c4dd29046183bfe3c99b7ec00414449e53478d22), [`3d65807d9924c057ccce6ccaf1c6e0eee8e7c245`](https://github.com/medusajs/medusa/commit/3d65807d9924c057ccce6ccaf1c6e0eee8e7c245), [`f6f34cc0e419a0c4be0971f13eb59b2a1e3aa31d`](https://github.com/medusajs/medusa/commit/f6f34cc0e419a0c4be0971f13eb59b2a1e3aa31d), [`490bd7647fca30951d14c7c78c1b809379ebd870`](https://github.com/medusajs/medusa/commit/490bd7647fca30951d14c7c78c1b809379ebd870), [`cf0297f74af1b043363ffbd5a23ca0933097a69d`](https://github.com/medusajs/medusa/commit/cf0297f74af1b043363ffbd5a23ca0933097a69d)]:
  - @medusajs/modules-sdk@2.8.4
  - @medusajs/utils@2.8.4
  - @medusajs/core-flows@2.8.4
  - @medusajs/medusa@2.8.4
  - @medusajs/test-utils@2.8.4
  - @medusajs/api-key@2.8.4
  - @medusajs/auth@2.8.4
  - @medusajs/cache-inmemory@2.8.4
  - @medusajs/customer@2.8.4
  - @medusajs/event-bus-local@2.8.4
  - @medusajs/fulfillment@2.8.4
  - @medusajs/inventory@2.8.4
  - @medusajs/pricing@2.8.4
  - @medusajs/product@2.8.4
  - @medusajs/promotion@2.8.4
  - @medusajs/fulfillment-manual@2.8.4
  - @medusajs/region@2.8.4
  - @medusajs/stock-location@2.8.4
  - @medusajs/store@2.8.4
  - @medusajs/tax@2.8.4
  - @medusajs/user@2.8.4
  - @medusajs/workflow-engine-inmemory@2.8.4

## 1.0.15

### Patch Changes

- [#12527](https://github.com/medusajs/medusa/pull/12527) [`fca5ad77b41856867ec68b1e46d04f1bb71cbc76`](https://github.com/medusajs/medusa/commit/fca5ad77b41856867ec68b1e46d04f1bb71cbc76) Thanks [@thetutlage](https://github.com/thetutlage)! - feat: process import from pre-processed chunks

- [#12516](https://github.com/medusajs/medusa/pull/12516) [`5cd4ff6fe75c6be4ac33820a2e22654fc2508b4e`](https://github.com/medusajs/medusa/commit/5cd4ff6fe75c6be4ac33820a2e22654fc2508b4e) Thanks [@thetutlage](https://github.com/thetutlage)! - test: remove snapshots usage

- Updated dependencies [[`d9fdabe96d05108355c01081ea15d39467e40268`](https://github.com/medusajs/medusa/commit/d9fdabe96d05108355c01081ea15d39467e40268), [`fca5ad77b41856867ec68b1e46d04f1bb71cbc76`](https://github.com/medusajs/medusa/commit/fca5ad77b41856867ec68b1e46d04f1bb71cbc76), [`4e49cebcf0f053cb89012276e935a7ec62a12046`](https://github.com/medusajs/medusa/commit/4e49cebcf0f053cb89012276e935a7ec62a12046), [`59bbff62d81861282d55a32d6c0c45285203c4e0`](https://github.com/medusajs/medusa/commit/59bbff62d81861282d55a32d6c0c45285203c4e0), [`52bd9f9a53f6e63e5fbe0beb1fb2c650d88f7c88`](https://github.com/medusajs/medusa/commit/52bd9f9a53f6e63e5fbe0beb1fb2c650d88f7c88), [`32be40a2c09be2f793b5d348a3dd62e9312f46c9`](https://github.com/medusajs/medusa/commit/32be40a2c09be2f793b5d348a3dd62e9312f46c9), [`ebe5cc7acddb7c61dc82fd8ec7f2fe3779104a99`](https://github.com/medusajs/medusa/commit/ebe5cc7acddb7c61dc82fd8ec7f2fe3779104a99), [`41054a34199168f0b949c3cda0bbe667da2c5993`](https://github.com/medusajs/medusa/commit/41054a34199168f0b949c3cda0bbe667da2c5993), [`85d2b3c992cf361a9a18a14659484c57f4923197`](https://github.com/medusajs/medusa/commit/85d2b3c992cf361a9a18a14659484c57f4923197), [`c5a6573e26b403b86f53b88c307ea311a1bd9230`](https://github.com/medusajs/medusa/commit/c5a6573e26b403b86f53b88c307ea311a1bd9230), [`3071d09a03205597158afe79d55dd43643a97026`](https://github.com/medusajs/medusa/commit/3071d09a03205597158afe79d55dd43643a97026)]:
  - @medusajs/medusa@2.8.3
  - @medusajs/core-flows@2.8.3
  - @medusajs/utils@2.8.3
  - @medusajs/modules-sdk@2.8.3
  - @medusajs/product@2.8.3
  - @medusajs/test-utils@2.8.3
  - @medusajs/api-key@2.8.3
  - @medusajs/auth@2.8.3
  - @medusajs/customer@2.8.3
  - @medusajs/fulfillment@2.8.3
  - @medusajs/inventory@2.8.3
  - @medusajs/pricing@2.8.3
  - @medusajs/promotion@2.8.3
  - @medusajs/region@2.8.3
  - @medusajs/stock-location@2.8.3
  - @medusajs/store@2.8.3
  - @medusajs/tax@2.8.3
  - @medusajs/user@2.8.3
  - @medusajs/workflow-engine-inmemory@2.8.3
  - @medusajs/cache-inmemory@2.8.3
  - @medusajs/event-bus-local@2.8.3
  - @medusajs/fulfillment-manual@2.8.3

## 1.0.14

### Patch Changes

- [#12473](https://github.com/medusajs/medusa/pull/12473) [`e149a998862272fff80573a623c4d9010cb0b104`](https://github.com/medusajs/medusa/commit/e149a998862272fff80573a623c4d9010cb0b104) Thanks [@thetutlage](https://github.com/thetutlage)! - feat: define validators and use normalize-products step

- Updated dependencies [[`9f4d32b2201d8c87d84c59b9a1ca59e00bcc6af1`](https://github.com/medusajs/medusa/commit/9f4d32b2201d8c87d84c59b9a1ca59e00bcc6af1), [`e149a998862272fff80573a623c4d9010cb0b104`](https://github.com/medusajs/medusa/commit/e149a998862272fff80573a623c4d9010cb0b104)]:
  - @medusajs/core-flows@2.8.2
  - @medusajs/utils@2.8.2
  - @medusajs/modules-sdk@2.8.2
  - @medusajs/medusa@2.8.2
  - @medusajs/test-utils@2.8.2
  - @medusajs/api-key@2.8.2
  - @medusajs/auth@2.8.2
  - @medusajs/cache-inmemory@2.8.2
  - @medusajs/customer@2.8.2
  - @medusajs/event-bus-local@2.8.2
  - @medusajs/fulfillment@2.8.2
  - @medusajs/inventory@2.8.2
  - @medusajs/pricing@2.8.2
  - @medusajs/product@2.8.2
  - @medusajs/promotion@2.8.2
  - @medusajs/fulfillment-manual@2.8.2
  - @medusajs/region@2.8.2
  - @medusajs/stock-location@2.8.2
  - @medusajs/store@2.8.2
  - @medusajs/tax@2.8.2
  - @medusajs/user@2.8.2
  - @medusajs/workflow-engine-inmemory@2.8.2

## 1.0.13

### Patch Changes

- Updated dependencies [[`4602163b568962f8115b83971d67a6c55c2b8a98`](https://github.com/medusajs/medusa/commit/4602163b568962f8115b83971d67a6c55c2b8a98), [`ab22faaa52008ad952d50f0a3b6b1148515b10c9`](https://github.com/medusajs/medusa/commit/ab22faaa52008ad952d50f0a3b6b1148515b10c9), [`142a1f0a5be60d2cc013ecb174bca7b1381c6551`](https://github.com/medusajs/medusa/commit/142a1f0a5be60d2cc013ecb174bca7b1381c6551)]:
  - @medusajs/core-flows@2.8.1
  - @medusajs/utils@2.8.1
  - @medusajs/test-utils@2.8.1
  - @medusajs/workflow-engine-inmemory@2.8.1
  - @medusajs/product@2.8.1
  - @medusajs/medusa@2.8.1
  - @medusajs/modules-sdk@2.8.1
  - @medusajs/api-key@2.8.1
  - @medusajs/auth@2.8.1
  - @medusajs/customer@2.8.1
  - @medusajs/fulfillment@2.8.1
  - @medusajs/inventory@2.8.1
  - @medusajs/pricing@2.8.1
  - @medusajs/promotion@2.8.1
  - @medusajs/region@2.8.1
  - @medusajs/stock-location@2.8.1
  - @medusajs/store@2.8.1
  - @medusajs/tax@2.8.1
  - @medusajs/user@2.8.1
  - @medusajs/cache-inmemory@2.8.1
  - @medusajs/event-bus-local@2.8.1
  - @medusajs/fulfillment-manual@2.8.1

## 1.0.12

### Patch Changes

- Updated dependencies [[`469ecef3c52797b812c9cb8a4410f632e8de8b8c`](https://github.com/medusajs/medusa/commit/469ecef3c52797b812c9cb8a4410f632e8de8b8c), [`0d8af119c5f000addcbc2431c61711b51e7b34b1`](https://github.com/medusajs/medusa/commit/0d8af119c5f000addcbc2431c61711b51e7b34b1), [`77c3023200f5c718a77220f39b300e9149a92a4f`](https://github.com/medusajs/medusa/commit/77c3023200f5c718a77220f39b300e9149a92a4f), [`aba4cba373aa6499ca7cce77e7515613c38c681d`](https://github.com/medusajs/medusa/commit/aba4cba373aa6499ca7cce77e7515613c38c681d), [`2dd885ebc12303b9b1741a2785560da44d4e4e28`](https://github.com/medusajs/medusa/commit/2dd885ebc12303b9b1741a2785560da44d4e4e28), [`a53d645f8aab30135baebac29f9645dd35d47632`](https://github.com/medusajs/medusa/commit/a53d645f8aab30135baebac29f9645dd35d47632), [`90c61d189806894c56bfd5686807406c800cfdeb`](https://github.com/medusajs/medusa/commit/90c61d189806894c56bfd5686807406c800cfdeb), [`c4dd805849fee483d52ee61078e15f9be111b414`](https://github.com/medusajs/medusa/commit/c4dd805849fee483d52ee61078e15f9be111b414), [`cb53b8a5290708b395e1cf1f1a75ec6ff518f7b7`](https://github.com/medusajs/medusa/commit/cb53b8a5290708b395e1cf1f1a75ec6ff518f7b7), [`89859987565b1fc872c7cd1c6d23144b97f454bc`](https://github.com/medusajs/medusa/commit/89859987565b1fc872c7cd1c6d23144b97f454bc), [`2c49e8b7332420c9fc949f9429a339fcbf5637af`](https://github.com/medusajs/medusa/commit/2c49e8b7332420c9fc949f9429a339fcbf5637af), [`9cedeb182dc19d6127b602fc06e4b8850490e2a9`](https://github.com/medusajs/medusa/commit/9cedeb182dc19d6127b602fc06e4b8850490e2a9), [`e4d853185f103ffc81fcf14df02e84cd5c538f9a`](https://github.com/medusajs/medusa/commit/e4d853185f103ffc81fcf14df02e84cd5c538f9a), [`d7a273ff2def96420054f31114a46294be6ee968`](https://github.com/medusajs/medusa/commit/d7a273ff2def96420054f31114a46294be6ee968), [`32e0194772cd44efa1930f2ee99f147fa2976f1f`](https://github.com/medusajs/medusa/commit/32e0194772cd44efa1930f2ee99f147fa2976f1f), [`fff285f8d2f3020a24b83066fa4250130fdcf229`](https://github.com/medusajs/medusa/commit/fff285f8d2f3020a24b83066fa4250130fdcf229), [`b868a4ef4deb7df09d6156a907f4c883cd55a3fd`](https://github.com/medusajs/medusa/commit/b868a4ef4deb7df09d6156a907f4c883cd55a3fd), [`80007f3afda76eabd5b148fa6bb5590fa6987265`](https://github.com/medusajs/medusa/commit/80007f3afda76eabd5b148fa6bb5590fa6987265), [`9d4bc81d0f1ac1614ab1ffb95d708f622c836ceb`](https://github.com/medusajs/medusa/commit/9d4bc81d0f1ac1614ab1ffb95d708f622c836ceb), [`5fe0e8250d0255866a68db32d4b54dab8ab66e52`](https://github.com/medusajs/medusa/commit/5fe0e8250d0255866a68db32d4b54dab8ab66e52)]:
  - @medusajs/medusa@2.8.0
  - @medusajs/core-flows@2.8.0
  - @medusajs/product@2.8.0
  - @medusajs/utils@2.8.0
  - @medusajs/tax@2.8.0
  - @medusajs/pricing@2.8.0
  - @medusajs/modules-sdk@2.8.0
  - @medusajs/workflow-engine-inmemory@2.8.0
  - @medusajs/test-utils@2.8.0
  - @medusajs/api-key@2.8.0
  - @medusajs/auth@2.8.0
  - @medusajs/cache-inmemory@2.8.0
  - @medusajs/customer@2.8.0
  - @medusajs/event-bus-local@2.8.0
  - @medusajs/fulfillment@2.8.0
  - @medusajs/inventory@2.8.0
  - @medusajs/promotion@2.8.0
  - @medusajs/fulfillment-manual@2.8.0
  - @medusajs/region@2.8.0
  - @medusajs/stock-location@2.8.0
  - @medusajs/store@2.8.0
  - @medusajs/user@2.8.0

## 1.0.11

### Patch Changes

- Updated dependencies [[`24af8f2d8e27d0f842e6e596bc4c695882f67737`](https://github.com/medusajs/medusa/commit/24af8f2d8e27d0f842e6e596bc4c695882f67737), [`01542f69737b48346d924670296c551e4c4b47ec`](https://github.com/medusajs/medusa/commit/01542f69737b48346d924670296c551e4c4b47ec), [`413a0da26c7e9acffe9cc087fd77500efc76191a`](https://github.com/medusajs/medusa/commit/413a0da26c7e9acffe9cc087fd77500efc76191a), [`2f6963a5fbea05537680cb1b1f6a2b9822c36325`](https://github.com/medusajs/medusa/commit/2f6963a5fbea05537680cb1b1f6a2b9822c36325), [`b8902637251e9ed4f8762ef280659bbab6d967de`](https://github.com/medusajs/medusa/commit/b8902637251e9ed4f8762ef280659bbab6d967de), [`ad74ba2ca4c86b38c91c342edfad077cd132cc2f`](https://github.com/medusajs/medusa/commit/ad74ba2ca4c86b38c91c342edfad077cd132cc2f), [`8618e6ee3843069ea189ea64d5191d93db52dc9d`](https://github.com/medusajs/medusa/commit/8618e6ee3843069ea189ea64d5191d93db52dc9d), [`19d71fdc63547886cfc238c6b680370a80d50b50`](https://github.com/medusajs/medusa/commit/19d71fdc63547886cfc238c6b680370a80d50b50)]:
  - @medusajs/core-flows@2.7.1
  - @medusajs/medusa@2.7.1
  - @medusajs/event-bus-local@2.7.1
  - @medusajs/test-utils@2.7.1
  - @medusajs/modules-sdk@2.7.1
  - @medusajs/utils@2.7.1
  - @medusajs/workflow-engine-inmemory@2.7.1
  - @medusajs/api-key@2.7.1
  - @medusajs/auth@2.7.1
  - @medusajs/cache-inmemory@2.7.1
  - @medusajs/customer@2.7.1
  - @medusajs/fulfillment@2.7.1
  - @medusajs/inventory@2.7.1
  - @medusajs/pricing@2.7.1
  - @medusajs/product@2.7.1
  - @medusajs/promotion@2.7.1
  - @medusajs/fulfillment-manual@2.7.1
  - @medusajs/region@2.7.1
  - @medusajs/stock-location@2.7.1
  - @medusajs/store@2.7.1
  - @medusajs/tax@2.7.1
  - @medusajs/user@2.7.1

## 1.0.10

### Patch Changes

- Updated dependencies [[`386205d0f41828b82d519d2f5b8e07b41907a8ae`](https://github.com/medusajs/medusa/commit/386205d0f41828b82d519d2f5b8e07b41907a8ae), [`07252691c59f0e945730e987d0f1a97976b4c7f0`](https://github.com/medusajs/medusa/commit/07252691c59f0e945730e987d0f1a97976b4c7f0), [`74381addc3d6af42f0292e778948aabb60a6dad9`](https://github.com/medusajs/medusa/commit/74381addc3d6af42f0292e778948aabb60a6dad9), [`ec56a8bc857a74788df6523af25914da95c4c1d8`](https://github.com/medusajs/medusa/commit/ec56a8bc857a74788df6523af25914da95c4c1d8), [`2a18a75353f872b0cb4c203afc08cfd82f778428`](https://github.com/medusajs/medusa/commit/2a18a75353f872b0cb4c203afc08cfd82f778428), [`5f3a82f5c341d4a98a7a2ab92563f6cdae1cdce1`](https://github.com/medusajs/medusa/commit/5f3a82f5c341d4a98a7a2ab92563f6cdae1cdce1), [`72d2cf92075b3e0849251f233517e2972de1b19c`](https://github.com/medusajs/medusa/commit/72d2cf92075b3e0849251f233517e2972de1b19c), [`95e89a39f347c8af6a5960943af56965bc3a07ba`](https://github.com/medusajs/medusa/commit/95e89a39f347c8af6a5960943af56965bc3a07ba), [`b1b3b484747a110f720d9c1d086696bbfba86bda`](https://github.com/medusajs/medusa/commit/b1b3b484747a110f720d9c1d086696bbfba86bda), [`67b308c8eb52950991df34ac1c8d007a14cfaa1e`](https://github.com/medusajs/medusa/commit/67b308c8eb52950991df34ac1c8d007a14cfaa1e), [`c3440e5e3812e3d1c6b82e9d4e41287398451611`](https://github.com/medusajs/medusa/commit/c3440e5e3812e3d1c6b82e9d4e41287398451611), [`3dba58785fb2d8e79f1ea89daa9e4ab8810821c8`](https://github.com/medusajs/medusa/commit/3dba58785fb2d8e79f1ea89daa9e4ab8810821c8), [`0625f76cd4f040963829b61dcc70563e1d1b7070`](https://github.com/medusajs/medusa/commit/0625f76cd4f040963829b61dcc70563e1d1b7070), [`1895d8cc1141b28525acfc21715f6f523b8194a2`](https://github.com/medusajs/medusa/commit/1895d8cc1141b28525acfc21715f6f523b8194a2), [`cae47d9e49e9a17d8395f7b390f6ec0a2f9b8dc2`](https://github.com/medusajs/medusa/commit/cae47d9e49e9a17d8395f7b390f6ec0a2f9b8dc2), [`3a1cf2212ac3d92eebee1bbea07e8731e53e4c72`](https://github.com/medusajs/medusa/commit/3a1cf2212ac3d92eebee1bbea07e8731e53e4c72), [`d87b25203c3e1aa9b975dc68818d66fe877657a6`](https://github.com/medusajs/medusa/commit/d87b25203c3e1aa9b975dc68818d66fe877657a6), [`5cf0bf4d93b5fd965680223dd448324c5135426e`](https://github.com/medusajs/medusa/commit/5cf0bf4d93b5fd965680223dd448324c5135426e), [`cb26c224ea3e0e06fa9efb1c317d4529bfcb2d49`](https://github.com/medusajs/medusa/commit/cb26c224ea3e0e06fa9efb1c317d4529bfcb2d49), [`79cfc1a69ee166fec298aa706b994253a1284520`](https://github.com/medusajs/medusa/commit/79cfc1a69ee166fec298aa706b994253a1284520), [`cb6249320e7322e8eabfec8434f1278f8d63e96c`](https://github.com/medusajs/medusa/commit/cb6249320e7322e8eabfec8434f1278f8d63e96c), [`1f8fab36361aa8e473ffe6c411c8598a916a6d3f`](https://github.com/medusajs/medusa/commit/1f8fab36361aa8e473ffe6c411c8598a916a6d3f), [`375c4a5ab1b2805ef2a3d792327c325fa11740a5`](https://github.com/medusajs/medusa/commit/375c4a5ab1b2805ef2a3d792327c325fa11740a5), [`13e159d8ad7ebb3e6977969b4bb10877d7bb7850`](https://github.com/medusajs/medusa/commit/13e159d8ad7ebb3e6977969b4bb10877d7bb7850), [`6015dcc16d6d9af15575bee98fb5727c6a6d9fd2`](https://github.com/medusajs/medusa/commit/6015dcc16d6d9af15575bee98fb5727c6a6d9fd2), [`2f7eb0ee030966844b45dd00b2259e68b9fb0e83`](https://github.com/medusajs/medusa/commit/2f7eb0ee030966844b45dd00b2259e68b9fb0e83), [`8385a5e34d9528eb3d80d16f391ee7f44a6e5d90`](https://github.com/medusajs/medusa/commit/8385a5e34d9528eb3d80d16f391ee7f44a6e5d90), [`a8513019db08d1345e79a15aea7f11389b4918d4`](https://github.com/medusajs/medusa/commit/a8513019db08d1345e79a15aea7f11389b4918d4), [`9dd62d93bd9e2acccc2e9f22bc029fd2b0df3234`](https://github.com/medusajs/medusa/commit/9dd62d93bd9e2acccc2e9f22bc029fd2b0df3234), [`01089d5bc81bc92311bb43b2d57d987fee378030`](https://github.com/medusajs/medusa/commit/01089d5bc81bc92311bb43b2d57d987fee378030), [`6ae1e7b708f6be5faabeb26c94f99054c3dcd144`](https://github.com/medusajs/medusa/commit/6ae1e7b708f6be5faabeb26c94f99054c3dcd144), [`c870a7a1baf7db748a831265f06dd4b7378b262e`](https://github.com/medusajs/medusa/commit/c870a7a1baf7db748a831265f06dd4b7378b262e), [`9ac74eead4760d6c92676d451e6f25c2305b1852`](https://github.com/medusajs/medusa/commit/9ac74eead4760d6c92676d451e6f25c2305b1852)]:
  - @medusajs/core-flows@2.7.0
  - @medusajs/pricing@2.7.0
  - @medusajs/fulfillment@2.7.0
  - @medusajs/inventory@2.7.0
  - @medusajs/user@2.7.0
  - @medusajs/utils@2.7.0
  - @medusajs/test-utils@2.7.0
  - @medusajs/medusa@2.7.0
  - @medusajs/workflow-engine-inmemory@2.7.0
  - @medusajs/promotion@2.7.0
  - @medusajs/modules-sdk@2.7.0
  - @medusajs/product@2.7.0
  - @medusajs/api-key@2.7.0
  - @medusajs/auth@2.7.0
  - @medusajs/customer@2.7.0
  - @medusajs/region@2.7.0
  - @medusajs/stock-location@2.7.0
  - @medusajs/store@2.7.0
  - @medusajs/tax@2.7.0
  - @medusajs/cache-inmemory@2.7.0
  - @medusajs/event-bus-local@2.7.0
  - @medusajs/fulfillment-manual@2.7.0

## 1.0.9

### Patch Changes

- Updated dependencies [[`8bb0a25f573c62ca1d1bcd7af184b0d0cf98e125`](https://github.com/medusajs/medusa/commit/8bb0a25f573c62ca1d1bcd7af184b0d0cf98e125), [`51b0af193c7dde4899a696a515b59373b465d907`](https://github.com/medusajs/medusa/commit/51b0af193c7dde4899a696a515b59373b465d907), [`eeebb35758ea443468dd2355a7ea761dfe24babc`](https://github.com/medusajs/medusa/commit/eeebb35758ea443468dd2355a7ea761dfe24babc), [`d172ad8ebc4677bba73c36465c973f4784dc50ae`](https://github.com/medusajs/medusa/commit/d172ad8ebc4677bba73c36465c973f4784dc50ae), [`93cbc6b6695f236fa39b66169de971228888f1b9`](https://github.com/medusajs/medusa/commit/93cbc6b6695f236fa39b66169de971228888f1b9), [`322d108c0395757b4655a1e0055d722acf127b36`](https://github.com/medusajs/medusa/commit/322d108c0395757b4655a1e0055d722acf127b36), [`d1efad9bf05ca80959e8b50d74b74167fc1b0064`](https://github.com/medusajs/medusa/commit/d1efad9bf05ca80959e8b50d74b74167fc1b0064), [`caf83cf78cb6d2dbd1837f6814062dafecbd04fa`](https://github.com/medusajs/medusa/commit/caf83cf78cb6d2dbd1837f6814062dafecbd04fa), [`ca6a15717d05de112ca00ca56d65beb2ab0f2598`](https://github.com/medusajs/medusa/commit/ca6a15717d05de112ca00ca56d65beb2ab0f2598), [`d254b2ddba3fba4fb60e1076a6bc4e7d425bbd30`](https://github.com/medusajs/medusa/commit/d254b2ddba3fba4fb60e1076a6bc4e7d425bbd30), [`38beeb157eadcd7dabe814119c48b5ddbc17fe20`](https://github.com/medusajs/medusa/commit/38beeb157eadcd7dabe814119c48b5ddbc17fe20), [`b42f151be31161a5d7a73132ee6794b990403d76`](https://github.com/medusajs/medusa/commit/b42f151be31161a5d7a73132ee6794b990403d76), [`03731c7660fe5dca3c6d3c38a2a71eb2ea89e192`](https://github.com/medusajs/medusa/commit/03731c7660fe5dca3c6d3c38a2a71eb2ea89e192), [`ab96ad3b8213b117b067ae0ab66b94f74b8bd031`](https://github.com/medusajs/medusa/commit/ab96ad3b8213b117b067ae0ab66b94f74b8bd031), [`cad8b40c130e371d615d3bd953bb466fb4ac54a8`](https://github.com/medusajs/medusa/commit/cad8b40c130e371d615d3bd953bb466fb4ac54a8), [`7dbec10b3bdde8a9f869080d5ef2c3c97fca1077`](https://github.com/medusajs/medusa/commit/7dbec10b3bdde8a9f869080d5ef2c3c97fca1077), [`fa1793e8e92164251c776859dea7a5e312ef9432`](https://github.com/medusajs/medusa/commit/fa1793e8e92164251c776859dea7a5e312ef9432), [`e23f204b7ca0f195e36fef2ba0bae7a686b8da4f`](https://github.com/medusajs/medusa/commit/e23f204b7ca0f195e36fef2ba0bae7a686b8da4f), [`aabbbb7292a59ec029a6165451aa6d949844b2ea`](https://github.com/medusajs/medusa/commit/aabbbb7292a59ec029a6165451aa6d949844b2ea)]:
  - @medusajs/medusa@2.6.0
  - @medusajs/product@2.6.0
  - @medusajs/utils@2.6.0
  - @medusajs/core-flows@2.6.0
  - @medusajs/inventory@2.6.0
  - @medusajs/modules-sdk@2.6.0
  - @medusajs/test-utils@2.6.0
  - @medusajs/api-key@2.6.0
  - @medusajs/auth@2.6.0
  - @medusajs/cache-inmemory@2.6.0
  - @medusajs/customer@2.6.0
  - @medusajs/event-bus-local@2.6.0
  - @medusajs/fulfillment@2.6.0
  - @medusajs/pricing@2.6.0
  - @medusajs/promotion@2.6.0
  - @medusajs/fulfillment-manual@2.6.0
  - @medusajs/region@2.6.0
  - @medusajs/stock-location@2.6.0
  - @medusajs/store@2.6.0
  - @medusajs/tax@2.6.0
  - @medusajs/user@2.6.0
  - @medusajs/workflow-engine-inmemory@2.6.0

## 1.0.8

### Patch Changes

- Updated dependencies [[`e98d3c615e8a42e09974ded9cc3ca3277e3a9217`](https://github.com/medusajs/medusa/commit/e98d3c615e8a42e09974ded9cc3ca3277e3a9217), [`da25980d2445a09a51220c0d4f005f41659057a6`](https://github.com/medusajs/medusa/commit/da25980d2445a09a51220c0d4f005f41659057a6), [`9f1a3b2a4214ef23a22972e6d28c5f43f87da353`](https://github.com/medusajs/medusa/commit/9f1a3b2a4214ef23a22972e6d28c5f43f87da353), [`cb0f065c9dd59fe54a52c337f9b5392723f9db58`](https://github.com/medusajs/medusa/commit/cb0f065c9dd59fe54a52c337f9b5392723f9db58), [`016e332e9b98f316cded6eb999927fc942ce56c5`](https://github.com/medusajs/medusa/commit/016e332e9b98f316cded6eb999927fc942ce56c5), [`a33aebd8957f4bab10afd5e50a810cf738879b0d`](https://github.com/medusajs/medusa/commit/a33aebd8957f4bab10afd5e50a810cf738879b0d), [`716de2cb3ab5d504ec763fc322dc11b542b7e8ca`](https://github.com/medusajs/medusa/commit/716de2cb3ab5d504ec763fc322dc11b542b7e8ca), [`c8376a9f15ba728506411e567ed4389c7b64406f`](https://github.com/medusajs/medusa/commit/c8376a9f15ba728506411e567ed4389c7b64406f), [`040b7b274ee602e31f2b0ffa16605d6f38285f3e`](https://github.com/medusajs/medusa/commit/040b7b274ee602e31f2b0ffa16605d6f38285f3e), [`f4c2cd112ed54757ed35a55297b46b36152829cb`](https://github.com/medusajs/medusa/commit/f4c2cd112ed54757ed35a55297b46b36152829cb), [`c9821171866a5a66ce5b7f0b8a414de48dbcdc7e`](https://github.com/medusajs/medusa/commit/c9821171866a5a66ce5b7f0b8a414de48dbcdc7e), [`244cd714b2e8dc742afbefd0d175649f8fc45eed`](https://github.com/medusajs/medusa/commit/244cd714b2e8dc742afbefd0d175649f8fc45eed), [`acefcd7d8052601308d75daf004069e95eb78a89`](https://github.com/medusajs/medusa/commit/acefcd7d8052601308d75daf004069e95eb78a89), [`f07af7b93c86673e730dc4e5eba8df2572013f9f`](https://github.com/medusajs/medusa/commit/f07af7b93c86673e730dc4e5eba8df2572013f9f), [`3c51709daf07dcdd5563fa08fec2446a42cc8058`](https://github.com/medusajs/medusa/commit/3c51709daf07dcdd5563fa08fec2446a42cc8058)]:
  - @medusajs/core-flows@2.5.0
  - @medusajs/medusa@2.5.0
  - @medusajs/utils@2.5.0
  - @medusajs/api-key@2.5.0
  - @medusajs/auth@2.5.0
  - @medusajs/customer@2.5.0
  - @medusajs/fulfillment@2.5.0
  - @medusajs/inventory@2.5.0
  - @medusajs/pricing@2.5.0
  - @medusajs/product@2.5.0
  - @medusajs/promotion@2.5.0
  - @medusajs/region@2.5.0
  - @medusajs/stock-location@2.5.0
  - @medusajs/store@2.5.0
  - @medusajs/tax@2.5.0
  - @medusajs/user@2.5.0
  - @medusajs/modules-sdk@2.5.0
  - @medusajs/workflow-engine-inmemory@2.5.0
  - @medusajs/test-utils@2.5.0
  - @medusajs/cache-inmemory@2.5.0
  - @medusajs/event-bus-local@2.5.0
  - @medusajs/fulfillment-manual@2.5.0

## 1.0.7

### Patch Changes

- Updated dependencies [[`67782350a9da278457c3280c300ebec65bdc6326`](https://github.com/medusajs/medusa/commit/67782350a9da278457c3280c300ebec65bdc6326), [`b0f581cc7cb9f173666502d9ed2ea2c128b517be`](https://github.com/medusajs/medusa/commit/b0f581cc7cb9f173666502d9ed2ea2c128b517be), [`4bc3f5b845f832959bed3d5f2bd320b55a8fb50f`](https://github.com/medusajs/medusa/commit/4bc3f5b845f832959bed3d5f2bd320b55a8fb50f), [`1758bfb8d042fa9fc82f23c36ccd61e4a439448e`](https://github.com/medusajs/medusa/commit/1758bfb8d042fa9fc82f23c36ccd61e4a439448e), [`7be47354e1eb95141f420ef9c74f98b3e2bd8315`](https://github.com/medusajs/medusa/commit/7be47354e1eb95141f420ef9c74f98b3e2bd8315), [`69e2a6d6951c133295947d00fa1f99547da467d2`](https://github.com/medusajs/medusa/commit/69e2a6d6951c133295947d00fa1f99547da467d2), [`c5a207144e2f04f232a1beb3586422fc93047ed2`](https://github.com/medusajs/medusa/commit/c5a207144e2f04f232a1beb3586422fc93047ed2), [`b7a37598249a60c91ce70c999ff8b0dfa6246e49`](https://github.com/medusajs/medusa/commit/b7a37598249a60c91ce70c999ff8b0dfa6246e49), [`899b1fba4afeed61c343aa0ff5d171bfe6dc5ca8`](https://github.com/medusajs/medusa/commit/899b1fba4afeed61c343aa0ff5d171bfe6dc5ca8), [`5eab9e739919594ae7e7e416942ec93d84b699fd`](https://github.com/medusajs/medusa/commit/5eab9e739919594ae7e7e416942ec93d84b699fd), [`3fec01ab494dcd91ee5b2f17597e24e653ddc801`](https://github.com/medusajs/medusa/commit/3fec01ab494dcd91ee5b2f17597e24e653ddc801), [`c75678d6d41d3b88d07681ad7e24472d6cbde672`](https://github.com/medusajs/medusa/commit/c75678d6d41d3b88d07681ad7e24472d6cbde672), [`a625bce7b022c28a256f81777b7ebab15ab1d930`](https://github.com/medusajs/medusa/commit/a625bce7b022c28a256f81777b7ebab15ab1d930), [`11f98f374cb0b77b1c80e72328fc68b5e22d5b87`](https://github.com/medusajs/medusa/commit/11f98f374cb0b77b1c80e72328fc68b5e22d5b87), [`0cfaab5bb16daf403966e9d0a5931e2c64d44138`](https://github.com/medusajs/medusa/commit/0cfaab5bb16daf403966e9d0a5931e2c64d44138), [`0924164e86ecc256e2fa56a4e8c504abf7663131`](https://github.com/medusajs/medusa/commit/0924164e86ecc256e2fa56a4e8c504abf7663131), [`7232a8a93053adedd964659c1f370aa9fddc0e44`](https://github.com/medusajs/medusa/commit/7232a8a93053adedd964659c1f370aa9fddc0e44), [`1ba2fadf22a30de9f94aee4f195163ef5e9e84d2`](https://github.com/medusajs/medusa/commit/1ba2fadf22a30de9f94aee4f195163ef5e9e84d2), [`114b2133aa7a82b7a152022e95d29e1a489ad99e`](https://github.com/medusajs/medusa/commit/114b2133aa7a82b7a152022e95d29e1a489ad99e), [`c1930bd6568043d145e34d8360015e7207e18e4a`](https://github.com/medusajs/medusa/commit/c1930bd6568043d145e34d8360015e7207e18e4a), [`28febfc6438351fddb5b214b86f96aff89db688e`](https://github.com/medusajs/medusa/commit/28febfc6438351fddb5b214b86f96aff89db688e), [`bc22b81cdf9591912744f448c74d45bcb0f11e0c`](https://github.com/medusajs/medusa/commit/bc22b81cdf9591912744f448c74d45bcb0f11e0c), [`428fce53134bd0b224f636a9a15d369d1f03cde8`](https://github.com/medusajs/medusa/commit/428fce53134bd0b224f636a9a15d369d1f03cde8)]:
  - @medusajs/utils@2.3.0
  - @medusajs/medusa@2.3.0
  - @medusajs/core-flows@2.3.0
  - @medusajs/promotion@2.3.0
  - @medusajs/pricing@2.3.0
  - @medusajs/test-utils@2.3.0
  - @medusajs/inventory@2.3.0
  - @medusajs/modules-sdk@2.3.0
  - @medusajs/api-key@2.3.0
  - @medusajs/auth@2.3.0
  - @medusajs/cache-inmemory@2.3.0
  - @medusajs/customer@2.3.0
  - @medusajs/event-bus-local@2.3.0
  - @medusajs/fulfillment@2.3.0
  - @medusajs/product@2.3.0
  - @medusajs/fulfillment-manual@2.3.0
  - @medusajs/region@2.3.0
  - @medusajs/stock-location@2.3.0
  - @medusajs/store@2.3.0
  - @medusajs/tax@2.3.0
  - @medusajs/user@2.3.0
  - @medusajs/workflow-engine-inmemory@2.3.0

## 1.0.6

### Patch Changes

- Updated dependencies [[`100da64242838739816351ed259461f2d7c258e3`](https://github.com/medusajs/medusa/commit/100da64242838739816351ed259461f2d7c258e3), [`d08b71f9b87c68350e57016e62e406a9bdd82342`](https://github.com/medusajs/medusa/commit/d08b71f9b87c68350e57016e62e406a9bdd82342), [`c9b8db04c1b35f1cf129bb9ad74789fbc2881815`](https://github.com/medusajs/medusa/commit/c9b8db04c1b35f1cf129bb9ad74789fbc2881815), [`9d85e663b8bac2240ec3e3bf99377dd0eac72160`](https://github.com/medusajs/medusa/commit/9d85e663b8bac2240ec3e3bf99377dd0eac72160), [`5d1098ceb9713225186fce16c0306b0539d71fc5`](https://github.com/medusajs/medusa/commit/5d1098ceb9713225186fce16c0306b0539d71fc5), [`1232a43fcec50b01477149089bbb957dec15ba76`](https://github.com/medusajs/medusa/commit/1232a43fcec50b01477149089bbb957dec15ba76)]:
  - @medusajs/fulfillment@2.1.3
  - @medusajs/utils@2.1.3
  - @medusajs/medusa@2.1.3
  - @medusajs/product@2.1.3
  - @medusajs/core-flows@2.1.3
  - @medusajs/modules-sdk@2.1.3
  - @medusajs/test-utils@2.1.3
  - @medusajs/api-key@2.1.3
  - @medusajs/auth@2.1.3
  - @medusajs/cache-inmemory@2.1.3
  - @medusajs/customer@2.1.3
  - @medusajs/event-bus-local@2.1.3
  - @medusajs/inventory@2.1.3
  - @medusajs/pricing@2.1.3
  - @medusajs/promotion@2.1.3
  - @medusajs/fulfillment-manual@2.1.3
  - @medusajs/region@2.1.3
  - @medusajs/stock-location@2.1.3
  - @medusajs/store@2.1.3
  - @medusajs/tax@2.1.3
  - @medusajs/user@2.1.3
  - @medusajs/workflow-engine-inmemory@2.1.3

## 1.0.5

### Patch Changes

- Updated dependencies [[`729eb5da7b6daf9781b8bdcbc2fab344e942d444`](https://github.com/medusajs/medusa/commit/729eb5da7b6daf9781b8bdcbc2fab344e942d444), [`16192d9b3077e36c6b1df7409a0c0f26f643cc6d`](https://github.com/medusajs/medusa/commit/16192d9b3077e36c6b1df7409a0c0f26f643cc6d), [`16d27ea6e4c2e4290820fe2328f08557534fcb8f`](https://github.com/medusajs/medusa/commit/16d27ea6e4c2e4290820fe2328f08557534fcb8f), [`fad85a9d293acee1dae784afa223a080b9b8b85b`](https://github.com/medusajs/medusa/commit/fad85a9d293acee1dae784afa223a080b9b8b85b), [`885c82ded63e504739bf39a113f820c87c9e2d52`](https://github.com/medusajs/medusa/commit/885c82ded63e504739bf39a113f820c87c9e2d52), [`4ad9ac1e5f3b583514015ffd35b88d0f60b2b38a`](https://github.com/medusajs/medusa/commit/4ad9ac1e5f3b583514015ffd35b88d0f60b2b38a), [`90ad2566fdde2215447100d10c3fe9b17ce826b5`](https://github.com/medusajs/medusa/commit/90ad2566fdde2215447100d10c3fe9b17ce826b5), [`e021c9258cd3bf7b92213b0bd2d529f72200142e`](https://github.com/medusajs/medusa/commit/e021c9258cd3bf7b92213b0bd2d529f72200142e), [`6367bccde88158d524dfa01e5a8123ffa3461c10`](https://github.com/medusajs/medusa/commit/6367bccde88158d524dfa01e5a8123ffa3461c10)]:
  - @medusajs/inventory@2.1.2
  - @medusajs/utils@2.1.2
  - @medusajs/product@2.1.2
  - @medusajs/customer@2.1.2
  - @medusajs/promotion@2.1.2
  - @medusajs/stock-location@2.1.2
  - @medusajs/fulfillment@2.1.2
  - @medusajs/tax@2.1.2
  - @medusajs/core-flows@2.1.2
  - @medusajs/pricing@2.1.2
  - @medusajs/medusa@2.1.2
  - @medusajs/modules-sdk@2.1.2
  - @medusajs/test-utils@2.1.2
  - @medusajs/api-key@2.1.2
  - @medusajs/auth@2.1.2
  - @medusajs/cache-inmemory@2.1.2
  - @medusajs/event-bus-local@2.1.2
  - @medusajs/fulfillment-manual@2.1.2
  - @medusajs/region@2.1.2
  - @medusajs/store@2.1.2
  - @medusajs/user@2.1.2
  - @medusajs/workflow-engine-inmemory@2.1.2

## 1.0.4

### Patch Changes

- Updated dependencies [[`e9003c3124f284eae7e1457101bf10c1beccbac1`](https://github.com/medusajs/medusa/commit/e9003c3124f284eae7e1457101bf10c1beccbac1), [`030ee871506cfe178702853714feaaa33f1d9cf4`](https://github.com/medusajs/medusa/commit/030ee871506cfe178702853714feaaa33f1d9cf4)]:
  - @medusajs/utils@2.0.7
  - @medusajs/core-flows@2.0.7
  - @medusajs/modules-sdk@2.0.7
  - @medusajs/medusa@2.0.7
  - @medusajs/test-utils@2.0.7
  - @medusajs/api-key@2.0.7
  - @medusajs/auth@2.0.7
  - @medusajs/cache-inmemory@2.0.7
  - @medusajs/customer@2.0.7
  - @medusajs/event-bus-local@2.0.7
  - @medusajs/fulfillment@2.0.7
  - @medusajs/inventory@2.0.7
  - @medusajs/pricing@2.0.7
  - @medusajs/product@2.0.7
  - @medusajs/promotion@2.0.7
  - @medusajs/fulfillment-manual@2.0.7
  - @medusajs/region@2.0.7
  - @medusajs/stock-location@2.0.7
  - @medusajs/store@2.0.7
  - @medusajs/tax@2.0.7
  - @medusajs/user@2.0.7
  - @medusajs/workflow-engine-inmemory@2.0.7

## 1.0.3

### Patch Changes

- Updated dependencies [[`0ef92cce2848ed447028434c43e4041f094cb402`](https://github.com/medusajs/medusa/commit/0ef92cce2848ed447028434c43e4041f094cb402)]:
  - @medusajs/medusa@2.0.4
  - @medusajs/core-flows@2.0.4
  - @medusajs/modules-sdk@2.0.4
  - @medusajs/utils@2.0.4
  - @medusajs/test-utils@2.0.4
  - @medusajs/api-key@2.0.4
  - @medusajs/auth@2.0.4
  - @medusajs/cache-inmemory@2.0.4
  - @medusajs/customer@2.0.4
  - @medusajs/event-bus-local@2.0.4
  - @medusajs/fulfillment@2.0.4
  - @medusajs/inventory@2.0.4
  - @medusajs/pricing@2.0.4
  - @medusajs/product@2.0.4
  - @medusajs/promotion@2.0.4
  - @medusajs/fulfillment-manual@2.0.4
  - @medusajs/region@2.0.4
  - @medusajs/stock-location@2.0.4
  - @medusajs/store@2.0.4
  - @medusajs/tax@2.0.4
  - @medusajs/user@2.0.4
  - @medusajs/workflow-engine-inmemory@2.0.4

## 1.0.2

### Patch Changes

- Updated dependencies [[`471f7e4a10fe415064480b2a0aa5b8b23174c141`](https://github.com/medusajs/medusa/commit/471f7e4a10fe415064480b2a0aa5b8b23174c141)]:
  - @medusajs/medusa@2.0.1
  - @medusajs/core-flows@2.0.1
  - @medusajs/modules-sdk@2.0.1
  - @medusajs/utils@2.0.1
  - @medusajs/test-utils@2.0.1
  - @medusajs/api-key@2.0.1
  - @medusajs/auth@2.0.1
  - @medusajs/cache-inmemory@2.0.1
  - @medusajs/customer@2.0.1
  - @medusajs/event-bus-local@2.0.1
  - @medusajs/fulfillment@2.0.1
  - @medusajs/inventory@2.0.1
  - @medusajs/pricing@2.0.1
  - @medusajs/product@2.0.1
  - @medusajs/promotion@2.0.1
  - @medusajs/fulfillment-manual@2.0.1
  - @medusajs/region@2.0.1
  - @medusajs/stock-location@2.0.1
  - @medusajs/store@2.0.1
  - @medusajs/tax@2.0.1
  - @medusajs/user@2.0.1
  - @medusajs/workflow-engine-inmemory@2.0.1

## 1.0.1

### Patch Changes

- Updated dependencies [[`2e42e053d4c9d5445d227bdc268c66713aad8e2e`](https://github.com/medusajs/medusa/commit/2e42e053d4c9d5445d227bdc268c66713aad8e2e)]:
  - @medusajs/core-flows@2.0.0
  - @medusajs/test-utils@2.0.0
  - @medusajs/modules-sdk@2.0.0
  - @medusajs/utils@2.0.0
  - @medusajs/medusa@2.0.0
  - @medusajs/api-key@2.0.0
  - @medusajs/auth@2.0.0
  - @medusajs/cache-inmemory@2.0.0
  - @medusajs/customer@2.0.0
  - @medusajs/event-bus-local@2.0.0
  - @medusajs/fulfillment@2.0.0
  - @medusajs/inventory@2.0.0
  - @medusajs/pricing@2.0.0
  - @medusajs/product@2.0.0
  - @medusajs/promotion@2.0.0
  - @medusajs/fulfillment-manual@2.0.0
  - @medusajs/region@2.0.0
  - @medusajs/stock-location@2.0.0
  - @medusajs/store@2.0.0
  - @medusajs/tax@2.0.0
  - @medusajs/user@2.0.0
  - @medusajs/workflow-engine-inmemory@2.0.0
