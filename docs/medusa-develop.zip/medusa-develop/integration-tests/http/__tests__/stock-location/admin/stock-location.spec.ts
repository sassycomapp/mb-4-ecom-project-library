import { Modules } from "@medusajs/utils"
import {
  adminHeaders,
  createAdminUser,
} from "../../../../helpers/create-admin-user"

const { medusaIntegrationTestRunner } = require("@medusajs/test-utils")

jest.setTimeout(30000)

medusaIntegrationTestRunner({
  testSuite: ({ dbConnection, getContainer, api, dbUtils }) => {
    let location1
    let location2
    let salesChannel1
    let salesChannel2

    beforeAll(async () => {
      await createAdminUser(dbConnection, adminHeaders, getContainer())

      location1 = (
        await api.post(
          `/admin/stock-locations`,
          {
            name: "Test Location 1",
            address: {
              address_1: "Test Address",
              country_code: "US",
            },
          },
          adminHeaders
        )
      ).data.stock_location

      location2 = (
        await api.post(
          `/admin/stock-locations`,
          {
            name: "Test Location 2",
            address: {
              address_1: "Test Address",
              country_code: "US",
            },
          },
          adminHeaders
        )
      ).data.stock_location

      salesChannel1 = (
        await api.post(
          `/admin/sales-channels`,
          {
            name: "Test SC",
          },
          adminHeaders
        )
      ).data.sales_channel

      salesChannel2 = (
        await api.post(
          `/admin/sales-channels`,
          {
            name: "Test SC 2",
          },
          adminHeaders
        )
      ).data.sales_channel

      await dbUtils.snapshot()
    })

    describe("create stock location", () => {
      it("should create a stock location with a name and address", async () => {
        const response = await api.post(
          "/admin/stock-locations",
          {
            name: "Test Location",
            address: {
              address_1: "Test Address",
              country_code: "US",
            },
          },
          adminHeaders
        )

        expect(response.status).toEqual(200)
        expect(response.data.stock_location).toEqual(
          expect.objectContaining({
            name: "Test Location",
            address: expect.objectContaining({
              address_1: "Test Address",
              country_code: "US",
            }),
          })
        )
      })

      it("should create a stock location with address metadata", async () => {
        const response = await api.post(
          "/admin/stock-locations",
          {
            name: "Metadata Test Location",
            address: {
              address_1: "123 Test St",
              country_code: "US",
              metadata: {
                internal_id: "LOC-123",
                gate_code: "9999",
              },
            },
          },
          adminHeaders
        )

        expect(response.status).toEqual(200)
        expect(response.data.stock_location).toEqual(
          expect.objectContaining({
            name: "Metadata Test Location",
            address: expect.objectContaining({
              address_1: "123 Test St",
              country_code: "US",
              metadata: {
                internal_id: "LOC-123",
                gate_code: "9999",
              },
            }),
          })
        )
      })

      it("should create and retrieve a stock location with metadata", async () => {
        const metadata = {
          internal_id: "LOC-789",
          priority: "high",
        }

        const response = await api.post(
          "/admin/stock-locations",
          {
            name: "Stock Location Metadata Test",
            metadata,
            address: {
              address_1: "456 Test St",
              country_code: "US",
            },
          },
          adminHeaders
        )

        expect(response.status).toEqual(200)
        expect(response.data.stock_location).toEqual(
          expect.objectContaining({
            name: "Stock Location Metadata Test",
            metadata,
          })
        )

        const retrieveResponse = await api.get(
          `/admin/stock-locations/${response.data.stock_location.id}`,
          adminHeaders
        )

        expect(retrieveResponse.status).toEqual(200)
        expect(retrieveResponse.data.stock_location).toEqual(
          expect.objectContaining({
            id: response.data.stock_location.id,
            metadata,
          })
        )
      })
    })

    describe("list stock locations", () => {
      it("should list stock locations", async () => {
        const listLocationsResponse = await api.get(
          "/admin/stock-locations",
          adminHeaders
        )

        expect(listLocationsResponse.status).toEqual(200)
        expect(listLocationsResponse.data.stock_locations).toEqual([
          expect.objectContaining(location1),
          expect.objectContaining(location2),
        ])
      })

      it("should filter stock locations by name", async () => {
        const listLocationsResponse = await api.get(
          "/admin/stock-locations?name=Test%20Location%201",
          adminHeaders
        )

        expect(listLocationsResponse.status).toEqual(200)
        expect(listLocationsResponse.data.stock_locations).toEqual([
          expect.objectContaining(location1),
        ])
      })

      it("should filter stock locations by partial name with q parameter", async () => {
        const listLocationsResponse = await api.get(
          "/admin/stock-locations?q=ation%201",
          adminHeaders
        )

        expect(listLocationsResponse.status).toEqual(200)
        expect(listLocationsResponse.data.stock_locations).toEqual([
          expect.objectContaining(location1),
        ])
      })

      it("should filter stock locations on sales_channel_id", async () => {
        await api.post(
          `/admin/stock-locations/${location1.id}/sales-channels`,
          {
            add: [salesChannel1.id],
          },
          adminHeaders
        )

        const listLocationsResponse = await api.get(
          `/admin/stock-locations?sales_channel_id=${salesChannel1.id}`,
          adminHeaders
        )

        expect(listLocationsResponse.status).toEqual(200)
        expect(listLocationsResponse.data.stock_locations).toEqual([
          expect.objectContaining(location1),
        ])
      })
    })

    describe("Update stock locations", () => {
      it("should update stock location name", async () => {
        const response = await api.post(
          `/admin/stock-locations/${location1.id}`,
          {
            name: "new name",
          },
          adminHeaders
        )
        expect(response.status).toEqual(200)
        expect(response.data.stock_location.name).toEqual("new name")
      })

      it("should update stock location address without creating new addresses", async () => {
        const response = await api.post(
          `/admin/stock-locations/${location1.id}`,
          {
            name: "new name",
            address: {
              address_1: "test",
              country_code: "dk",
            },
          },
          adminHeaders
        )

        const firstAddressId = response.data.stock_location.address.id

        expect(response.status).toEqual(200)
        expect(response.data.stock_location).toEqual(
          expect.objectContaining({
            name: "new name",
            address: expect.objectContaining({
              id: firstAddressId,
              address_1: "test",
              country_code: "dk",
            }),
          })
        )

        const response2 = await api.post(
          `/admin/stock-locations/${location1.id}`,
          {
            name: "new name 2",
            address: {
              address_1: "test 2",
              country_code: "dk",
            },
          },
          adminHeaders
        )

        expect(response2.status).toEqual(200)
        expect(response2.data.stock_location).toEqual(
          expect.objectContaining({
            name: "new name 2",
            address: expect.objectContaining({
              id: firstAddressId,
              address_1: "test 2",
              country_code: "dk",
            }),
          })
        )
      })

      it("should update stock location address metadata", async () => {
        const response = await api.post(
          `/admin/stock-locations/${location1.id}`,
          {
            address: {
              address_1: "123 Test St",
              country_code: "US",
              metadata: {
                updated_id: "LOC-456",
              },
            },
          },
          adminHeaders
        )

        expect(response.status).toEqual(200)
        expect(response.data.stock_location.address).toEqual(
          expect.objectContaining({
            address_1: "123 Test St",
            country_code: "US",
            metadata: {
              updated_id: "LOC-456",
            },
          })
        )
      })
    })

    describe("Get stock location", () => {
      it("should get a stock location", async () => {
        const response = await api.get(
          `/admin/stock-locations/${location1.id}`,
          adminHeaders
        )

        expect(response.status).toEqual(200)
        expect(response.data.stock_location).toEqual(
          expect.objectContaining({ id: location1.id, name: "Test Location 1" })
        )
      })

      it("should throw an error when a stock location does not exist", async () => {
        let error
        await api
          .get(`/admin/stock-locations/does-not-exist`, adminHeaders)
          .catch((e) => (error = e))

        expect(error.response.status).toEqual(404)
        expect(error.response.data.message).toEqual(
          `Stock location with id: does-not-exist was not found`
        )
      })
    })

    describe("Delete stock location", () => {
      it("should successfully delete stock location", async () => {
        const stockLocationDeleteResponse = await api.delete(
          `/admin/stock-locations/${location1.id}`,
          adminHeaders
        )

        expect(stockLocationDeleteResponse.status).toEqual(200)
        expect(stockLocationDeleteResponse.data).toEqual({
          id: location1.id,
          object: "stock_location",
          deleted: true,
        })

        const stockLocations = await api.get(
          `/admin/stock-locations`,
          adminHeaders
        )

        expect(stockLocations.status).toEqual(200)
        expect(stockLocations.data.stock_locations).toEqual([
          expect.objectContaining(location2),
        ])
      })

      it("should successfully delete stock location associations", async () => {
        await api.post(
          `/admin/stock-locations/${location1.id}/sales-channels`,
          {
            add: [salesChannel1.id],
          },
          adminHeaders
        )

        await api.delete(`/admin/stock-locations/${location1.id}`, adminHeaders)

        const scWithAssociation = (
          await api.get(
            `/admin/sales-channels/${salesChannel1.id}?fields=*stock_locations`,
            adminHeaders
          )
        ).data.sales_channel

        expect(scWithAssociation.stock_locations).toEqual([])
      })
    })

    describe("Add sales channels", () => {
      it("should add sales channels to a location", async () => {
        const salesChannelResponse = await api.post(
          `/admin/stock-locations/${location1.id}/sales-channels?fields=*sales_channels`,
          { add: [salesChannel1.id] },
          adminHeaders
        )

        expect(
          salesChannelResponse.data.stock_location.sales_channels
        ).toHaveLength(1)
      })
    })

    describe("Remove sales channels", () => {
      beforeEach(async () => {
        await api.post(
          `/admin/stock-locations/${location1.id}/sales-channels?fields=*sales_channels`,
          { add: [salesChannel1.id, salesChannel2.id] },
          adminHeaders
        )
      })

      it("should remove sales channels from a location", async () => {
        const salesChannelResponse = await api.post(
          `/admin/stock-locations/${location1.id}/sales-channels?fields=*sales_channels`,
          { remove: [salesChannel1.id] },
          adminHeaders
        )

        expect(
          salesChannelResponse.data.stock_location.sales_channels
        ).toHaveLength(1)
      })
    })

    describe("Location fulfillment sets", () => {
      it("should create a fulfillment set for the location and then delete it and its associations", async () => {
        const response = await api.post(
          `/admin/stock-locations/${location1.id}/fulfillment-sets?fields=id,*fulfillment_sets`,
          {
            name: "Fulfillment Set",
            type: "shipping",
          },
          adminHeaders
        )

        expect(response.status).toEqual(200)

        expect(response.data.stock_location.fulfillment_sets).toEqual([
          expect.objectContaining({
            id: expect.any(String),
          }),
        ])

        await api.delete(`/admin/stock-locations/${location1.id}`, adminHeaders)

        // TODO: Ideally we use HTTP here, maybe we should have a get endpoint for fulfillment sets?
        const fulfillmentModule = getContainer().resolve(Modules.FULFILLMENT)
        const sets = await fulfillmentModule.listFulfillmentSets()
        expect(sets).toHaveLength(0)
      })

      // This is really just to test the new Zod middleware. We don't need more of these.
      it("should throw a validation error on wrong input", async () => {
        const errorResponse = await api
          .post(
            `/admin/stock-locations/${location1.id}/fulfillment-sets?fields=id,*fulfillment_sets`,
            {
              name: "Fulfillment Set",
              type: "shipping",
              foo: "bar",
            },
            adminHeaders
          )
          .catch((e) => e.response)

        expect(errorResponse.status).toEqual(400)

        expect(errorResponse.data.message).toEqual(
          "Invalid request: Unrecognized fields: 'foo'"
        )
      })
    })
  },
})
