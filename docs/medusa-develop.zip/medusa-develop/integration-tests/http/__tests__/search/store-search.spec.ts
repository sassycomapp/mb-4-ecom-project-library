import { medusaIntegrationTestRunner } from "@medusajs/test-utils"
import { SearchTypes } from "@medusajs/types"
import { Modules } from "@medusajs/utils"
import {
  adminHeaders,
  createAdminUser,
  generatePublishableKey,
  generateStoreHeaders,
} from "../../../helpers/create-admin-user"

jest.setTimeout(120000)

/**
 * Covers POST /store/search. The app under test opts in `product` only — see its
 * `src/api/middlewares.ts`. Narrowing to published products in the key's sales
 * channels is the endpoint's own, since the index declares both fields.
 */
medusaIntegrationTestRunner({
  testSuite: ({ dbConnection, getContainer, api }) => {
    let searchModule: SearchTypes.ISearchModuleService
    let storeHeaders
    let salesChannel
    let otherSalesChannel
    let shirt
    let shoe
    let draft
    let hidden
    let customer

    const createProduct = async (data) => {
      const response = await api.post("/admin/products", data, adminHeaders)
      return response.data.product
    }

    const createSalesChannel = async (name, productIds) => {
      const { data } = await api.post(
        "/admin/sales-channels",
        { name },
        adminHeaders
      )

      await api.post(
        `/admin/sales-channels/${data.sales_channel.id}/products`,
        { add: productIds },
        adminHeaders
      )

      return data.sales_channel
    }

    const waitForIndexReady = async (name: string) => {
      const deadline = Date.now() + 10000
      while (Date.now() < deadline) {
        const listed = await api.get("/admin/search-indexes", adminHeaders)
        const index = listed.data.search_indexes.find((i) => i.name === name)
        if (index?.status === "ready") {
          return index
        }
        await new Promise((resolve) => setTimeout(resolve, 100))
      }
      throw new Error(`Index "${name}" did not become ready in time`)
    }

    beforeAll(async () => {
      const container = getContainer()
      await createAdminUser(dbConnection, adminHeaders, container)

      searchModule = container.resolve(Modules.SEARCH)

      shirt = await createProduct({
        title: "Zephyr Shirt",
        handle: "zephyr-shirt",
        description: "A shirt for windy days",
        status: "published",
        options: [{ title: "Size", values: ["M"] }],
        variants: [
          {
            title: "Medium",
            sku: "ZEPHYR-M",
            options: { Size: "M" },
            prices: [{ amount: 20, currency_code: "usd" }],
          },
        ],
      })

      shoe = await createProduct({
        title: "Aurora Shoe",
        handle: "aurora-shoe",
        description: "A shoe for long walks",
        status: "published",
        options: [{ title: "Size", values: ["42"] }],
      })

      draft = await createProduct({
        title: "Zephyr Draft",
        handle: "zephyr-draft",
        status: "draft",
        options: [{ title: "Size", values: ["M"] }],
      })

      hidden = await createProduct({
        title: "Zephyr Elsewhere",
        handle: "zephyr-elsewhere",
        status: "published",
        options: [{ title: "Size", values: ["M"] }],
      })

      salesChannel = await createSalesChannel("Web", [
        shirt.id,
        shoe.id,
        draft.id,
      ])
      otherSalesChannel = await createSalesChannel("Retail", [hidden.id])

      customer = (
        await api.post(
          "/admin/customers",
          {
            email: "wilhelmina@zephyr.test",
            first_name: "Wilhelmina",
            last_name: "Zephyr",
          },
          adminHeaders
        )
      ).data.customer

      const publishableKey = await generatePublishableKey(container)
      await api.post(
        `/admin/api-keys/${publishableKey.id}/sales-channels`,
        { add: [salesChannel.id] },
        adminHeaders
      )
      storeHeaders = generateStoreHeaders({ publishableKey })

      // The sales channel links landed after the products were ingested off
      // their creation events, so the index is rebuilt from the seed.
      await searchModule.reindex()
      await waitForIndexReady("product")
      await waitForIndexReady("customer")
    })

    const search = (body) => api.post("/store/search", body, storeHeaders)

    describe("POST /store/search", () => {
      it("returns one result per posted query, in order", async () => {
        const response = await search({
          queries: [
            { entity: "product", filters: { handle: "zephyr-shirt" } },
            { entity: "product", filters: { handle: "aurora-shoe" } },
          ],
        })

        expect(response.status).toEqual(200)
        expect(response.data.results).toHaveLength(2)
        expect(response.data.results[0].hits).toEqual([
          expect.objectContaining({
            id: shirt.id,
            document: expect.objectContaining({
              id: shirt.id,
              title: "Zephyr Shirt",
              handle: "zephyr-shirt",
            }),
          }),
        ])
        expect(response.data.results[1].hits).toEqual([
          expect.objectContaining({ id: shoe.id }),
        ])
        expect(response.data.results[0].metadata).toEqual(
          expect.objectContaining({ skip: 0, take: 20 })
        )
      })

      it("accepts a single query outside of a batch", async () => {
        const response = await search({
          entity: "product",
          filters: { handle: "zephyr-shirt" },
        })

        expect(response.status).toEqual(200)
        expect(response.data.results).toHaveLength(1)
        expect(response.data.results[0].hits).toEqual([
          expect.objectContaining({ id: shirt.id }),
        ])
      })

      it("404s on a registered index the store hasn't opted in", async () => {
        const listed = await api.get(
          "/admin/search?q=wilhelmina&entity=customer",
          adminHeaders
        )
        expect(listed.data.results[0].data).toEqual([
          expect.objectContaining({ id: customer.id }),
        ])

        const error = await search({
          queries: [{ entity: "customer" }],
        }).catch((e) => e)

        expect(error.response.status).toEqual(404)
        expect(error.response.data.message).toEqual(
          'No search index named "customer"'
        )
      })

      it("404s on an index that isn't registered", async () => {
        const error = await search({
          queries: [{ entity: "nope" }],
        }).catch((e) => e)

        expect(error.response.status).toEqual(404)
        expect(error.response.data.message).toEqual(
          'No search index named "nope"'
        )
      })

      it("narrows products to published ones the key can see", async () => {
        const response = await search({
          queries: [{ entity: "product", filters: { q: "zephyr" } }],
        })

        expect(response.status).toEqual(200)
        // "Zephyr Draft" is out on status, "Zephyr Elsewhere" on sales channel.
        expect(response.data.results[0].hits).toEqual([
          expect.objectContaining({ id: shirt.id }),
        ])
      })

      it("scopes products to the key's sales channels", async () => {
        const response = await search({
          queries: [
            { entity: "product", filters: { handle: "zephyr-elsewhere" } },
          ],
        })

        expect(response.status).toEqual(200)
        // Published, so only the sales channel it lives in excludes it.
        expect(response.data.results[0].hits).toEqual([])
      })

      it("can't widen past the endpoint's product filters", async () => {
        const response = await search({
          queries: [
            { entity: "product", filters: { status: "draft" } },
            {
              entity: "product",
              filters: { sales_channel_ids: otherSalesChannel.id },
            },
          ],
        })

        expect(response.status).toEqual(200)
        expect(response.data.results[0].hits).toEqual([])
        expect(response.data.results[1].hits).toEqual([])
      })

      it("returns exactly the fields the index can retrieve", async () => {
        const response = await search({
          queries: [{ entity: "product", filters: { handle: "zephyr-shirt" } }],
        })

        expect(response.status).toEqual(200)
        const [hit] = response.data.results[0].hits
        expect(Object.keys(hit.document).sort()).toEqual(
          searchModule.listRetrievableFields("product").sort()
        )
        expect(hit.document).toEqual({
          id: shirt.id,
          title: "Zephyr Shirt",
          handle: "zephyr-shirt",
          status: "published",
          sales_channel_ids: [salesChannel.id],
        })
      })

      it("narrows the hits to the selected fields", async () => {
        const response = await search({
          queries: [
            {
              entity: "product",
              filters: { handle: "zephyr-shirt" },
              fields: ["id", "title"],
            },
          ],
        })

        expect(response.status).toEqual(200)
        expect(response.data.results[0].hits[0].document).toEqual({
          id: shirt.id,
          title: "Zephyr Shirt",
        })
      })

      it("rejects fields the index can't return", async () => {
        const batched = await search({
          queries: [
            {
              entity: "product",
              filters: { handle: "zephyr-shirt" },
              // On the product, but not on the index.
              fields: ["id", "description", "variants.*"],
            },
          ],
        }).catch((e) => e)

        expect(batched.response.status).toEqual(400)
        expect(batched.response.data.message).toEqual(
          `Search index "product" can't return the fields: description, variants.*`
        )

        const single = await search({
          entity: "product",
          fields: ["variants.sku"],
        }).catch((e) => e)

        expect(single.response.status).toEqual(400)
      })

      it("filters on the index' own fields", async () => {
        const response = await search({
          queries: [{ entity: "product", filters: { handle: "aurora-shoe" } }],
        })

        expect(response.status).toEqual(200)
        expect(response.data.results[0].hits).toEqual([
          expect.objectContaining({ id: shoe.id }),
        ])
      })

      it("sorts and paginates", async () => {
        const first = await search({
          queries: [
            {
              entity: "product",
              pagination: { take: 1, order: { title: "ASC" } },
            },
          ],
        })

        expect(first.data.results[0].hits).toEqual([
          expect.objectContaining({
            document: expect.objectContaining({ title: "Aurora Shoe" }),
          }),
        ])
        expect(first.data.results[0].metadata.take).toEqual(1)

        const second = await search({
          queries: [
            {
              entity: "product",
              pagination: { skip: 1, take: 1, order: { title: "ASC" } },
            },
          ],
        })

        expect(second.data.results[0].hits).toEqual([
          expect.objectContaining({
            document: expect.objectContaining({ title: "Zephyr Shirt" }),
          }),
        ])
        expect(second.data.results[0].metadata.skip).toEqual(1)
      })

      it("sorts on a lower-case order direction", async () => {
        const response = await search({
          entity: "product",
          pagination: { order: { title: "desc" } },
        })

        expect(response.status).toEqual(200)
        expect(
          response.data.results[0].hits.map((hit) => hit.document.title)
        ).toEqual(["Zephyr Shirt", "Aurora Shoe"])
      })

      it("rejects an unknown order direction", async () => {
        const error = await search({
          entity: "product",
          pagination: { order: { title: "up" } },
        }).catch((e) => e)

        expect(error.response.status).toEqual(400)
      })

      it("returns the facets a query asks for", async () => {
        const response = await search({
          queries: [
            {
              entity: "product",
              search_options: { facets: [{ field: "status", type: "value" }] },
            },
          ],
        })

        expect(response.status).toEqual(200)
        expect(response.data.results[0].facets.status).toEqual({
          type: "value",
          values: [{ value: "published", count: 2 }],
        })
      })

      it("rejects an unknown search option", async () => {
        const error = await search({
          queries: [
            {
              entity: "product",
              search_options: { provider_options: { "search-medusa": {} } },
            },
          ],
        }).catch((e) => e)

        expect(error.response.status).toEqual(400)
      })
    })
  },
})
