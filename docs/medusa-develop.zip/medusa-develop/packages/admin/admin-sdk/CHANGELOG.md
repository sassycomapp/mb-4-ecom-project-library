# @medusajs/admin-sdk

## 2.21.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.21.2

## 2.21.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.21.1

## 2.21.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.21.0

## 2.20.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.20.1

## 2.20.0

### Patch Changes

- Updated dependencies [[`7e421e0f0c60abf64bcfeccea93071202ec78d55`](https://github.com/medusajs/medusa/commit/7e421e0f0c60abf64bcfeccea93071202ec78d55)]:
  - @medusajs/admin-shared@2.20.0

## 2.19.0

### Patch Changes

- Updated dependencies [[`8f03b13a6137047ce36f61a9bb033879395f9345`](undefined)]:
  - @medusajs/admin-shared@2.19.0

## 2.18.0

### Patch Changes

- Updated dependencies [[`8f97e3f3710a2bae662415dac7098e1c6e60c3c9`](https://github.com/medusajs/medusa/commit/8f97e3f3710a2bae662415dac7098e1c6e60c3c9)]:
  - @medusajs/admin-shared@2.18.0

## 2.17.2

### Patch Changes

- [#15683](https://github.com/medusajs/medusa/pull/15683) [`de58ec503bcd82aae3fe576f9a404c36e2525f4c`](https://github.com/medusajs/medusa/commit/de58ec503bcd82aae3fe576f9a404c36e2525f4c) Thanks [@Floofy6](https://github.com/Floofy6)! - chore: add package bugs metadata

- [#15721](https://github.com/medusajs/medusa/pull/15721) [`7686adc8637b41879c4551ca422829ad2d63d6a9`](https://github.com/medusajs/medusa/commit/7686adc8637b41879c4551ca422829ad2d63d6a9) Thanks [@leobenzol](https://github.com/leobenzol)! - feat: drag&drop LayoutComposer, settings db persistence

- Updated dependencies [[`de58ec503bcd82aae3fe576f9a404c36e2525f4c`](https://github.com/medusajs/medusa/commit/de58ec503bcd82aae3fe576f9a404c36e2525f4c), [`7686adc8637b41879c4551ca422829ad2d63d6a9`](https://github.com/medusajs/medusa/commit/7686adc8637b41879c4551ca422829ad2d63d6a9), [`9e47b94b5fb9777b06f099d270bcb95df99c3214`](https://github.com/medusajs/medusa/commit/9e47b94b5fb9777b06f099d270bcb95df99c3214), [`f79afaaecdd5aaa84b31ddcdea14a43692e33eff`](https://github.com/medusajs/medusa/commit/f79afaaecdd5aaa84b31ddcdea14a43692e33eff)]:
  - @medusajs/admin-shared@2.17.2

## 2.17.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.17.1

## 2.17.0

### Patch Changes

- Updated dependencies [[`6eff86709de4dddc359f35fa84a2462fed85b753`](https://github.com/medusajs/medusa/commit/6eff86709de4dddc359f35fa84a2462fed85b753), [`6eff86709de4dddc359f35fa84a2462fed85b753`](https://github.com/medusajs/medusa/commit/6eff86709de4dddc359f35fa84a2462fed85b753)]:
  - @medusajs/admin-shared@2.17.0

## 2.16.0

### Patch Changes

- Updated dependencies [[`f2e576f895ae6579dfa4e29b75d8a0a9c9cf9326`](https://github.com/medusajs/medusa/commit/f2e576f895ae6579dfa4e29b75d8a0a9c9cf9326), [`06b05343b4158e7bb96f8f0fbd7e6836a1818e44`](https://github.com/medusajs/medusa/commit/06b05343b4158e7bb96f8f0fbd7e6836a1818e44)]:
  - @medusajs/admin-shared@2.16.0

## 2.15.5

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.5

## 2.15.4

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.4

## 2.15.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.3

## 2.15.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.2

## 2.15.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.1

## 2.15.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.0

## 2.14.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.14.2

## 2.14.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.14.1

## 2.14.0

### Patch Changes

- [#14309](https://github.com/medusajs/medusa/pull/14309) [`843dbfe7c8f27b732486c7a8da7b6d63f2fdf967`](https://github.com/medusajs/medusa/commit/843dbfe7c8f27b732486c7a8da7b6d63f2fdf967) Thanks [@adrien2p](https://github.com/adrien2p)! - chore(): upgrade zod to latest

- Updated dependencies []:
  - @medusajs/admin-shared@2.14.0

## 2.13.6

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.6

## 2.13.5

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.5

## 2.13.4

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.4

## 2.13.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.3

## 2.13.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.2

## 2.13.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.1

## 2.13.0

### Minor Changes

- [`a31e72c31c5235240cead2d04e39e5927688eec7`](https://github.com/medusajs/medusa/commit/a31e72c31c5235240cead2d04e39e5927688eec7) Thanks [@olivermrbl](https://github.com/olivermrbl)! - chore: Minor bump

### Patch Changes

- Updated dependencies [[`a31e72c31c5235240cead2d04e39e5927688eec7`](https://github.com/medusajs/medusa/commit/a31e72c31c5235240cead2d04e39e5927688eec7)]:
  - @medusajs/admin-shared@2.13.0

## 2.12.6

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.6

## 2.12.5

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.5

## 2.12.4

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.4

## 2.12.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.3

## 2.12.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.2

## 2.12.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.1

## 2.12.0

### Patch Changes

- [#13843](https://github.com/medusajs/medusa/pull/13843) [`3852efbcfffbfd10b7f7cae7d1a15de2a5f3afee`](https://github.com/medusajs/medusa/commit/3852efbcfffbfd10b7f7cae7d1a15de2a5f3afee) Thanks [@leobenzol](https://github.com/leobenzol)! - feat(admin-\*,dashboard): i18n labels for menu item extensions

- [#13946](https://github.com/medusajs/medusa/pull/13946) [`213c344804fb1077aaca3e3cefbd1653ae559899`](https://github.com/medusajs/medusa/commit/213c344804fb1077aaca3e3cefbd1653ae559899) Thanks [@bqst](https://github.com/bqst)! - feat(dashboard): add custom admin route ranking feature

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.0

## 2.11.3

### Patch Changes

- [#13910](https://github.com/medusajs/medusa/pull/13910) [`224ab39a81e8d3cf3d6fa3ff5eee82541f64728d`](https://github.com/medusajs/medusa/commit/224ab39a81e8d3cf3d6fa3ff5eee82541f64728d) Thanks [@adrien2p](https://github.com/adrien2p)! - chore(): Dependencies cleanup and improvements

- [#13940](https://github.com/medusajs/medusa/pull/13940) [`afb40d437b3cc4ceb015df70985b2f005f40eaff`](https://github.com/medusajs/medusa/commit/afb40d437b3cc4ceb015df70985b2f005f40eaff) Thanks [@adrien2p](https://github.com/adrien2p)! - chore(): Cleanup and organize deps

- Updated dependencies [[`224ab39a81e8d3cf3d6fa3ff5eee82541f64728d`](https://github.com/medusajs/medusa/commit/224ab39a81e8d3cf3d6fa3ff5eee82541f64728d), [`afb40d437b3cc4ceb015df70985b2f005f40eaff`](https://github.com/medusajs/medusa/commit/afb40d437b3cc4ceb015df70985b2f005f40eaff)]:
  - @medusajs/admin-shared@2.11.3

## 2.11.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.11.2

## 2.11.1

### Patch Changes

- Updated dependencies [[`226984cf0f229bec00ee33a3a1a981b57889c11a`](https://github.com/medusajs/medusa/commit/226984cf0f229bec00ee33a3a1a981b57889c11a)]:
  - @medusajs/admin-shared@2.11.1

## 2.11.0

### Patch Changes

- Updated dependencies [[`5e827ec95d0f721e62c0d4e8c603bda7ddc0929c`](https://github.com/medusajs/medusa/commit/5e827ec95d0f721e62c0d4e8c603bda7ddc0929c)]:
  - @medusajs/admin-shared@2.11.0

## 2.10.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.10.3

## 2.10.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.10.2

## 2.10.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.10.1

## 2.10.0

### Patch Changes

- Updated dependencies [[`4b3c43fe92d99a98b3d7b9ee6705114de01cbc5d`](https://github.com/medusajs/medusa/commit/4b3c43fe92d99a98b3d7b9ee6705114de01cbc5d)]:
  - @medusajs/admin-shared@2.10.0

## 2.9.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.9.0

## 2.8.8

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.8

## 2.8.7

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.7

## 2.8.6

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.6

## 2.8.5

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.5

## 2.8.4

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.4

## 2.8.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.3

## 2.8.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.2

## 2.8.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.1

## 2.8.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.0

## 2.7.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.7.1

## 2.7.0

### Patch Changes

- Updated dependencies [[`5ab15a29889870411b719ebad3fb94786baee45e`](https://github.com/medusajs/medusa/commit/5ab15a29889870411b719ebad3fb94786baee45e), [`5ab15a29889870411b719ebad3fb94786baee45e`](https://github.com/medusajs/medusa/commit/5ab15a29889870411b719ebad3fb94786baee45e)]:
  - @medusajs/admin-shared@2.7.0

## 2.6.1

### Patch Changes

- [#11738](https://github.com/medusajs/medusa/pull/11738) [`3b470f41427e487c68f89b8ee8155de716ffe861`](https://github.com/medusajs/medusa/commit/3b470f41427e487c68f89b8ee8155de716ffe861) Thanks [@olivermrbl](https://github.com/olivermrbl)! - chore: Remove ranges on Medusa packages

- Updated dependencies []:
  - @medusajs/admin-shared@2.6.1

## 2.6.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.6.0

## 2.5.1

### Patch Changes

- [#11413](https://github.com/medusajs/medusa/pull/11413) [`a039dd6932c3c5581b3ee0ebba1eb8413912ec43`](https://github.com/medusajs/medusa/commit/a039dd6932c3c5581b3ee0ebba1eb8413912ec43) Thanks [@kasperkristensen](https://github.com/kasperkristensen)! - chore(admin-sdk): Pin zod in admin-sdk

- Updated dependencies []:
  - @medusajs/admin-shared@2.5.1

## 2.5.0

### Patch Changes

- [#11272](https://github.com/medusajs/medusa/pull/11272) [`f4c2cd112ed54757ed35a55297b46b36152829cb`](https://github.com/medusajs/medusa/commit/f4c2cd112ed54757ed35a55297b46b36152829cb) Thanks [@thetutlage](https://github.com/thetutlage)! - fix: issues with peer dependencies

- Updated dependencies []:
  - @medusajs/admin-shared@2.5.0

## 2.4.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.4.0

## 2.3.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.3.1

## 2.3.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.3.0

## 2.2.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.2.0

## 2.1.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.1.3

## 2.1.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.1.2

## 2.1.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.1.1

## 2.1.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.1.0

## 2.0.7

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.7

## 2.0.6

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.6

## 2.0.5

### Patch Changes

- Updated dependencies [[`a153bc477c421cd3cfc6f2cb7e30f2f3661f5922`](https://github.com/medusajs/medusa/commit/a153bc477c421cd3cfc6f2cb7e30f2f3661f5922)]:
  - @medusajs/admin-shared@2.0.5

## 2.0.4

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.4

## 2.0.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.3

## 2.0.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.2

## 2.0.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.1

## 2.0.0

### Major Changes

- [#7341](https://github.com/medusajs/medusa/pull/7341) [`2e42e053d4c9d5445d227bdc268c66713aad8e2e`](https://github.com/medusajs/medusa/commit/2e42e053d4c9d5445d227bdc268c66713aad8e2e) Thanks [@olivermrbl](https://github.com/olivermrbl)! - chore: Medusa 2.0

### Patch Changes

- Updated dependencies [[`2e42e053d4c9d5445d227bdc268c66713aad8e2e`](https://github.com/medusajs/medusa/commit/2e42e053d4c9d5445d227bdc268c66713aad8e2e)]:
  - @medusajs/admin-shared@2.0.0
