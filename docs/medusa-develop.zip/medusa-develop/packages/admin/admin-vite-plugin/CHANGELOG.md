# @medusajs/admin-vite-plugin

## 2.21.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.21.2

## 2.21.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.21.1

## 2.21.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.21.0

## 2.20.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.20.1

## 2.20.0

### Patch Changes

- [#16425](https://github.com/medusajs/medusa/pull/16425) [`7e421e0f0c60abf64bcfeccea93071202ec78d55`](https://github.com/medusajs/medusa/commit/7e421e0f0c60abf64bcfeccea93071202ec78d55) Thanks [@sradevski](https://github.com/sradevski)! - Add support for configuring the global search in admin

- Updated dependencies [[`7e421e0f0c60abf64bcfeccea93071202ec78d55`](https://github.com/medusajs/medusa/commit/7e421e0f0c60abf64bcfeccea93071202ec78d55)]:
  - @medusajs/admin-shared@2.20.0

## 2.19.0

### Minor Changes

- [#16314](https://github.com/medusajs/medusa/pull/16314) [`5105fec20908cf7bcd7f5f859674acdd8a38b982`](https://github.com/medusajs/medusa/commit/5105fec20908cf7bcd7f5f859674acdd8a38b982) Thanks [@shahednasser](https://github.com/shahednasser)! - chore(admin-vite-plugin): widen the vite peer range to v5, v6 and v7

  The peer range is now `^5.4.21 || ^6.0.0 || ^7.0.0`, so plugin authors on any of those majors are supported. Also drops the unused `chokidar` dependency — it was declared but never imported, since the plugin uses the watcher Vite provides.

### Patch Changes

- Updated dependencies [[`8f03b13a6137047ce36f61a9bb033879395f9345`](undefined)]:
  - @medusajs/admin-shared@2.19.0

## 2.18.0

### Patch Changes

- [#14661](https://github.com/medusajs/medusa/pull/14661) [`8f97e3f3710a2bae662415dac7098e1c6e60c3c9`](https://github.com/medusajs/medusa/commit/8f97e3f3710a2bae662415dac7098e1c6e60c3c9) Thanks [@NicolasGorga](https://github.com/NicolasGorga)! - feat(dashboard,admin-vite-plugin,admin-shared,ui,settings,js-sdk,types): view configuration UI enhancements — dynamic filter/sort resolution, custom cell renderer registration, property labels management UI

- [#15984](https://github.com/medusajs/medusa/pull/15984) [`e765a7e6b5e9eafff510218f9884e867e2d6e224`](https://github.com/medusajs/medusa/commit/e765a7e6b5e9eafff510218f9884e867e2d6e224) Thanks [@NicolasGorga](https://github.com/NicolasGorga)! - feat(admin-vite-plugin,dashboard): add config.label to document title resolution seo fallback

- Updated dependencies [[`8f97e3f3710a2bae662415dac7098e1c6e60c3c9`](https://github.com/medusajs/medusa/commit/8f97e3f3710a2bae662415dac7098e1c6e60c3c9)]:
  - @medusajs/admin-shared@2.18.0

## 2.17.2

### Patch Changes

- [#15683](https://github.com/medusajs/medusa/pull/15683) [`de58ec503bcd82aae3fe576f9a404c36e2525f4c`](https://github.com/medusajs/medusa/commit/de58ec503bcd82aae3fe576f9a404c36e2525f4c) Thanks [@Floofy6](https://github.com/Floofy6)! - chore: add package bugs metadata

- [#15721](https://github.com/medusajs/medusa/pull/15721) [`7686adc8637b41879c4551ca422829ad2d63d6a9`](https://github.com/medusajs/medusa/commit/7686adc8637b41879c4551ca422829ad2d63d6a9) Thanks [@leobenzol](https://github.com/leobenzol)! - feat: drag&drop LayoutComposer, settings db persistence

- Updated dependencies [[`de58ec503bcd82aae3fe576f9a404c36e2525f4c`](https://github.com/medusajs/medusa/commit/de58ec503bcd82aae3fe576f9a404c36e2525f4c), [`7686adc8637b41879c4551ca422829ad2d63d6a9`](https://github.com/medusajs/medusa/commit/7686adc8637b41879c4551ca422829ad2d63d6a9), [`9e47b94b5fb9777b06f099d270bcb95df99c3214`](https://github.com/medusajs/medusa/commit/9e47b94b5fb9777b06f099d270bcb95df99c3214), [`f79afaaecdd5aaa84b31ddcdea14a43692e33eff`](https://github.com/medusajs/medusa/commit/f79afaaecdd5aaa84b31ddcdea14a43692e33eff)]:
  - @medusajs/admin-shared@2.17.2

## 2.17.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.17.1

## 2.17.0

### Patch Changes

- Updated dependencies [[`6eff86709de4dddc359f35fa84a2462fed85b753`](https://github.com/medusajs/medusa/commit/6eff86709de4dddc359f35fa84a2462fed85b753), [`6eff86709de4dddc359f35fa84a2462fed85b753`](https://github.com/medusajs/medusa/commit/6eff86709de4dddc359f35fa84a2462fed85b753)]:
  - @medusajs/admin-shared@2.17.0

## 2.16.0

### Patch Changes

- Updated dependencies [[`f2e576f895ae6579dfa4e29b75d8a0a9c9cf9326`](https://github.com/medusajs/medusa/commit/f2e576f895ae6579dfa4e29b75d8a0a9c9cf9326), [`06b05343b4158e7bb96f8f0fbd7e6836a1818e44`](https://github.com/medusajs/medusa/commit/06b05343b4158e7bb96f8f0fbd7e6836a1818e44)]:
  - @medusajs/admin-shared@2.16.0

## 2.15.5

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.5

## 2.15.4

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.4

## 2.15.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.3

## 2.15.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.2

## 2.15.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.1

## 2.15.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.15.0

## 2.14.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.14.2

## 2.14.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.14.1

## 2.14.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.14.0

## 2.13.6

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.6

## 2.13.5

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.5

## 2.13.4

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.4

## 2.13.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.3

## 2.13.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.2

## 2.13.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.13.1

## 2.13.0

### Minor Changes

- [`a31e72c31c5235240cead2d04e39e5927688eec7`](https://github.com/medusajs/medusa/commit/a31e72c31c5235240cead2d04e39e5927688eec7) Thanks [@olivermrbl](https://github.com/olivermrbl)! - chore: Minor bump

### Patch Changes

- Updated dependencies [[`a31e72c31c5235240cead2d04e39e5927688eec7`](https://github.com/medusajs/medusa/commit/a31e72c31c5235240cead2d04e39e5927688eec7)]:
  - @medusajs/admin-shared@2.13.0

## 2.12.6

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.6

## 2.12.5

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.5

## 2.12.4

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.4

## 2.12.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.3

## 2.12.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.2

## 2.12.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.1

## 2.12.0

### Patch Changes

- [#14042](https://github.com/medusajs/medusa/pull/14042) [`c2c3ad5ba53f1959422fb2d37297a8de8d714782`](https://github.com/medusajs/medusa/commit/c2c3ad5ba53f1959422fb2d37297a8de8d714782) Thanks [@adrien2p](https://github.com/adrien2p)! - chore(): Upgrade vit to non vulnerable one

- [#13843](https://github.com/medusajs/medusa/pull/13843) [`3852efbcfffbfd10b7f7cae7d1a15de2a5f3afee`](https://github.com/medusajs/medusa/commit/3852efbcfffbfd10b7f7cae7d1a15de2a5f3afee) Thanks [@leobenzol](https://github.com/leobenzol)! - feat(admin-\*,dashboard): i18n labels for menu item extensions

- [#13547](https://github.com/medusajs/medusa/pull/13547) [`1762f73bd903d7e447f9067cc63e172ac58a0f39`](https://github.com/medusajs/medusa/commit/1762f73bd903d7e447f9067cc63e172ac58a0f39) Thanks [@leobenzol](https://github.com/leobenzol)! - feat(admin-vite-plugin,dashboard): support for react-router's splat and optional segments

- [#13946](https://github.com/medusajs/medusa/pull/13946) [`213c344804fb1077aaca3e3cefbd1653ae559899`](https://github.com/medusajs/medusa/commit/213c344804fb1077aaca3e3cefbd1653ae559899) Thanks [@bqst](https://github.com/bqst)! - feat(dashboard): add custom admin route ranking feature

- Updated dependencies []:
  - @medusajs/admin-shared@2.12.0

## 2.11.3

### Patch Changes

- [#13910](https://github.com/medusajs/medusa/pull/13910) [`224ab39a81e8d3cf3d6fa3ff5eee82541f64728d`](https://github.com/medusajs/medusa/commit/224ab39a81e8d3cf3d6fa3ff5eee82541f64728d) Thanks [@adrien2p](https://github.com/adrien2p)! - chore(): Dependencies cleanup and improvements

- [#13940](https://github.com/medusajs/medusa/pull/13940) [`afb40d437b3cc4ceb015df70985b2f005f40eaff`](https://github.com/medusajs/medusa/commit/afb40d437b3cc4ceb015df70985b2f005f40eaff) Thanks [@adrien2p](https://github.com/adrien2p)! - chore(): Cleanup and organize deps

- [#13932](https://github.com/medusajs/medusa/pull/13932) [`37563987b8fe75c9acfe62957a33e8398977647a`](https://github.com/medusajs/medusa/commit/37563987b8fe75c9acfe62957a33e8398977647a) Thanks [@adrien2p](https://github.com/adrien2p)! - chore(): Fix dependencies vulnerabilities

- Updated dependencies [[`224ab39a81e8d3cf3d6fa3ff5eee82541f64728d`](https://github.com/medusajs/medusa/commit/224ab39a81e8d3cf3d6fa3ff5eee82541f64728d), [`afb40d437b3cc4ceb015df70985b2f005f40eaff`](https://github.com/medusajs/medusa/commit/afb40d437b3cc4ceb015df70985b2f005f40eaff)]:
  - @medusajs/admin-shared@2.11.3

## 2.11.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.11.2

## 2.11.1

### Patch Changes

- [#13763](https://github.com/medusajs/medusa/pull/13763) [`226984cf0f229bec00ee33a3a1a981b57889c11a`](https://github.com/medusajs/medusa/commit/226984cf0f229bec00ee33a3a1a981b57889c11a) Thanks [@leobenzol](https://github.com/leobenzol)! - feat(admin-\*,dashboard): add dashboard i18n extensions

- Updated dependencies [[`226984cf0f229bec00ee33a3a1a981b57889c11a`](https://github.com/medusajs/medusa/commit/226984cf0f229bec00ee33a3a1a981b57889c11a)]:
  - @medusajs/admin-shared@2.11.1

## 2.11.0

### Patch Changes

- Updated dependencies [[`5e827ec95d0f721e62c0d4e8c603bda7ddc0929c`](https://github.com/medusajs/medusa/commit/5e827ec95d0f721e62c0d4e8c603bda7ddc0929c)]:
  - @medusajs/admin-shared@2.11.0

## 2.10.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.10.3

## 2.10.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.10.2

## 2.10.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.10.1

## 2.10.0

### Patch Changes

- Updated dependencies [[`4b3c43fe92d99a98b3d7b9ee6705114de01cbc5d`](https://github.com/medusajs/medusa/commit/4b3c43fe92d99a98b3d7b9ee6705114de01cbc5d)]:
  - @medusajs/admin-shared@2.10.0

## 2.9.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.9.0

## 2.8.8

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.8

## 2.8.7

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.7

## 2.8.6

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.6

## 2.8.5

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.5

## 2.8.4

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.4

## 2.8.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.3

## 2.8.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.2

## 2.8.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.1

## 2.8.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.8.0

## 2.7.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.7.1

## 2.7.0

### Patch Changes

- [#11720](https://github.com/medusajs/medusa/pull/11720) [`ec56a8bc857a74788df6523af25914da95c4c1d8`](https://github.com/medusajs/medusa/commit/ec56a8bc857a74788df6523af25914da95c4c1d8) Thanks [@kasperkristensen](https://github.com/kasperkristensen)! - fix(medusa,utils,test-utils,types,framework,dashboard,admin-vite-plugin,admib-bundler): Fix broken plugin dependencies in development server

- Updated dependencies [[`5ab15a29889870411b719ebad3fb94786baee45e`](https://github.com/medusajs/medusa/commit/5ab15a29889870411b719ebad3fb94786baee45e), [`5ab15a29889870411b719ebad3fb94786baee45e`](https://github.com/medusajs/medusa/commit/5ab15a29889870411b719ebad3fb94786baee45e)]:
  - @medusajs/admin-shared@2.7.0

## 2.6.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.6.1

## 2.6.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.6.0

## 2.5.1

### Patch Changes

- [#11305](https://github.com/medusajs/medusa/pull/11305) [`a88f6576bd06522f86fb2f8bd4b49f94bd4017c1`](https://github.com/medusajs/medusa/commit/a88f6576bd06522f86fb2f8bd4b49f94bd4017c1) Thanks [@kasperkristensen](https://github.com/kasperkristensen)! - feat(dashboard,admin-vite-plugin): Add support for parallel routes

- [#11414](https://github.com/medusajs/medusa/pull/11414) [`47edd01deec79b394552cea349f1e41b7b88723b`](https://github.com/medusajs/medusa/commit/47edd01deec79b394552cea349f1e41b7b88723b) Thanks [@kasperkristensen](https://github.com/kasperkristensen)! - fix(admin-vite-plugin,admin-bundler,ui,icons,dashboard,framework,types): Update Vite dependencies

- Updated dependencies []:
  - @medusajs/admin-shared@2.5.1

## 2.5.0

### Patch Changes

- [#11361](https://github.com/medusajs/medusa/pull/11361) [`3dbef519d95cf694d06843cb694c0d2abdac2146`](https://github.com/medusajs/medusa/commit/3dbef519d95cf694d06843cb694c0d2abdac2146) Thanks [@kasperkristensen](https://github.com/kasperkristensen)! - fix(admin-vite-plugin,icons,ui,dashboard): Upgrade vitest in all packages and align Vite version

- Updated dependencies []:
  - @medusajs/admin-shared@2.5.0

## 2.4.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.4.0

## 2.3.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.3.1

## 2.3.0

### Patch Changes

- [#10869](https://github.com/medusajs/medusa/pull/10869) [`1ba2fadf22a30de9f94aee4f195163ef5e9e84d2`](https://github.com/medusajs/medusa/commit/1ba2fadf22a30de9f94aee4f195163ef5e9e84d2) Thanks [@kasperkristensen](https://github.com/kasperkristensen)! - feat(admin-bundler,admin-vite-plugin): Support loading loading admin extensions from plugins.

- Updated dependencies []:
  - @medusajs/admin-shared@2.3.0

## 2.2.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.2.0

## 2.1.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.1.3

## 2.1.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.1.2

## 2.1.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.1.1

## 2.1.0

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.1.0

## 2.0.7

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.7

## 2.0.6

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.6

## 2.0.5

### Patch Changes

- [#10236](https://github.com/medusajs/medusa/pull/10236) [`96b8963a6c0ac634de9af45ce3be285fc8030b85`](https://github.com/medusajs/medusa/commit/96b8963a6c0ac634de9af45ce3be285fc8030b85) Thanks [@kasperkristensen](https://github.com/kasperkristensen)! - fix(admin-vite-plugin): Move @babel/types to dependencies from devDependencies to make it compatible with Yarn PnP

- Updated dependencies [[`a153bc477c421cd3cfc6f2cb7e30f2f3661f5922`](https://github.com/medusajs/medusa/commit/a153bc477c421cd3cfc6f2cb7e30f2f3661f5922)]:
  - @medusajs/admin-shared@2.0.5

## 2.0.4

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.4

## 2.0.3

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.3

## 2.0.2

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.2

## 2.0.1

### Patch Changes

- Updated dependencies []:
  - @medusajs/admin-shared@2.0.1

## 2.0.0

### Major Changes

- [#7341](https://github.com/medusajs/medusa/pull/7341) [`2e42e053d4c9d5445d227bdc268c66713aad8e2e`](https://github.com/medusajs/medusa/commit/2e42e053d4c9d5445d227bdc268c66713aad8e2e) Thanks [@olivermrbl](https://github.com/olivermrbl)! - chore: Medusa 2.0

### Patch Changes

- Updated dependencies [[`2e42e053d4c9d5445d227bdc268c66713aad8e2e`](https://github.com/medusajs/medusa/commit/2e42e053d4c9d5445d227bdc268c66713aad8e2e)]:
  - @medusajs/admin-shared@2.0.0
