export const LINK_VIRTUAL_MODULE = `virtual:medusa/links`
export const FORM_VIRTUAL_MODULE = `virtual:medusa/forms`
export const DISPLAY_VIRTUAL_MODULE = `virtual:medusa/displays`
export const ROUTE_VIRTUAL_MODULE = `virtual:medusa/routes`
export const MENU_ITEM_VIRTUAL_MODULE = `virtual:medusa/menu-items`
export const WIDGET_VIRTUAL_MODULE = `virtual:medusa/widgets`
export const I18N_VIRTUAL_MODULE = `virtual:medusa/i18n`
export const CELL_RENDERER_VIRTUAL_MODULE = `virtual:medusa/cell-renderers`
export const LAYOUT_VIRTUAL_MODULE = `virtual:medusa/layouts`
export const SEARCH_ENTITY_VIRTUAL_MODULE = `virtual:medusa/search-entities`

export const VIRTUAL_MODULES = [
  LINK_VIRTUAL_MODULE,
  FORM_VIRTUAL_MODULE,
  DISPLAY_VIRTUAL_MODULE,
  ROUTE_VIRTUAL_MODULE,
  MENU_ITEM_VIRTUAL_MODULE,
  WIDGET_VIRTUAL_MODULE,
  I18N_VIRTUAL_MODULE,
  CELL_RENDERER_VIRTUAL_MODULE,
  LAYOUT_VIRTUAL_MODULE,
  SEARCH_ENTITY_VIRTUAL_MODULE,
] as const
